import { db } from "@/db";
import { orders } from "@/db/schema";
import { eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET(
  request: Request,
  { params }: { params: Promise<{ orderNumber: string }> },
) {
  const { orderNumber } = await params;
  const ref = orderNumber.trim().toUpperCase();
  if (ref.length < 4) {
    return Response.json({ ok: false, error: "Enter the full order number, e.g. KFY-XXXXXX-XXX." }, { status: 400 });
  }

  const email = new URL(request.url).searchParams.get("email")?.trim().toLowerCase();

  try {
    const [row] = await db.select().from(orders).where(eq(orders.orderNumber, ref)).limit(1);
    if (!row) {
      return Response.json({ ok: false, error: "No order found with that reference." }, { status: 404 });
    }
    if (email && row.customerEmail.toLowerCase() !== email) {
      return Response.json(
        { ok: false, error: "That order number does not match the email provided." },
        { status: 403 },
      );
    }

    return Response.json({
      ok: true,
      order: {
        orderNumber: row.orderNumber,
        status: row.status,
        planName: row.planName,
        credits: row.credits,
        totalCents: row.totalCents,
        currency: row.currency,
        senderId: row.senderId,
        campaignName: row.campaignName,
        schedule: row.schedule,
        scheduledAt: row.scheduledAt,
        paymentMethod: row.paymentMethod,
        country: row.country,
        createdAt: row.createdAt.toISOString(),
      },
    });
  } catch (error) {
    console.error("[orders] track failed", error);
    return Response.json({ ok: false, error: "Tracking is temporarily unavailable." }, { status: 500 });
  }
}

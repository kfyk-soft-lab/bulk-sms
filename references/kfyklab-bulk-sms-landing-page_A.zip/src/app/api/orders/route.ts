import { db } from "@/db";
import { orders } from "@/db/schema";
import { bumpStats, ensureStats, makeOrderNumber } from "@/lib/stats";
import { COUNTRIES, PAYMENT_METHODS, pricePerSmsTenthsFor, totalCentsFor } from "@/lib/plans";
import { desc } from "drizzle-orm";

export const dynamic = "force-dynamic";

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[a-z]{2,}$/i;
const MAX_CREDITS = 20_000_000;

type Payload = {
  planId?: unknown;
  planName?: unknown;
  credits?: unknown;
  segments?: unknown;
  senderId?: unknown;
  campaignName?: unknown;
  message?: unknown;
  recipients?: unknown;
  schedule?: unknown;
  scheduledAt?: unknown;
  customerName?: unknown;
  customerEmail?: unknown;
  customerPhone?: unknown;
  company?: unknown;
  country?: unknown;
  paymentMethod?: unknown;
  notes?: unknown;
};

const str = (v: unknown, max = 500) =>
  typeof v === "string" ? v.trim().slice(0, max) : undefined;

export async function POST(request: Request) {
  let body: Payload;
  try {
    body = (await request.json()) as Payload;
  } catch {
    return Response.json({ ok: false, error: "Invalid JSON body." }, { status: 400 });
  }

  const credits = Number(body.credits);
  const segments = Math.min(10, Math.max(1, Math.round(Number(body.segments) || 1)));

  const customerName = str(body.customerName, 120);
  const customerEmail = str(body.customerEmail, 160)?.toLowerCase();
  const customerPhone = str(body.customerPhone, 40);

  if (!customerName || customerName.length < 2) {
    return Response.json({ ok: false, error: "Please enter the full name on the account." }, { status: 400 });
  }
  if (!customerEmail || !EMAIL_RE.test(customerEmail)) {
    return Response.json({ ok: false, error: "A valid work email is required." }, { status: 400 });
  }
  if (!customerPhone || customerPhone.replace(/\D/g, "").length < 7) {
    return Response.json({ ok: false, error: "A reachable phone number is required." }, { status: 400 });
  }
  if (!Number.isFinite(credits) || credits < 100 || credits > MAX_CREDITS) {
    return Response.json(
      { ok: false, error: "Order volume must be between 100 and 20,000,000 credits." },
      { status: 400 },
    );
  }

  const paymentMethod = str(body.paymentMethod) ?? "card";
  if (!PAYMENT_METHODS.some((m) => m.id === paymentMethod)) {
    return Response.json({ ok: false, error: "Unsupported payment method." }, { status: 400 });
  }

  const country = str(body.country, 80) ?? "Other";
  if (!COUNTRIES.includes(country)) {
    return Response.json({ ok: false, error: "Unsupported country." }, { status: 400 });
  }

  // Price is always recomputed on the server — the client value is display-only.
  const rateTenths = pricePerSmsTenthsFor(credits);
  const totalCents = totalCentsFor(credits, segments);

  try {
    await ensureStats();

    const [order] = await db
      .insert(orders)
      .values({
        orderNumber: makeOrderNumber(),
        planId: str(body.planId, 40) ?? "custom",
        planName: str(body.planName, 60) ?? "Custom basket",
        credits,
        pricePerSmsCents: Math.round(rateTenths / 10) || 1,
        totalCents,
        senderId: str(body.senderId, 24)?.toUpperCase() || null,
        campaignName: str(body.campaignName, 120) || null,
        message: str(body.message, 900) || null,
        recipients: Number.isFinite(Number(body.recipients))
          ? Math.max(0, Math.round(Number(body.recipients)))
          : null,
        segmentsPerSms: segments,
        schedule: str(body.schedule, 20) === "scheduled" ? "scheduled" : "instant",
        scheduledAt: str(body.scheduledAt, 80) || null,
        customerName,
        customerEmail,
        customerPhone,
        company: str(body.company, 120) || null,
        country,
        paymentMethod,
        notes: str(body.notes, 900) || null,
        status: paymentMethod === "invoice" ? "pending" : "paid",
      })
      .returning();

    await bumpStats(credits);

    return Response.json(
      {
        ok: true,
        order: {
          orderNumber: order.orderNumber,
          status: order.status,
          credits: order.credits,
          totalCents: order.totalCents,
          currency: order.currency,
          senderId: order.senderId,
          planName: order.planName,
          paymentMethod: order.paymentMethod,
          createdAt: order.createdAt.toISOString(),
        },
      },
      { status: 201 },
    );
  } catch (error) {
    console.error("[orders] create failed", error);
    return Response.json(
      { ok: false, error: "We could not place this order. Please try again in a moment." },
      { status: 500 },
    );
  }
}

export async function GET(request: Request) {
  const limit = Math.min(50, Number(new URL(request.url).searchParams.get("limit") ?? 12) || 12);
  try {
    const rows = await db.select().from(orders).orderBy(desc(orders.createdAt)).limit(limit);
    return Response.json({ ok: true, orders: rows });
  } catch (error) {
    console.error("[orders] list failed", error);
    return Response.json({ ok: false, orders: [] }, { status: 500 });
  }
}

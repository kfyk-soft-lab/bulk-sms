import { ensureStats } from "@/lib/stats";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const stats = await ensureStats();
    return Response.json({ ok: true, stats });
  } catch (error) {
    console.error("[stats] failed", error);
    return Response.json({ ok: false, stats: null }, { status: 500 });
  }
}

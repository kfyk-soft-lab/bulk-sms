import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  metadataBase: new URL("https://kfyklab.com"),
  title: {
    default: "Kfyklab — Bulk SMS that actually lands",
    template: "%s · Kfyklab",
  },
  description:
    "Kfyklab sends bulk SMS over direct carrier routes in 190+ countries. Order credits online, launch a campaign in under four minutes, and watch delivery reports stream in real time.",
  keywords: [
    "bulk SMS",
    "bulk SMS provider",
    "SMS API",
    "transactional SMS",
    "marketing SMS",
    "sender ID registration",
    "Kfyklab",
  ],
  authors: [{ name: "Kfyklab" }],
  openGraph: {
    title: "Kfyklab — Bulk SMS that actually lands",
    description:
      "Order bulk SMS credits online. Direct carrier routes, 99.95% uptime, real-time delivery reports, and a campaign studio your whole team can use.",
    type: "website",
    siteName: "Kfyklab",
    url: "https://kfyklab.com",
  },
  twitter: {
    card: "summary_large_image",
    title: "Kfyklab — Bulk SMS that actually lands",
    description: "Direct-route bulk SMS. Order credits online in four minutes.",
  },
  robots: { index: true, follow: true },
};

export const viewport: Viewport = {
  themeColor: "#04060a",
  colorScheme: "dark",
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" className="scroll-smooth">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          rel="stylesheet"
          href="https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wght@12..96,500;12..96,600;12..96,700;12..96,800&family=Plus+Jakarta+Sans:ital,wght@0,400;0,500;0,600;0,700;1,400&family=JetBrains+Mono:wght@400;500;600&display=swap"
        />
        <link
          rel="icon"
          href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 32 32'%3E%3Crect width='32' height='32' rx='9' fill='%2304060a'/%3E%3Cpath d='M9 8v16M9 16.5 19 8M11.6 14.6 20 24' stroke='%2338e8ac' stroke-width='2.6' stroke-linecap='round' stroke-linejoin='round' fill='none'/%3E%3C/svg%3E"
        />
      </head>
      <body className="bg-ink-950 font-sans text-mist-100 antialiased">
        <a
          href="#main"
          className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-[200] focus:rounded-xl focus:bg-signal-400 focus:px-4 focus:py-2 focus:text-sm focus:font-semibold focus:text-ink-950"
        >
          Skip to content
        </a>
        {children}
      </body>
    </html>
  );
}

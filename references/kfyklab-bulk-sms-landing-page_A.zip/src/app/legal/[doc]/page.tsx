import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { IconArrow, LogoMark } from "@/components/icons";

export const dynamicParams = false;

type Doc = {
  slug: string;
  title: string;
  updated: string;
  intro: string;
  sections: { heading: string; body: string[] }[];
};

const DOCS: Doc[] = [
  {
    slug: "acceptable-use",
    title: "Acceptable use policy",
    updated: "12 January 2026",
    intro:
      "Bulk SMS reaches real people's pockets. These rules keep our routes whitelisted and your Sender IDs alive.",
    sections: [
      {
        heading: "1. Consent is mandatory",
        body: [
          "Every number you message must have opted in to receive messages from your brand, and you must be able to evidence that opt-in on request. Purchased, scraped or rented lists are prohibited and will get an account suspended without refund of remaining credits used for the offending send.",
        ],
      },
      {
        heading: "2. Prohibited content",
        body: [
          "No gambling without a licensed jurisdiction, no adult content, no payday lending outside licensed markets, no cryptocurrency pump schemes, no political messaging where local law restricts it, no impersonation of government bodies, banks or other brands, and no content that is fraudulent, defamatory or incites violence.",
        ],
      },
      {
        heading: "3. Identity and opt-out",
        body: [
          "Every message must identify your brand and honour STOP, HELP and UNSUBSCRIBE keywords. Kfyklab suppresses opted-out numbers automatically across your account within about 200 milliseconds; attempting to route around that suppression is a terminable offence.",
        ],
      },
      {
        heading: "4. Quiet hours and frequency",
        body: [
          "Promotional traffic is queued to respect local recipient time between 08:00 and 20:00 unless you have explicit consent for out-of-hours messaging. Transactional traffic such as one-time passwords, order updates and appointment reminders is exempt.",
        ],
      },
      {
        heading: "5. Enforcement",
        body: [
          "We sample campaign copy, monitor complaint rates per operator and pause any send whose bounce or complaint rate spikes abnormally. Where a route is damaged by a violation, we may withhold the affected credits and terminate the account. Appeals go to routes@kfyklab.com and are reviewed by a human within two business days.",
        ],
      },
    ],
  },
  {
    slug: "privacy",
    title: "Privacy notice",
    updated: "12 January 2026",
    intro: "What we collect when you order credits, why we collect it, and how long we keep it.",
    sections: [
      {
        heading: "Data we collect",
        body: [
          "When you place an order we store your name, work email, phone number, company, country, chosen package, Sender ID, campaign copy, recipient count and payment method. Payment card details are handled by our PCI-DSS payment processor and never touch Kfyklab servers.",
          "When you use the campaign studio in your browser, message copy and audience settings stay local to your session until you place an order.",
        ],
      },
      {
        heading: "Why we process it",
        body: [
          "To fulfil your order, register Sender IDs with destination operators, deliver messages to your recipients, provide delivery receipts, prevent fraud and spam, meet tax and telecom record-keeping obligations, and answer support requests.",
        ],
      },
      {
        heading: "Retention",
        body: [
          "Order records are retained for seven years for tax and audit purposes. Message content and delivery receipts are retained for 90 days by default, or longer where a local telecom regulator requires it. Recipient opt-out records are retained indefinitely so we can honour them.",
        ],
      },
      {
        heading: "Your rights",
        body: [
          "Under GDPR, the Kenya Data Protection Act and NDPR you may request access, rectification, erasure, restriction or portability of your personal data, and you may object to processing. Write to privacy@kfyklab.com; we respond within 30 days.",
        ],
      },
      {
        heading: "Sub-processors",
        body: [
          "We use tier-1 mobile network operators and licensed aggregators for termination, a PCI-DSS payment processor for card acquiring, and cloud infrastructure in the EU, Kenya and South Africa. A current list is available on request.",
        ],
      },
    ],
  },
  {
    slug: "terms",
    title: "Terms of service",
    updated: "12 January 2026",
    intro: "The commercial terms that apply when you buy credits through the Kfyklab order desk.",
    sections: [
      {
        heading: "1. The service",
        body: [
          "Kfyklab provides prepaid bulk SMS transmission, Sender ID registration, campaign tooling, a REST API and delivery reporting. Credits are denominated in message segments, not currency, and one credit equals one 160-character GSM-7 segment to one recipient.",
        ],
      },
      {
        heading: "2. Orders and payment",
        body: [
          "An order is accepted when payment clears. Card and wallet orders activate instantly; bank transfers activate on settlement; invoice accounts are subject to credit approval and net-15 terms unless agreed otherwise in writing. Prices are quoted in USD and exclude applicable taxes, which are shown at checkout.",
        ],
      },
      {
        heading: "3. Credits, expiry and refunds",
        body: [
          "Credits never expire and roll forward indefinitely. Messages that fail for invalid number, dead SIM, handset unreachable beyond the retry window, or operator rejection are refunded to your balance automatically. We do not refund messages that were successfully delivered, including where the recipient later opts out.",
        ],
      },
      {
        heading: "4. Delivery targets",
        body: [
          "Published delivery rates and latencies are targets measured across a rolling 30-day window per market, not guarantees for a specific list. Where an Orbit or Atlas agreement includes an SLA, service credits are calculated monthly and applied to your next invoice.",
        ],
      },
      {
        heading: "5. Your obligations",
        body: [
          "You warrant that you hold lawful consent for every number you submit, that your content complies with the acceptable use policy and applicable law, and that you will maintain a working opt-out mechanism. You indemnify Kfyklab against claims arising from breach of these warranties.",
        ],
      },
      {
        heading: "6. Suspension and termination",
        body: [
          "We may suspend a campaign or account immediately where we detect spam, fraud, regulator action or route abuse. Either party may terminate with 30 days' notice; on termination any unused credits are refunded within 30 days, less amounts owed for abuse-related remediation.",
        ],
      },
      {
        heading: "7. Liability",
        body: [
          "Our aggregate liability is capped at the value of credits purchased in the three months preceding the claim. Neither party is liable for indirect or consequential loss. Nothing limits liability for fraud, death or personal injury caused by negligence.",
        ],
      },
    ],
  },
  {
    slug: "dpa",
    title: "Data processing addendum",
    updated: "12 January 2026",
    intro:
      "Where you send messages on behalf of your own customers, Kfyklab acts as your processor. These terms apply.",
    sections: [
      {
        heading: "Roles",
        body: [
          "You are the controller of recipient personal data (phone numbers and any merge-tag content). Kfyklab is a processor and processes that data only to transmit messages, produce delivery receipts, enforce opt-outs and comply with law.",
        ],
      },
      {
        heading: "Security measures",
        body: [
          "Encryption in transit with TLS 1.3 and at rest with AES-256, role-based access with hardware-key MFA for production systems, immutable audit logging, quarterly penetration testing, and least-privilege access to message content for named support engineers only.",
        ],
      },
      {
        heading: "Sub-processing",
        body: [
          "You authorise our use of licensed telecom operators and aggregators as sub-processors for message termination. We notify registered accounts of changes to the sub-processor list 30 days in advance and remain liable for their performance.",
        ],
      },
      {
        heading: "International transfers",
        body: [
          "Where recipient data crosses borders, transfers rely on the EU Standard Contractual Clauses (Module 2), the UK International Data Transfer Addendum, or an adequacy decision, as applicable to your jurisdiction.",
        ],
      },
      {
        heading: "Breach notification and assistance",
        body: [
          "We notify you without undue delay and in any event within 72 hours of becoming aware of a personal data breach affecting your data, and we assist with data subject requests, DPIAs and regulator consultations at no additional cost on Orbit and Atlas plans.",
        ],
      },
    ],
  },
];

export function generateStaticParams() {
  return DOCS.map((doc) => ({ doc: doc.slug }));
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ doc: string }>;
}): Promise<Metadata> {
  const { doc: slug } = await params;
  const doc = DOCS.find((d) => d.slug === slug);
  return { title: doc ? doc.title : "Legal" };
}

export default async function LegalPage({ params }: { params: Promise<{ doc: string }> }) {
  const { doc: slug } = await params;
  const doc = DOCS.find((d) => d.slug === slug);
  if (!doc) notFound();

  return (
    <div className="min-h-screen bg-ink-950">
      <div aria-hidden className="pointer-events-none fixed inset-0 -z-10">
        <div className="absolute -right-32 top-0 size-[32rem] animate-drift rounded-full bg-signal-500/10 blur-[140px]" />
      </div>

      <header className="sticky top-0 z-40 border-b border-white/8 bg-ink-950/85 backdrop-blur-xl">
        <div className="mx-auto flex w-full max-w-4xl items-center justify-between gap-4 px-4 py-3.5 sm:px-6">
          <Link href="/" className="flex items-center gap-3">
            <LogoMark className="size-9" />
            <span className="font-display text-[15px] font-bold text-mist-50">Kfyklab</span>
          </Link>
          <Link
            href="/#pricing"
            className="group flex items-center gap-1.5 rounded-xl border border-white/12 bg-white/5 px-3.5 py-2 text-[13px] text-mist-200 transition hover:border-signal-400/40 hover:text-signal-200"
          >
            <IconArrow className="size-3.5 rotate-180 transition-transform group-hover:-translate-x-0.5" />
            Back
          </Link>
        </div>
      </header>

      <main className="mx-auto w-full max-w-3xl px-4 py-14 sm:px-6 sm:py-20">
        <p className="font-mono text-[10.5px] tracking-[0.22em] text-signal-300 uppercase">
          Updated {doc.updated}
        </p>
        <h1 className="mt-4 font-display text-[clamp(2rem,5vw,3rem)] font-bold leading-[1.05] tracking-[-0.035em] text-mist-50">
          {doc.title}
        </h1>
        <p className="mt-5 text-[16px] leading-relaxed text-mist-300">{doc.intro}</p>

        <div className="mt-10 space-y-8">
          {doc.sections.map((section) => (
            <section key={section.heading} className="rounded-2xl border border-white/8 bg-ink-900/45 p-6">
              <h2 className="font-display text-[18px] font-semibold text-mist-50">{section.heading}</h2>
              {section.body.map((paragraph, index) => (
                <p key={index} className="mt-3 text-[14.5px] leading-relaxed text-mist-400">
                  {paragraph}
                </p>
              ))}
            </section>
          ))}
        </div>

        <nav aria-label="Other legal documents" className="mt-12 flex flex-wrap gap-2">
          {DOCS.map((item) => (
            <Link
              key={item.slug}
              href={`/legal/${item.slug}`}
              className={`rounded-xl border px-3.5 py-2 text-[12.5px] transition ${
                item.slug === doc.slug
                  ? "border-signal-400/45 bg-signal-400/10 text-signal-200"
                  : "border-white/10 text-mist-400 hover:border-white/25 hover:text-mist-100"
              }`}
            >
              {item.title}
            </Link>
          ))}
        </nav>

        <p className="mt-10 border-t border-white/8 pt-6 text-[13px] text-mist-600">
          Questions about any of this? Write to{" "}
          <a href="mailto:legal@kfyklab.com" className="text-signal-300 underline decoration-signal-400/40 underline-offset-4 hover:text-signal-200">
            legal@kfyklab.com
          </a>{" "}
          — we will sign your DPA if ours does not fit.
        </p>
      </main>
    </div>
  );
}

import type { Metadata } from "next";
import Link from "next/link";
import { db } from "@/db";
import { orders } from "@/db/schema";
import { ensureStats } from "@/lib/stats";
import { desc } from "drizzle-orm";
import { OrdersTable } from "@/components/OrdersTable";
import { IconArrow, LogoMark } from "@/components/icons";

export const dynamic = "force-dynamic";
export const metadata: Metadata = {
  title: "Operations dashboard",
  description: "Every bulk SMS order placed through the Kfyklab order desk.",
  robots: { index: false },
};

export default async function OrdersPage() {
  const [rows, stats] = await Promise.all([
    db.select().from(orders).orderBy(desc(orders.createdAt)).limit(200).catch(() => []),
    ensureStats().catch(() => ({ messagesDelivered: 0, ordersPlaced: 0, updatedAt: new Date().toISOString() })),
  ]);

  const revenue = rows.reduce((sum, row) => sum + row.totalCents, 0);
  const credits = rows.reduce((sum, row) => sum + row.credits, 0);
  const openCount = rows.filter((row) => row.status === "pending" || row.status === "processing").length;

  const kpis = [
    { label: "Orders captured", value: rows.length.toLocaleString("en-US"), sub: "all time · this instance" },
    { label: "Credits sold", value: credits.toLocaleString("en-US"), sub: `${stats.messagesDelivered.toLocaleString("en-US")} delivered network-wide` },
    {
      label: "Order value",
      value: `$${(revenue / 100).toLocaleString("en-US", { maximumFractionDigits: 0 })}`,
      sub: "gross, USD",
    },
    { label: "Awaiting fulfilment", value: openCount.toLocaleString("en-US"), sub: "pending + processing" },
  ];

  return (
    <div className="min-h-screen bg-ink-950">
      <div aria-hidden className="pointer-events-none fixed inset-0 -z-10">
        <div className="absolute -left-40 top-0 size-[36rem] animate-drift rounded-full bg-signal-500/10 blur-[140px]" />
        <div className="absolute right-0 top-1/3 size-[28rem] animate-drift-slow rounded-full bg-pulse-500/10 blur-[140px]" />
      </div>

      <header className="sticky top-0 z-40 border-b border-white/8 bg-ink-950/85 backdrop-blur-xl">
        <div className="mx-auto flex w-full max-w-[86rem] items-center justify-between gap-4 px-4 py-3.5 sm:px-6">
          <Link href="/" className="group flex items-center gap-3">
            <LogoMark className="size-9" />
            <span>
              <span className="block font-display text-[15px] font-bold text-mist-50">Kfyklab</span>
              <span className="block font-mono text-[9.5px] tracking-[0.24em] text-mist-500 uppercase">
                Operations
              </span>
            </span>
          </Link>
          <Link
            href="/#pricing"
            className="group flex items-center gap-1.5 rounded-xl border border-white/12 bg-white/5 px-3.5 py-2 text-[13px] font-medium text-mist-200 transition hover:border-signal-400/40 hover:text-signal-200"
          >
            <IconArrow className="size-3.5 rotate-180 transition-transform group-hover:-translate-x-0.5" />
            Back to order desk
          </Link>
        </div>
      </header>

      <main className="mx-auto w-full max-w-[86rem] px-4 py-10 sm:px-6 sm:py-14">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <p className="font-mono text-[10.5px] tracking-[0.22em] text-signal-300 uppercase">
              Live order book
            </p>
            <h1 className="mt-3 font-display text-[clamp(1.9rem,4.5vw,2.8rem)] font-bold leading-tight tracking-[-0.035em] text-mist-50">
              Every basket your customers ordered.
            </h1>
            <p className="mt-3 max-w-xl text-[14.5px] leading-relaxed text-mist-400">
              Orders land here the moment checkout completes — with destination, Sender ID, campaign
              copy and payment method. Nothing is editable from this view; it is your audit trail.
            </p>
          </div>
          <p className="font-mono text-[11px] text-mist-600">
            Synced {new Date(stats.updatedAt).toLocaleString("en-GB", { dateStyle: "medium", timeStyle: "short" })}
          </p>
        </div>

        <dl className="mt-9 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          {kpis.map((kpi) => (
            <div
              key={kpi.label}
              className="glass group rounded-2xl p-5 transition-all duration-400 hover:-translate-y-0.5 hover:border-signal-400/25"
            >
              <dt className="font-mono text-[10px] tracking-[0.18em] text-mist-500 uppercase">
                {kpi.label}
              </dt>
              <dd className="mt-2.5 font-display text-[28px] font-bold leading-none text-mist-50 tabular-nums transition-colors duration-300 group-hover:text-signal-300">
                {kpi.value}
              </dd>
              <p className="mt-2 text-[11.5px] text-mist-600">{kpi.sub}</p>
            </div>
          ))}
        </dl>

        <OrdersTable
          rows={rows.map((row) => ({
            id: row.id,
            orderNumber: row.orderNumber,
            planName: row.planName,
            credits: row.credits,
            totalCents: row.totalCents,
            currency: row.currency,
            senderId: row.senderId,
            campaignName: row.campaignName,
            message: row.message,
            recipients: row.recipients,
            schedule: row.schedule,
            scheduledAt: row.scheduledAt,
            customerName: row.customerName,
            customerEmail: row.customerEmail,
            customerPhone: row.customerPhone,
            company: row.company,
            country: row.country,
            paymentMethod: row.paymentMethod,
            notes: row.notes,
            status: row.status,
            createdAt: row.createdAt.toISOString(),
          }))}
        />
      </main>
    </div>
  );
}

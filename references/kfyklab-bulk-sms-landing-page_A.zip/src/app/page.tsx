import { ensureStats } from "@/lib/stats";
import { PLANS } from "@/lib/plans";
import { OrderProvider } from "@/components/order/OrderContext";
import { Navbar } from "@/components/Navbar";
import { Hero } from "@/components/Hero";
import { SocialProof } from "@/components/SocialProof";
import { Features } from "@/components/Features";
import { Studio } from "@/components/Studio";
import { Network } from "@/components/Network";
import { Benefits } from "@/components/Benefits";
import { Testimonials } from "@/components/Testimonials";
import { Pricing } from "@/components/Pricing";
import { Faq } from "@/components/Faq";
import { TrackOrder } from "@/components/TrackOrder";
import { CtaBand } from "@/components/CtaBand";
import { Footer } from "@/components/Footer";

export const dynamic = "force-dynamic";

const FAQ_SCHEMA = [
  {
    q: "How fast can I start sending after I order?",
    a: "Card and wallet orders are credited instantly and you can send within about four minutes. Bank transfers activate when funds settle. A brand-new Sender ID adds roughly 24 hours for operator approval in most African and Gulf markets.",
  },
  {
    q: "What exactly counts as one credit?",
    a: "One credit equals one 160-character GSM-7 segment to one number. Longer messages split into 153-character segments and Unicode copy uses UCS-2 at 70 characters per segment. Undelivered messages refund their credits automatically.",
  },
  {
    q: "Do failed messages still cost credits?",
    a: "No. Invalid numbers, dead SIMs and operator rejections refund to your balance automatically, usually within the hour.",
  },
  {
    q: "Which countries do you cover?",
    a: "190+ countries across 680+ direct operator connections, with particularly strong routing in Kenya, Nigeria, Ghana, South Africa, the UAE, India, the UK and the US.",
  },
];

function JsonLd({ ordersPlaced }: { ordersPlaced: number }) {
  const data = {
    "@context": "https://schema.org",
    "@graph": [
      {
        "@type": "Organization",
        "@id": "https://kfyklab.com/#org",
        name: "Kfyklab",
        url: "https://kfyklab.com",
        email: "routes@kfyklab.com",
        telephone: "+254709442118",
        description:
          "Bulk SMS provider with direct carrier routes in 190+ countries, self-serve credit ordering and real-time delivery reporting.",
        aggregateRating: {
          "@type": "AggregateRating",
          ratingValue: "4.9",
          reviewCount: "2318",
        },
      },
      {
        "@type": "Product",
        name: "Kfyklab Bulk SMS Credits",
        category: "Bulk SMS",
        brand: { "@id": "https://kfyklab.com/#org" },
        description:
          "Prepaid bulk SMS credit baskets with direct carrier routing, free Sender ID registration, delivery receipts and automatic refunds on failed messages.",
        offers: PLANS.map((plan) => ({
          "@type": "Offer",
          name: `${plan.name} — ${plan.credits.toLocaleString("en-US")} SMS credits`,
          price: (plan.totalCents / 100).toFixed(2),
          priceCurrency: "USD",
          availability: "https://schema.org/InStock",
          url: "https://kfyklab.com/#pricing",
        })),
      },
      {
        "@type": "FAQPage",
        mainEntity: FAQ_SCHEMA.map((item) => ({
          "@type": "Question",
          name: item.q,
          acceptedAnswer: { "@type": "Answer", text: item.a },
        })),
      },
      {
        "@type": "WebSite",
        url: "https://kfyklab.com",
        name: "Kfyklab",
        potentialAction: {
          "@type": "OrderAction",
          target: "https://kfyklab.com/#pricing",
        },
        interactionStatistic: ordersPlaced,
      },
    ],
  };

  return (
    <script
      type="application/ld+json"
      dangerouslySetInnerHTML={{ __html: JSON.stringify(data) }}
    />
  );
}

export default async function HomePage() {
  const stats = await ensureStats().catch(() => ({
    messagesDelivered: 1_284_530_112,
    ordersPlaced: 0,
    updatedAt: new Date().toISOString(),
  }));

  return (
    <OrderProvider>
      <JsonLd ordersPlaced={stats.ordersPlaced} />
      <Navbar />
      <main id="main">
        <Hero messagesDelivered={stats.messagesDelivered} ordersPlaced={stats.ordersPlaced} />
        <SocialProof />
        <Features />
        <Studio />
        <Network />
        <Benefits />
        <Testimonials />
        <Pricing />
        <Faq />
        <TrackOrder />
        <CtaBand />
      </main>
      <Footer />
    </OrderProvider>
  );
}

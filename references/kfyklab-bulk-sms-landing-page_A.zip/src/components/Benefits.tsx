"use client";

import Image from "next/image";
import { Eyebrow, Reveal, useCountUp, useInView } from "@/components/motion";
import { IconCheck, IconClose, IconGlobe, IconLock, IconPulse, IconWallet } from "@/components/icons";

const COMPARISON = [
  { label: "Route type", us: "Direct tier-1 carrier", them: "Resold grey routes" },
  { label: "Delivery receipt", us: "1.4s median, per operator", them: "Batched, 10–40 min" },
  { label: "Failed messages", us: "Auto-refunded to balance", them: "Charged anyway" },
  { label: "Sender ID registration", us: "Free, filed for you", them: "$40–$120 per operator" },
  { label: "Contract", us: "None — pay per basket", them: "12-month minimum" },
  { label: "Support", us: "Human in 30 min on Orbit+", them: "Ticket queue, 3 days" },
];

const INCLUDED = [
  { icon: IconGlobe, title: "680+ operator connections", copy: "One API, one invoice, every market." },
  { icon: IconPulse, title: "Live delivery analytics", copy: "Per-message receipts and cohort breakdowns." },
  { icon: IconLock, title: "Consent & quiet hours", copy: "Compliance enforced at the queue, not in policy." },
  { icon: IconWallet, title: "Credits that never expire", copy: "Unused balance rolls forward forever." },
];

function Metric({ value, suffix, label, decimals = 0 }: { value: number; suffix?: string; label: string; decimals?: number }) {
  const { ref, inView } = useInView<HTMLDivElement>({ threshold: 0.5 });
  const animated = useCountUp(value, inView, 1700);
  return (
    <div ref={ref}>
      <p className="font-display text-[26px] font-bold leading-none text-mist-50 tabular-nums">
        {animated.toFixed(decimals)}
        {suffix}
      </p>
      <p className="mt-1.5 font-mono text-[10px] tracking-[0.16em] text-mist-500 uppercase">{label}</p>
    </div>
  );
}

export function Benefits() {
  return (
    <section id="benefits" className="relative scroll-mt-24 py-20 sm:py-28">
      <div className="mx-auto w-full max-w-[86rem] px-4 sm:px-6">
        <div className="grid gap-12 lg:grid-cols-[1fr_1.05fr] lg:items-center lg:gap-16">
          {/* visual */}
          <Reveal>
            <div className="relative">
              <div className="noise relative aspect-[4/5] overflow-hidden rounded-[2rem] border border-white/10 sm:aspect-[5/5]">
                <Image
                  src="/images/route-network.jpg"
                  alt="Abstract render of glowing message routes arcing over a night-time city skyline"
                  fill
                  priority={false}
                  sizes="(max-width: 1024px) 100vw, 46vw"
                  className="animate-kenburns object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-ink-950 via-ink-950/25 to-transparent" />

                <div className="absolute inset-x-5 bottom-5 rounded-2xl border border-white/12 bg-ink-950/72 p-5 backdrop-blur-xl">
                  <p className="font-mono text-[10px] tracking-[0.2em] text-signal-300 uppercase">
                    Case study · Zanara Retail
                  </p>
                  <p className="mt-2.5 text-[14px] leading-relaxed text-mist-200">
                    “We replaced three regional aggregators with one Kfyklab basket and cut our
                    cost-per-delivered-message by 41% in the first quarter.”
                  </p>
                  <div className="mt-4 grid grid-cols-3 gap-4 border-t border-white/10 pt-4">
                    <Metric value={41} suffix="%" label="Cost down" />
                    <Metric value={98.7} suffix="%" decimals={1} label="Delivered" />
                    <Metric value={6} suffix=" min" label="Full send" />
                  </div>
                </div>
              </div>

              <div className="glass absolute -right-2 top-8 hidden animate-float rounded-2xl px-4 py-3 sm:block lg:-right-8">
                <p className="font-mono text-[10px] tracking-[0.16em] text-mist-500 uppercase">
                  Saved this quarter
                </p>
                <p className="mt-1 font-display text-[22px] leading-none text-signal-300">$18,420</p>
              </div>
            </div>
          </Reveal>

          {/* copy */}
          <div>
            <Reveal>
              <Eyebrow>Why senders switch</Eyebrow>
            </Reveal>
            <Reveal delay={80}>
              <h2 className="mt-5 font-display text-[clamp(2rem,5vw,3.2rem)] font-bold leading-[1.04] tracking-[-0.035em] text-mist-50">
                The honest maths behind <span className="aqua-text">a cheaper message</span>.
              </h2>
            </Reveal>
            <Reveal delay={140}>
              <p className="mt-5 max-w-xl text-[16px] leading-relaxed text-mist-400">
                Resellers buy wholesale, add a margin, add a Sender ID fee, and bill you for
                messages that never arrived. We publish the rate, file the registration ourselves and
                refund every failure. Here is the difference line by line.
              </p>
            </Reveal>

            <Reveal delay={200}>
              <div className="mt-8 overflow-hidden rounded-2xl border border-white/10">
                <div className="grid grid-cols-[1.15fr_1fr_1fr] gap-2 border-b border-white/10 bg-ink-850/70 px-4 py-3 font-mono text-[10px] tracking-[0.16em] uppercase">
                  <span className="text-mist-500">&nbsp;</span>
                  <span className="text-signal-300">Kfyklab</span>
                  <span className="text-mist-500">Typical reseller</span>
                </div>
                {COMPARISON.map((row, index) => (
                  <div
                    key={row.label}
                    className={`group grid grid-cols-[1.15fr_1fr_1fr] items-center gap-2 px-4 py-3.5 transition-colors duration-300 hover:bg-signal-400/[0.045] ${
                      index % 2 ? "bg-white/[0.015]" : ""
                    }`}
                  >
                    <span className="text-[12.5px] font-medium text-mist-300">{row.label}</span>
                    <span className="flex items-start gap-1.5 text-[12.5px] text-mist-100">
                      <IconCheck
                        className="mt-0.5 size-3.5 shrink-0 text-signal-400 transition-transform duration-300 group-hover:scale-125"
                        strokeWidth={2.6}
                      />
                      {row.us}
                    </span>
                    <span className="flex items-start gap-1.5 text-[12.5px] text-mist-500">
                      <IconClose className="mt-0.5 size-3.5 shrink-0 text-ember-400/70" />
                      {row.them}
                    </span>
                  </div>
                ))}
              </div>
            </Reveal>

            <div className="mt-8 grid gap-3 sm:grid-cols-2">
              {INCLUDED.map((item, index) => (
                <Reveal key={item.title} delay={index * 80}>
                  <div className="group flex h-full items-start gap-3.5 rounded-2xl border border-white/8 bg-ink-900/50 p-4 transition-all duration-400 hover:-translate-y-0.5 hover:border-signal-400/28 hover:bg-signal-400/[0.05]">
                    <span className="grid size-9 shrink-0 place-items-center rounded-xl border border-white/10 bg-white/4 text-signal-300 transition-all duration-400 group-hover:border-signal-400/40 group-hover:bg-signal-400/12">
                      <item.icon className="size-4.5" />
                    </span>
                    <span>
                      <span className="block text-[13.5px] font-semibold text-mist-50">{item.title}</span>
                      <span className="mt-1 block text-[12.5px] leading-relaxed text-mist-500">
                        {item.copy}
                      </span>
                    </span>
                  </div>
                </Reveal>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

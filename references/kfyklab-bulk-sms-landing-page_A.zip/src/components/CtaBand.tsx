"use client";

import { useEffect, useState } from "react";
import { Reveal, useReducedMotion } from "@/components/motion";
import { useOrder } from "@/components/order/OrderContext";
import { IconArrow, IconBolt, IconCheck, IconLock } from "@/components/icons";
import { formatNumber } from "@/lib/plans";

type RecentOrder = {
  orderNumber: string;
  company: string | null;
  customerName: string;
  country: string;
  credits: number;
  planName: string;
  createdAt: string;
};

function timeAgo(iso: string) {
  const diff = Date.now() - new Date(iso).getTime();
  const minutes = Math.round(diff / 60_000);
  if (minutes < 1) return "just now";
  if (minutes < 60) return `${minutes} min ago`;
  const hours = Math.round(minutes / 60);
  if (hours < 24) return `${hours} h ago`;
  return `${Math.round(hours / 24)} d ago`;
}

function OrderTicker() {
  const [orders, setOrders] = useState<RecentOrder[]>([]);
  const [index, setIndex] = useState(0);
  const reduced = useReducedMotion();

  useEffect(() => {
    let alive = true;
    fetch("/api/orders?limit=6")
      .then((r) => r.json())
      .then((data) => {
        if (alive && data?.ok) setOrders(data.orders as RecentOrder[]);
      })
      .catch(() => undefined);
    return () => {
      alive = false;
    };
  }, []);

  useEffect(() => {
    if (reduced || orders.length < 2) return;
    const id = window.setInterval(() => setIndex((i) => (i + 1) % orders.length), 3600);
    return () => window.clearInterval(id);
  }, [orders.length, reduced]);

  if (!orders.length) {
    return (
      <div className="flex items-center gap-3 rounded-2xl border border-white/12 bg-ink-950/45 px-4 py-3 backdrop-blur">
        <span className="size-2 animate-pulse rounded-full bg-signal-400" />
        <span className="font-mono text-[11.5px] text-mist-400">
          Order desk live · accepting baskets now
        </span>
      </div>
    );
  }

  const shown = reduced ? orders.slice(0, 3) : [orders[index % orders.length]];

  return (
    <div className="overflow-hidden rounded-2xl border border-white/12 bg-ink-950/45 px-4 py-3 backdrop-blur">
      <p className="font-mono text-[9.5px] tracking-[0.22em] text-mist-600 uppercase">
        Ordered on Kfyklab
      </p>
      <div className="mt-1.5 space-y-1.5">
        {shown.map((order) => (
          <p key={order.orderNumber} className="animate-rise flex items-center gap-2 text-[12.5px] text-mist-300">
            <span className="size-1.5 shrink-0 rounded-full bg-signal-400" />
            <span className="truncate">
              <span className="text-mist-50">{order.company ?? order.customerName}</span> in{" "}
              {order.country} · {formatNumber(order.credits)} credits ({order.planName})
            </span>
            <span className="ml-auto shrink-0 font-mono text-[10.5px] text-mist-600">
              {timeAgo(order.createdAt)}
            </span>
          </p>
        ))}
      </div>
    </div>
  );
}

export function CtaBand() {
  const { openOrder } = useOrder();

  return (
    <section className="relative px-4 py-20 sm:px-6 sm:py-28">
      <Reveal>
        <div className="noise relative mx-auto w-full max-w-[86rem] overflow-hidden rounded-[2.5rem] border border-white/12 bg-gradient-to-br from-ink-800 via-ink-900 to-ink-950 px-6 py-14 sm:px-12 sm:py-16">
          <div aria-hidden className="pointer-events-none absolute inset-0">
            <div className="absolute -left-24 -top-24 size-[30rem] animate-drift rounded-full bg-signal-500/22 blur-[110px]" />
            <div className="absolute -bottom-32 right-[-6rem] size-[28rem] animate-drift-slow rounded-full bg-pulse-500/18 blur-[120px]" />
            <div className="absolute inset-0 grid-lines opacity-25" />
          </div>

          <div className="relative grid gap-10 lg:grid-cols-[1.1fr_0.9fr] lg:items-center">
            <div>
              <span className="inline-flex items-center gap-2 rounded-full border border-signal-400/30 bg-signal-400/10 px-3.5 py-1.5 font-mono text-[10.5px] tracking-[0.2em] text-signal-200 uppercase">
                <IconBolt className="size-3.5" />
                Checkout is open · credits reserved instantly
              </span>
              <h2 className="mt-6 font-display text-[clamp(2.1rem,5.4vw,3.6rem)] font-extrabold leading-[1.02] tracking-[-0.04em] text-mist-50">
                Your next campaign is{" "}
                <span className="aqua-text">four minutes</span> away.
              </h2>
              <p className="mt-5 max-w-xl text-[16px] leading-relaxed text-mist-300">
                Pick a basket, register your Sender ID and send. If the first delivery rate is not
                what we promised, we will move you to a better route free or refund the balance.
              </p>

              <div className="mt-8 flex flex-col gap-3 sm:flex-row">
                <button
                  type="button"
                  onClick={() => openOrder()}
                  className="shine group relative flex items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-signal-400 to-signal-500 px-7 py-4 text-[15px] font-semibold text-ink-950 shadow-[0_22px_55px_-24px_rgba(56,232,172,0.9)] transition-all duration-300 hover:-translate-y-0.5"
                >
                  <span className="shine-bar" />
                  Order credits now
                  <IconArrow className="size-4 transition-transform duration-300 group-hover:translate-x-1" />
                </button>
                <a
                  href="mailto:routes@kfyklab.com?subject=Route%20consultation"
                  className="flex items-center justify-center gap-2 rounded-2xl border border-white/18 bg-white/5 px-7 py-4 text-[15px] font-semibold text-mist-100 backdrop-blur transition-all duration-300 hover:-translate-y-0.5 hover:border-white/32 hover:bg-white/10"
                >
                  Book a route consultation
                </a>
              </div>

              <ul className="mt-7 flex flex-wrap gap-x-6 gap-y-2">
                {["No contracts", "Credits never expire", "Failures refunded", "PCI-DSS checkout"].map((item) => (
                  <li key={item} className="flex items-center gap-2 text-[12.5px] text-mist-400">
                    <IconCheck className="size-3.5 text-signal-400" strokeWidth={2.6} />
                    {item}
                  </li>
                ))}
              </ul>
            </div>

            <div className="space-y-3">
              <OrderTicker />
              <div className="glass rounded-2xl p-5">
                <div className="flex items-center gap-2 font-mono text-[10px] tracking-[0.2em] text-mist-500 uppercase">
                  <IconLock className="size-3.5 text-signal-300" />
                  Secure order desk
                </div>
                <div className="mt-4 grid grid-cols-3 gap-3">
                  {[
                    ["From", "$180"],
                    ["Rate", "0.9–2.4c"],
                    ["Markets", "190+"],
                  ].map(([k, v]) => (
                    <div key={k}>
                      <p className="font-mono text-[10px] text-mist-600 uppercase">{k}</p>
                      <p className="mt-1 font-display text-[19px] leading-none text-mist-50 tabular-nums">
                        {v}
                      </p>
                    </div>
                  ))}
                </div>
                <p className="mt-4 border-t border-white/8 pt-3 text-[12px] leading-relaxed text-mist-500">
                  Prefer a human? Call{" "}
                  <a href="tel:+254709442118" className="text-signal-300 underline decoration-signal-400/40 underline-offset-4 hover:text-signal-200">
                    +254 709 442 118
                  </a>{" "}
                  and we will price your destination mix on the call.
                </p>
              </div>
            </div>
          </div>
        </div>
      </Reveal>
    </section>
  );
}

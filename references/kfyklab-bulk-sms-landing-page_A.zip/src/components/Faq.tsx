"use client";

import { useState } from "react";
import { Eyebrow, Reveal } from "@/components/motion";
import { IconArrow, IconChat, IconMinus, IconPlus } from "@/components/icons";

const FAQS = [
  {
    q: "How fast can I start sending after I order?",
    a: "Card and wallet orders are credited instantly — you can send within four minutes of checkout. Bank transfers activate the moment funds settle, usually the same business day. If you need a brand-new Sender ID, add 24 hours for operator approval in most African and Gulf markets; UK and EU registered routes are typically instant.",
  },
  {
    q: "What exactly counts as one credit?",
    a: "One credit equals one 160-character GSM-7 segment delivered to one number. Longer messages split into 153-character segments, and Unicode copy (emoji, Arabic, Kiswahili diacritics) uses UCS-2 at 70 characters per segment. The studio shows your segment count and true cost live as you type, and undelivered messages refund their credits automatically.",
  },
  {
    q: "Which countries and networks do you cover?",
    a: "190+ countries across 680+ direct operator connections, with the strongest routing in Kenya, Nigeria, Ghana, South Africa, Uganda, Tanzania, Rwanda, the UAE, Saudi Arabia, India, the UK and the US. If a market matters to you, ask — we publish the per-country rate and historic delivery rate before you commit.",
  },
  {
    q: "Do messages that fail still cost me credits?",
    a: "No. Invalid numbers, dead SIMs, handset-off timeouts and operator rejections refund to your balance automatically, usually within the hour. You only pay for what lands on a handset, which is why our effective cost-per-delivered-message is often 20–40% below a reseller's headline price.",
  },
  {
    q: "Can I run OTP and marketing traffic from one account?",
    a: "Yes, and you should keep them separated by Sender ID and route priority. OTP traffic rides our highest-priority transactional connections with sub-second targets, while promotional campaigns are throttled and respect regional quiet hours. Both share one balance, one dashboard and one invoice.",
  },
  {
    q: "Is there an API? Can you migrate us off our current provider?",
    a: "There is a REST API with signed webhooks, plus SDKs for Node, Python, PHP, Go and Java. Migration is usually a day's work: import your lists, re-register your Sender IDs (we file them for free), and point your code at /v4/send. On Orbit and Atlas we assign an engineer to run the cutover with you and keep your old route warm until the new one proves itself.",
  },
  {
    q: "What payment methods and currencies do you accept?",
    a: "Cards with 3-D Secure, SWIFT and SEPA bank transfers, local rails in select markets, mobile money (M-Pesa, MTN MoMo, Airtel Money) and corporate invoices on net-15 terms with a purchase order. Invoicing is available in USD, KES, NGN, ZAR, AED, GBP and EUR.",
  },
  {
    q: "How do you handle consent, opt-outs and data protection?",
    a: "Every list must be permission-based, and we enforce it technically: STOP/HELP keywords are handled in about 200ms, opted-out numbers are suppressed account-wide, quiet hours are applied per recipient timezone, and every send writes to an immutable audit log. We are GDPR and NDPR aligned, Kenya DPA compliant, and will sign your DPA.",
  },
  {
    q: "What if I need more than two million messages?",
    a: "Order the Atlas basket as a starting point and tell us the real number in the checkout notes. Above two million we price on a private route agreement — usually 0.6–0.9c per message depending on destination mix — with dedicated connections, a named engineer and net-30 terms.",
  },
];

function Item({
  item,
  index,
  open,
  onToggle,
}: {
  item: { q: string; a: string };
  index: number;
  open: boolean;
  onToggle: () => void;
}) {
  const panelId = `faq-panel-${index}`;
  const buttonId = `faq-button-${index}`;
  return (
    <div
      className={`overflow-hidden rounded-2xl border transition-all duration-500 ${
        open
          ? "border-signal-400/35 bg-signal-400/[0.05] shadow-[0_30px_70px_-55px_rgba(56,232,172,0.9)]"
          : "border-white/9 bg-ink-900/45 hover:border-white/20"
      }`}
    >
      <h3>
        <button
          id={buttonId}
          type="button"
          aria-expanded={open}
          aria-controls={panelId}
          onClick={onToggle}
          className="flex w-full items-start gap-4 px-5 py-5 text-left sm:px-6"
        >
          <span className="mt-0.5 font-mono text-[11px] text-mist-600 tabular-nums">
            {String(index + 1).padStart(2, "0")}
          </span>
          <span
            className={`flex-1 font-display text-[16px] font-semibold leading-snug transition-colors duration-300 sm:text-[17.5px] ${
              open ? "text-signal-200" : "text-mist-50"
            }`}
          >
            {item.q}
          </span>
          <span
            className={`grid size-7 shrink-0 place-items-center rounded-full border transition-all duration-500 ${
              open
                ? "rotate-180 border-signal-400/50 bg-signal-400/15 text-signal-300"
                : "border-white/14 text-mist-400"
            }`}
          >
            {open ? <IconMinus className="size-3.5" /> : <IconPlus className="size-3.5" />}
          </span>
        </button>
      </h3>
      <div
        id={panelId}
        role="region"
        aria-labelledby={buttonId}
        className="grid transition-[grid-template-rows] duration-500 [transition-timing-function:var(--ease-out-expo)]"
        style={{ gridTemplateRows: open ? "1fr" : "0fr" }}
      >
        <div className="overflow-hidden">
          <p
            className={`px-5 pb-5 pl-[3.4rem] text-[14.5px] leading-relaxed text-mist-400 transition-opacity duration-400 sm:px-6 sm:pl-[3.9rem] ${
              open ? "opacity-100" : "opacity-0"
            }`}
          >
            {item.a}
          </p>
        </div>
      </div>
    </div>
  );
}

export function Faq() {
  const [open, setOpen] = useState<number | null>(0);

  return (
    <section id="faq" className="relative scroll-mt-24 border-t border-white/6 py-20 sm:py-28">
      <div aria-hidden className="pointer-events-none absolute inset-0 -z-10">
        <div className="absolute left-1/2 top-1/3 h-[24rem] w-[46rem] -translate-x-1/2 rounded-full bg-signal-500/6 blur-[140px]" />
      </div>

      <div className="mx-auto grid w-full max-w-[86rem] gap-12 px-4 sm:px-6 lg:grid-cols-[0.8fr_1.2fr] lg:gap-16">
        <div className="lg:sticky lg:top-28 lg:h-fit">
          <Reveal>
            <Eyebrow>Questions</Eyebrow>
          </Reveal>
          <Reveal delay={80}>
            <h2 className="mt-5 font-display text-[clamp(2rem,4.6vw,3rem)] font-bold leading-[1.04] tracking-[-0.035em] text-mist-50">
              Everything buyers ask <span className="aqua-text">before the first send</span>.
            </h2>
          </Reveal>
          <Reveal delay={140}>
            <p className="mt-5 max-w-md text-[15.5px] leading-relaxed text-mist-400">
              Straight answers, no brochure language. If something is still unclear, a route
              specialist replies in under 30 minutes during business hours.
            </p>
          </Reveal>

          <Reveal delay={200}>
            <div className="glass mt-8 rounded-2xl p-5">
              <div className="flex items-center gap-3">
                <span className="grid size-10 place-items-center rounded-xl bg-signal-400/12 text-signal-300 ring-1 ring-signal-400/25">
                  <IconChat className="size-5" />
                </span>
                <span>
                  <span className="block text-[14px] font-semibold text-mist-50">Talk to a human</span>
                  <span className="block font-mono text-[11px] text-mist-500">
                    routes@kfyklab.com · +254 709 442 118
                  </span>
                </span>
              </div>
              <a
                href="mailto:routes@kfyklab.com?subject=Bulk%20SMS%20route%20question"
                className="group mt-4 flex items-center justify-between rounded-xl border border-white/12 bg-white/5 px-4 py-3 text-[13.5px] font-medium text-mist-100 transition hover:border-signal-400/45 hover:bg-signal-400/10 hover:text-signal-200"
              >
                Ask about your destination mix
                <IconArrow className="size-4 transition-transform duration-300 group-hover:translate-x-1" />
              </a>
            </div>
          </Reveal>
        </div>

        <div className="space-y-3">
          {FAQS.map((item, index) => (
            <Reveal key={item.q} delay={Math.min(index * 60, 300)}>
              <Item
                item={item}
                index={index}
                open={open === index}
                onToggle={() => setOpen(open === index ? null : index)}
              />
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

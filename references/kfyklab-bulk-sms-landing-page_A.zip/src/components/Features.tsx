"use client";

import { useState } from "react";
import { Eyebrow, Reveal, useReducedMotion, useSpotlight } from "@/components/motion";
import {
  IconAudience,
  IconCalendar,
  IconCheck,
  IconCode,
  IconGlobe,
  IconPulse,
  IconRoute,
  IconShield,
  IconSparkle,
} from "@/components/icons";

function Card({
  children,
  className = "",
  delay = 0,
}: {
  children: React.ReactNode;
  className?: string;
  delay?: number;
}) {
  const { ref, onPointerMove } = useSpotlight<HTMLDivElement>();
  return (
    <Reveal delay={delay} className={className}>
      <div
        ref={ref}
        onPointerMove={onPointerMove}
        className="spotlight glass group relative h-full overflow-hidden rounded-3xl p-6 transition-transform duration-500 hover:-translate-y-1 sm:p-7"
      >
        {children}
      </div>
    </Reveal>
  );
}

function CardTitle({ icon: Icon, title, copy }: { icon: typeof IconRoute; title: string; copy: string }) {
  return (
    <>
      <span className="grid size-11 place-items-center rounded-2xl border border-signal-400/22 bg-signal-400/10 text-signal-300 transition-all duration-500 group-hover:scale-105 group-hover:border-signal-400/45 group-hover:bg-signal-400/16">
        <Icon className="size-5" />
      </span>
      <h3 className="mt-5 font-display text-[19px] leading-snug text-mist-50 sm:text-[21px]">{title}</h3>
      <p className="mt-2.5 text-[14.5px] leading-relaxed text-mist-400">{copy}</p>
    </>
  );
}

function RouteDiagram() {
  const reduced = useReducedMotion();
  const carriers = [
    { name: "Safaricom", y: 26 },
    { name: "MTN", y: 62 },
    { name: "Vodafone", y: 98 },
    { name: "Airtel", y: 134 },
  ];
  return (
    <svg viewBox="0 0 320 160" className="mt-6 h-auto w-full" role="img" aria-label="Messages route from Kfyklab through direct carrier connections to handsets">
      <defs>
        <linearGradient id="route-line" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0" stopColor="#38E8AC" stopOpacity="0.05" />
          <stop offset="0.5" stopColor="#38E8AC" stopOpacity="0.75" />
          <stop offset="1" stopColor="#4CC4F0" stopOpacity="0.15" />
        </linearGradient>
        <radialGradient id="hub-glow">
          <stop offset="0" stopColor="#38E8AC" stopOpacity="0.45" />
          <stop offset="1" stopColor="#38E8AC" stopOpacity="0" />
        </radialGradient>
      </defs>

      <circle cx="150" cy="80" r="46" fill="url(#hub-glow)" />
      <rect x="112" y="56" width="76" height="48" rx="14" fill="#0A0E15" stroke="#38E8AC" strokeOpacity="0.4" />
      <text x="150" y="77" textAnchor="middle" fill="#F5F8FA" fontSize="11" fontFamily="JetBrains Mono, monospace">
        KFYKLAB
      </text>
      <text x="150" y="92" textAnchor="middle" fill="#7BF7D0" fontSize="8.5" fontFamily="JetBrains Mono, monospace">
        ROUTER v4
      </text>

      {carriers.map((carrier, index) => (
        <g key={carrier.name}>
          <path
            d={`M78 ${carrier.y} C 96 ${carrier.y}, 96 80, 112 80`}
            stroke="url(#route-line)"
            strokeWidth="1.4"
            fill="none"
            strokeDasharray="4 5"
          />
          <rect x="6" y={carrier.y - 11} width="72" height="22" rx="7" fill="#0E131B" stroke="#FFFFFF" strokeOpacity="0.1" />
          <text x="42" y={carrier.y + 4} textAnchor="middle" fill="#A6B3C1" fontSize="9" fontFamily="Plus Jakarta Sans, sans-serif">
            {carrier.name}
          </text>
          {!reduced && (
            <circle r="2.6" fill="#7BF7D0">
              <animateMotion
                dur={`${2.4 + index * 0.35}s`}
                repeatCount="indefinite"
                begin={`${index * 0.5}s`}
                path={`M78 ${carrier.y} C 96 ${carrier.y}, 96 80, 112 80`}
              />
            </circle>
          )}
        </g>
      ))}

      <path d="M188 80 C 214 80, 214 44, 244 44" stroke="url(#route-line)" strokeWidth="1.4" fill="none" strokeDasharray="4 5" />
      <path d="M188 80 C 214 80, 214 116, 244 116" stroke="url(#route-line)" strokeWidth="1.4" fill="none" strokeDasharray="4 5" />
      {[44, 116].map((y, i) => (
        <g key={y}>
          <rect x="244" y={y - 15} width="62" height="30" rx="9" fill="#0A0E15" stroke="#FFFFFF" strokeOpacity="0.12" />
          <text x="275" y={y - 1} textAnchor="middle" fill="#F5F8FA" fontSize="9.5" fontFamily="JetBrains Mono, monospace">
            DLR
          </text>
          <text x="275" y={y + 10} textAnchor="middle" fill={i === 0 ? "#7BF7D0" : "#8EE0FF"} fontSize="8" fontFamily="JetBrains Mono, monospace">
            {i === 0 ? "DELIVERED" : "0.9s"}
          </text>
          {!reduced && (
            <circle r="2.6" fill="#4CC4F0">
              <animateMotion
                dur="2.1s"
                repeatCount="indefinite"
                begin={`${i * 0.7}s`}
                path={`M188 80 C 214 80, 214 ${y}, 244 ${y}`}
              />
            </circle>
          )}
        </g>
      ))}
    </svg>
  );
}

const CODE = `curl https://api.kfyklab.com/v4/send \\
  -H "Authorization: Bearer $KFYK_KEY" \\
  -d sender_id=ZANARA \\
  -d message="40% off till midnight" \\
  -d recipients=@list.csv \\
  -d callback="https://you.co/dlr"`;

function CodeCard() {
  const [copied, setCopied] = useState(false);
  const copy = async () => {
    try {
      await navigator.clipboard.writeText(CODE);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1800);
    } catch {
      setCopied(false);
    }
  };
  return (
    <Card delay={120} className="lg:col-span-4">
      <div className="flex items-start justify-between gap-4">
        <div>
          <CardTitle
            icon={IconCode}
            title="Ship from your own stack in one call"
            copy="A tidy REST API, signed webhooks, and SDKs for Node, Python, PHP, Go and Java. Batch 100,000 numbers per request and stream receipts back as they land."
          />
        </div>
      </div>
      <div className="relative mt-6 overflow-hidden rounded-2xl border border-white/10 bg-ink-950/80">
        <div className="flex items-center justify-between border-b border-white/8 px-4 py-2.5">
          <span className="flex items-center gap-1.5">
            <span className="size-2.5 rounded-full bg-ember-400/70" />
            <span className="size-2.5 rounded-full bg-signal-400/60" />
            <span className="size-2.5 rounded-full bg-pulse-400/60" />
            <span className="ml-2 font-mono text-[10.5px] text-mist-500">send.sh</span>
          </span>
          <button
            type="button"
            onClick={copy}
            className="rounded-lg border border-white/10 px-2.5 py-1 font-mono text-[10.5px] text-mist-400 transition hover:border-signal-400/45 hover:text-signal-300"
          >
            {copied ? "copied ✓" : "copy"}
          </button>
        </div>
        <pre className="overflow-x-auto px-4 py-4 font-mono text-[11.5px] leading-relaxed text-mist-300 sm:text-[12.5px]">
          <code>
            {CODE.split("\n").map((line, i) => (
              <span key={i} className="block whitespace-pre">
                <span className="mr-3 inline-block w-4 select-none text-right text-mist-600">{i + 1}</span>
                <span className={line.startsWith("curl") ? "text-signal-300" : line.startsWith("  -") ? "text-pulse-300" : "text-mist-400"}>
                  {line}
                </span>
              </span>
            ))}
          </code>
        </pre>
      </div>
    </Card>
  );
}

export function Features() {
  return (
    <section id="platform" className="relative scroll-mt-24 py-20 sm:py-28">
      <div aria-hidden className="pointer-events-none absolute inset-0 -z-10">
        <div className="absolute left-1/2 top-10 h-[26rem] w-[52rem] -translate-x-1/2 rounded-full bg-signal-500/6 blur-[130px]" />
      </div>

      <div className="mx-auto w-full max-w-[86rem] px-4 sm:px-6">
        <div className="max-w-3xl">
          <Reveal>
            <Eyebrow>The platform</Eyebrow>
          </Reveal>
          <Reveal delay={90}>
            <h2 className="mt-5 font-display text-[clamp(2rem,5vw,3.3rem)] font-bold leading-[1.03] tracking-[-0.035em] text-mist-50">
              Everything between your list and <span className="aqua-text">their lock screen</span>.
            </h2>
          </Reveal>
          <Reveal delay={160}>
            <p className="mt-5 max-w-2xl text-[16px] leading-relaxed text-mist-400">
              No reseller chains, no mystery routes. You buy credits, we handle carrier handshakes,
              throttling, retries, compliance and reporting — so your team just writes the message.
            </p>
          </Reveal>
        </div>

        <div className="mt-12 grid gap-4 lg:grid-cols-6">
          <Card className="lg:col-span-4">
            <CardTitle
              icon={IconRoute}
              title="Direct carrier routes — never a grey hop"
              copy="We hold our own connections with tier-1 operators and aggregators in every market we serve. Fewer hops means fewer silent failures, faster receipts, and sender IDs that stay whitelisted."
            />
            <RouteDiagram />
            <div className="mt-4 flex flex-wrap gap-2">
              {["No SMPP sharing", "Carrier-grade throughput", "Automatic failover"].map((chip) => (
                <span
                  key={chip}
                  className="rounded-full border border-white/10 bg-white/4 px-3 py-1 font-mono text-[10.5px] text-mist-300"
                >
                  {chip}
                </span>
              ))}
            </div>
          </Card>

          <Card delay={80} className="lg:col-span-2">
            <CardTitle
              icon={IconSparkle}
              title="Sender ID registered in 24 hours"
              copy="Submit your brand name once; we file it with each operator and track approval status for you."
            />
            <ul className="mt-5 space-y-2.5">
              {["Free on every plan", "Alphanumeric up to 11 chars", "Status tracked per operator"].map((item) => (
                <li key={item} className="flex items-start gap-2 text-[13.5px] text-mist-300">
                  <IconCheck className="mt-0.5 size-3.5 shrink-0 text-signal-400" strokeWidth={2.4} />
                  {item}
                </li>
              ))}
            </ul>
          </Card>

          <Card delay={60} className="lg:col-span-2">
            <CardTitle
              icon={IconPulse}
              title="Receipts in under two seconds"
              copy="Every message carries a delivery receipt, error code and latency figure, streamed to your webhook."
            />
            <div className="mt-5 space-y-2 font-mono text-[11px]">
              {[
                { s: "DELIVERED", c: "text-signal-300 bg-signal-400/10", w: "99.2%" },
                { s: "FAILED · invalid", c: "text-ember-300 bg-ember-400/10", w: "0.4%" },
                { s: "PENDING · retry", c: "text-pulse-300 bg-pulse-400/10", w: "0.4%" },
              ].map((row) => (
                <div key={row.s} className="flex items-center gap-2">
                  <span className={`rounded-md px-2 py-1 ${row.c}`}>{row.s}</span>
                  <span className="h-1 flex-1 overflow-hidden rounded-full bg-white/8">
                    <span
                      className="block h-full rounded-full bg-current opacity-70 transition-[width] duration-700"
                      style={{ width: row.w }}
                    />
                  </span>
                </div>
              ))}
            </div>
          </Card>

          <CodeCard />

          <Card delay={60} className="lg:col-span-3">
            <CardTitle
              icon={IconAudience}
              title="Audiences that behave like a database"
              copy="Import CSVs, sync from your CRM, tag by behaviour and personalise with merge tags — then exclude anyone who opted out, automatically."
            />
            <div className="mt-5 flex flex-wrap gap-2">
              {["{{first_name}}", "{{order_id}}", "{{balance}}", "segment: VIP", "suppressed: 1,204"].map((tag) => (
                <span
                  key={tag}
                  className="rounded-lg border border-white/10 bg-ink-950/60 px-2.5 py-1.5 font-mono text-[11px] text-mist-300 transition hover:border-signal-400/40 hover:text-signal-300"
                >
                  {tag}
                </span>
              ))}
            </div>
          </Card>

          <Card delay={120} className="lg:col-span-3">
            <CardTitle
              icon={IconCalendar}
              title="Schedule, throttle and never get throttled yourself"
              copy="Send at a local time that suits each region, cap messages per second so your support line does not melt, and auto-pause on abnormal bounce rates."
            />
            <div className="mt-6 flex items-end gap-1.5">
              {[38, 52, 44, 68, 74, 58, 86, 92, 70, 64, 80, 96].map((h, i) => (
                <span
                  key={i}
                  className="flex-1 rounded-t-md bg-gradient-to-t from-signal-500/25 to-signal-400/80 transition-all duration-500 hover:from-pulse-500/30 hover:to-pulse-400/90"
                  style={{ height: `${h * 0.42}px` }}
                />
              ))}
            </div>
            <p className="mt-2 font-mono text-[10px] tracking-[0.16em] text-mist-600 uppercase">
              Send volume · last 12 hours
            </p>
          </Card>

          <Card delay={80} className="lg:col-span-6">
            <div className="grid gap-6 lg:grid-cols-[0.9fr_1.1fr] lg:items-center">
              <CardTitle
                icon={IconShield}
                title="Compliance handled before the regulator calls"
                copy="Consent flags, quiet hours, per-country templates, mandatory STOP keywords and a full audit trail on every send. GDPR, NDPR and Kenya DPA aligned, with a DPA we will actually sign."
              />
              <div className="grid gap-3 sm:grid-cols-2">
                {[
                  { icon: IconGlobe, t: "Quiet hours by timezone", d: "Nobody gets a promo at 3am." },
                  { icon: IconShield, t: "Consent & audit log", d: "7-year immutable retention." },
                  { icon: IconCheck, t: "STOP / HELP keywords", d: "Auto-suppression in 200ms." },
                  { icon: IconPulse, t: "Anomaly circuit breaker", d: "Pauses on spike in bounces." },
                ].map((item) => (
                  <div
                    key={item.t}
                    className="flex items-start gap-3 rounded-2xl border border-white/8 bg-ink-950/40 p-3.5 transition hover:border-signal-400/28 hover:bg-signal-400/5"
                  >
                    <item.icon className="mt-0.5 size-4.5 shrink-0 text-signal-300" />
                    <span>
                      <span className="block text-[13.5px] font-semibold text-mist-100">{item.t}</span>
                      <span className="mt-0.5 block text-[12.5px] text-mist-500">{item.d}</span>
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </Card>
        </div>
      </div>
    </section>
  );
}

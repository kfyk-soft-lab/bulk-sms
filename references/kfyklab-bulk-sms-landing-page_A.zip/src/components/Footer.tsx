"use client";

import { useState } from "react";
import { useOrder } from "@/components/order/OrderContext";
import { IconArrow, IconChat, IconCheck, LogoMark } from "@/components/icons";

const COLUMNS: { title: string; links: { label: string; href: string; action?: boolean }[] }[] = [
  {
    title: "Platform",
    links: [
      { label: "Direct routes", href: "#platform" },
      { label: "Campaign studio", href: "#studio" },
      { label: "Live network", href: "#network" },
      { label: "Customer proof", href: "#testimonials" },
    ],
  },
  {
    title: "Buy",
    links: [
      { label: "Pricing & baskets", href: "#pricing" },
      { label: "Order credits", href: "#order", action: true },
      { label: "Track an order", href: "#track" },
      { label: "Operations dashboard", href: "/orders" },
    ],
  },
  {
    title: "Company",
    links: [
      { label: "Why senders switch", href: "#benefits" },
      { label: "FAQ", href: "#faq" },
      { label: "routes@kfyklab.com", href: "mailto:routes@kfyklab.com" },
      { label: "+254 709 442 118", href: "tel:+254709442118" },
    ],
  },
  {
    title: "Legal",
    links: [
      { label: "Acceptable use", href: "/legal/acceptable-use" },
      { label: "Privacy notice", href: "/legal/privacy" },
      { label: "Terms of service", href: "/legal/terms" },
      { label: "Data processing addendum", href: "/legal/dpa" },
    ],
  },
];

function SocialMark({ label, href, children }: { label: string; href: string; children: React.ReactNode }) {
  return (
    <a
      href={href}
      aria-label={label}
      className="grid size-10 place-items-center rounded-xl border border-white/10 bg-white/4 font-display text-[12px] font-bold text-mist-300 transition-all duration-400 hover:-translate-y-0.5 hover:border-signal-400/45 hover:bg-signal-400/12 hover:text-signal-200"
    >
      {children}
    </a>
  );
}

export function Footer() {
  const { openOrder } = useOrder();
  const [email, setEmail] = useState("");
  const [subscribed, setSubscribed] = useState(false);

  return (
    <footer className="relative overflow-hidden border-t border-white/8 bg-ink-900/60">
      <div aria-hidden className="pointer-events-none absolute inset-0 -z-10">
        <div className="absolute left-1/2 top-[-40%] h-[34rem] w-[64rem] -translate-x-1/2 rounded-full bg-signal-500/8 blur-[150px]" />
      </div>

      <div className="mx-auto w-full max-w-[86rem] px-4 py-16 sm:px-6">
        <div className="grid gap-10 lg:grid-cols-[1.15fr_1.85fr]">
          <div>
            <div className="flex items-center gap-3">
              <LogoMark className="size-11" />
              <span>
                <span className="block font-display text-[20px] font-extrabold tracking-[-0.03em] text-mist-50">
                  Kfyklab
                </span>
                <span className="block font-mono text-[9.5px] tracking-[0.28em] text-mist-500 uppercase">
                  Bulk SMS · since 2019
                </span>
              </span>
            </div>
            <p className="mt-5 max-w-sm text-[14px] leading-relaxed text-mist-400">
              The order desk for high-deliverability bulk SMS. Direct carrier routes in 190+
              countries, priced per message, settled in minutes.
            </p>

            <div className="mt-7 rounded-2xl border border-white/10 bg-ink-950/45 p-5">
              <p className="font-mono text-[10px] tracking-[0.2em] text-mist-500 uppercase">
                Route status alerts
              </p>
              <p className="mt-2 text-[13px] leading-relaxed text-mist-400">
                One email when a market you send to changes rate or latency. No marketing, ever.
              </p>
              {subscribed ? (
                <p className="mt-4 flex items-center gap-2 rounded-xl border border-signal-400/30 bg-signal-400/10 px-3.5 py-3 text-[13px] text-signal-200">
                  <IconCheck className="size-4" strokeWidth={2.4} />
                  You are on the list — confirmation sent.
                </p>
              ) : (
                <form
                  className="mt-4 flex flex-col gap-2 sm:flex-row"
                  onSubmit={(event) => {
                    event.preventDefault();
                    if (/^[^\s@]+@[^\s@]+\.[a-z]{2,}$/i.test(email.trim())) setSubscribed(true);
                  }}
                >
                  <label className="sr-only" htmlFor="footer-email">
                    Email address
                  </label>
                  <input
                    id="footer-email"
                    type="email"
                    required
                    className="field flex-1"
                    placeholder="you@company.com"
                    value={email}
                    onChange={(event) => setEmail(event.target.value)}
                  />
                  <button
                    type="submit"
                    className="group flex items-center justify-center gap-1.5 rounded-xl border border-white/14 bg-white/5 px-4 py-3 text-[13px] font-semibold text-mist-100 transition hover:border-signal-400/45 hover:bg-signal-400/12 hover:text-signal-200"
                  >
                    Subscribe
                    <IconArrow className="size-3.5 transition-transform group-hover:translate-x-0.5" />
                  </button>
                </form>
              )}
            </div>
          </div>

          <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
            {COLUMNS.map((column) => (
              <nav key={column.title} aria-label={column.title}>
                <p className="font-mono text-[10px] tracking-[0.2em] text-mist-600 uppercase">
                  {column.title}
                </p>
                <ul className="mt-4 space-y-2.5">
                  {column.links.map((link) => (
                    <li key={link.label}>
                      {link.action ? (
                        <button
                          type="button"
                          onClick={() => openOrder()}
                          className="group inline-flex items-center gap-1.5 text-left text-[13.5px] text-mist-300 transition-colors hover:text-signal-300"
                        >
                          <span className="relative">
                            {link.label}
                            <span className="absolute -bottom-0.5 left-0 h-px w-full origin-right scale-x-0 bg-signal-400 transition-transform duration-400 group-hover:origin-left group-hover:scale-x-100" />
                          </span>
                          <IconArrow className="size-3.5 opacity-0 transition-all duration-300 group-hover:translate-x-0.5 group-hover:opacity-100" />
                        </button>
                      ) : (
                        <a
                          href={link.href}
                          className="group inline-block text-[13.5px] text-mist-300 transition-colors hover:text-signal-300"
                        >
                          <span className="relative">
                            {link.label}
                            <span className="absolute -bottom-0.5 left-0 h-px w-full origin-right scale-x-0 bg-signal-400 transition-transform duration-400 group-hover:origin-left group-hover:scale-x-100" />
                          </span>
                        </a>
                      )}
                    </li>
                  ))}
                </ul>
              </nav>
            ))}
          </div>
        </div>

        {/* oversized wordmark */}
        <div className="mask-fade-x mt-14 overflow-hidden">
          <p
            aria-hidden
            className="select-none whitespace-nowrap text-center font-display text-[clamp(3.5rem,17vw,13rem)] font-extrabold leading-none tracking-[-0.05em] text-transparent"
            style={{
              backgroundImage:
                "linear-gradient(100deg, rgba(123,247,208,0.22), rgba(56,232,172,0.5) 35%, rgba(76,196,240,0.32) 65%, rgba(255,179,92,0.2))",
              WebkitBackgroundClip: "text",
              backgroundClip: "text",
            }}
          >
            KFYKLAB · SEND IT
          </p>
        </div>

        <div className="mt-10 flex flex-col gap-5 border-t border-white/8 pt-7 lg:flex-row lg:items-center lg:justify-between">
          <p className="font-mono text-[11px] text-mist-600">
            © {new Date().getFullYear()} Kfyklab Ltd · Nairobi · Dubai · London
          </p>

          <div className="flex flex-wrap items-center gap-4">
            <span className="flex items-center gap-2 rounded-full border border-signal-400/25 bg-signal-400/8 px-3 py-1.5 font-mono text-[10.5px] text-signal-200">
              <span className="relative flex size-2">
                <span className="absolute inline-flex size-full animate-ping rounded-full bg-signal-400 opacity-70" />
                <span className="relative inline-flex size-2 rounded-full bg-signal-400" />
              </span>
              All 680 routes nominal
            </span>
            <div className="flex items-center gap-2">
              <SocialMark label="Kfyklab on X" href="https://x.com/kfyklab">
                <svg viewBox="0 0 24 24" className="size-3.5" aria-hidden fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
                  <path d="M4.5 4.5 19.5 19.5M19.5 4.5 4.5 19.5" />
                </svg>
              </SocialMark>
              <SocialMark label="Kfyklab on LinkedIn" href="https://www.linkedin.com/company/kfyklab">
                <svg viewBox="0 0 24 24" className="size-3.5" aria-hidden fill="currentColor">
                  <rect x="4" y="9.5" width="3" height="10" rx="0.6" />
                  <circle cx="5.5" cy="5.6" r="1.8" />
                  <path d="M11 9.5h3v1.6c.7-1.1 1.9-1.9 3.4-1.9 2.4 0 3.6 1.6 3.6 4.4v5.9h-3v-5.3c0-1.5-.5-2.3-1.7-2.3-1.1 0-1.8.8-1.8 2.3v5.3h-3.5Z" />
                </svg>
              </SocialMark>
              <SocialMark label="Talk to Kfyklab support" href="mailto:routes@kfyklab.com">
                <IconChat className="size-4" />
              </SocialMark>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}

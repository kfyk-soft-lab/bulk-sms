"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { useOrder } from "@/components/order/OrderContext";
import { useReducedMotion } from "@/components/motion";
import { IconArrow, IconBolt, IconCheck, IconPulse, IconShield } from "@/components/icons";
import { formatMoney } from "@/lib/plans";
import { PLANS } from "@/lib/plans";

const SCRIPT = [
  { from: "ZANARA", text: "Amara, your 40% flash-sale code ZAN40 is live till midnight → zanara.co", tag: "Promo" },
  { from: "PAYLENT", text: "Your one-time code is 481-220. It expires in 5 minutes.", tag: "OTP" },
  { from: "BLOOM", text: "Reminder: dental check-up tomorrow 10:30. Reply C to confirm.", tag: "Reminder" },
];

const cheapest = PLANS[0].totalCents;

function LivePhone() {
  const reduced = useReducedMotion();
  const [index, setIndex] = useState(0);
  const [typed, setTyped] = useState("");
  const [state, setState] = useState<"typing" | "sent" | "delivered">("typing");
  const [sent, setSent] = useState(38_412);
  const timer = useRef<number | null>(null);

  const current = SCRIPT[index % SCRIPT.length];

  useEffect(() => {
    if (reduced) {
      setTyped(current.text);
      setState("delivered");
      return;
    }
    setTyped("");
    setState("typing");
    let char = 0;
    const typing = window.setInterval(() => {
      char += 1;
      setTyped(current.text.slice(0, char));
      if (char >= current.text.length) {
        window.clearInterval(typing);
        setState("sent");
        timer.current = window.setTimeout(() => setState("delivered"), 700);
        timer.current = window.setTimeout(() => setIndex((i) => i + 1), 3200);
      }
    }, 22);
    return () => {
      window.clearInterval(typing);
      if (timer.current) window.clearTimeout(timer.current);
    };
  }, [index, current.text, reduced]);

  useEffect(() => {
    if (reduced) return;
    const id = window.setInterval(() => setSent((s) => s + Math.floor(Math.random() * 90) + 24), 320);
    return () => window.clearInterval(id);
  }, [reduced]);

  return (
    <div className="relative mx-auto w-full max-w-[22rem]">
      {/* handset */}
      <div className="relative rounded-[2.4rem] border border-white/12 bg-gradient-to-b from-ink-750 to-ink-950 p-2.5 shadow-[0_50px_120px_-40px_rgba(0,0,0,0.95),0_0_0_1px_rgba(255,255,255,0.04)_inset]">
        <div className="relative overflow-hidden rounded-[1.9rem] bg-ink-900">
          {/* status bar */}
          <div className="flex items-center justify-between px-5 pb-2 pt-3.5">
            <span className="font-mono text-[10.5px] text-mist-400">9:41</span>
            <span className="absolute left-1/2 top-2.5 h-5 w-20 -translate-x-1/2 rounded-full bg-ink-950" />
            <span className="flex items-center gap-1 font-mono text-[10.5px] text-mist-400">
              <IconPulse className="size-3.5 text-signal-400" />
              DLR
            </span>
          </div>

          {/* header */}
          <div className="flex items-center justify-between border-b border-white/8 px-4 py-3">
            <div>
              <p className="font-display text-[14px] text-mist-50">Campaign monitor</p>
              <p className="font-mono text-[10px] tracking-[0.16em] text-mist-500 uppercase">
                {current.tag} · live
              </p>
            </div>
            <span className="relative grid size-8 place-items-center rounded-full bg-signal-400/12 ring-1 ring-signal-400/30">
              <span className="absolute inset-0 animate-ring rounded-full border border-signal-400/50" />
              <IconBolt className="size-4 text-signal-300" />
            </span>
          </div>

          {/* message stream */}
          <div className="space-y-3 px-4 py-5">
            <div className="flex items-end gap-2">
              <div className="max-w-[86%] rounded-2xl rounded-bl-sm bg-gradient-to-br from-signal-400/18 to-pulse-400/10 px-3.5 py-3 ring-1 ring-signal-400/22">
                <span className="mb-1 block font-mono text-[10px] tracking-[0.2em] text-signal-300 uppercase">
                  {current.from}
                </span>
                <p className="text-[13px] leading-relaxed text-mist-100">
                  {typed}
                  {!reduced && state === "typing" && (
                    <span className="ml-0.5 inline-block h-3.5 w-[2px] translate-y-0.5 animate-caret bg-signal-300" />
                  )}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2 pl-1">
              <span
                className={`flex items-center gap-1 rounded-full px-2 py-0.5 font-mono text-[10px] transition-all duration-500 ${
                  state === "delivered"
                    ? "bg-signal-400/15 text-signal-300"
                    : "bg-white/6 text-mist-500"
                }`}
              >
                <IconCheck className="size-2.5" strokeWidth={3} />
                {state === "delivered" ? "Delivered" : state === "sent" ? "Sent" : "Queued"}
              </span>
              <span className="font-mono text-[10px] text-mist-600">
                {state === "delivered" ? "0.9s" : "—"}
              </span>
            </div>

            {/* throughput meter */}
            <div className="mt-4 rounded-2xl border border-white/8 bg-ink-850/80 p-3.5">
              <div className="flex items-baseline justify-between">
                <span className="font-mono text-[10px] tracking-[0.16em] text-mist-500 uppercase">
                  Dispatched
                </span>
                <span className="font-mono text-[13px] text-mist-50 tabular-nums">
                  {sent.toLocaleString("en-US")}
                </span>
              </div>
              <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-white/8">
                <div
                  className="h-full rounded-full bg-gradient-to-r from-signal-400 to-pulse-400 transition-[width] duration-500"
                  style={{ width: `${Math.min(96, (sent / 60_000) * 100)}%` }}
                />
              </div>
              <div className="mt-2.5 flex justify-between font-mono text-[10px] text-mist-500">
                <span>1,200 msg/s</span>
                <span>99.2% DLR</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* floating chips */}
      <div className="pointer-events-none absolute -left-6 top-16 hidden animate-float-soft sm:block">
        <div className="glass flex items-center gap-2.5 rounded-2xl px-3.5 py-2.5">
          <span className="grid size-8 place-items-center rounded-xl bg-signal-400/15 text-signal-300">
            <IconShield className="size-4" />
          </span>
          <span>
            <span className="block font-mono text-[10px] tracking-wider text-mist-500 uppercase">
              Filtered
            </span>
            <span className="block text-[13px] font-semibold text-mist-50">0 spam flags</span>
          </span>
        </div>
      </div>
      <div className="pointer-events-none absolute -right-4 bottom-20 hidden animate-float sm:block">
        <div className="glass rounded-2xl px-3.5 py-3">
          <span className="block font-mono text-[10px] tracking-wider text-mist-500 uppercase">
            Cost / 1,000
          </span>
          <span className="mt-0.5 block font-display text-[18px] text-signal-300">$12.00</span>
          <span className="mt-0.5 flex items-center gap-1 font-mono text-[10px] text-mist-500">
            <IconArrow className="size-3 rotate-[-45deg]" /> Orbit route
          </span>
        </div>
      </div>
    </div>
  );
}

function MaskLine({ children, delay }: { children: React.ReactNode; delay: number }) {
  return (
    <span className="block overflow-hidden pb-[0.12em]">
      <span
        className="block animate-rise"
        style={{ animationDelay: `${delay}ms`, animationDuration: "900ms" }}
      >
        {children}
      </span>
    </span>
  );
}

export function Hero({ messagesDelivered, ordersPlaced }: { messagesDelivered: number; ordersPlaced: number }) {
  const { openOrder } = useOrder();
  const delivered = useMemo(
    () => new Intl.NumberFormat("en-US").format(messagesDelivered),
    [messagesDelivered],
  );

  return (
    <section id="top" className="noise relative overflow-hidden pb-20 pt-28 sm:pb-28 sm:pt-32 lg:pb-32">
      {/* ambient background */}
      <div aria-hidden className="pointer-events-none absolute inset-0 -z-10">
        <div className="absolute inset-0 grid-lines mask-fade-b opacity-[0.5]" />
        <div className="absolute -left-[18%] top-[-14%] size-[42rem] animate-drift rounded-full bg-signal-500/20 blur-[130px]" />
        <div className="absolute right-[-12%] top-[6%] size-[34rem] animate-drift-slow rounded-full bg-pulse-500/16 blur-[120px]" />
        <div className="absolute bottom-[-18%] left-[28%] size-[30rem] animate-drift rounded-full bg-ember-500/8 blur-[140px] [animation-delay:-8s]" />
        <div className="absolute inset-x-0 bottom-0 h-40 bg-gradient-to-b from-transparent to-ink-950" />
      </div>

      <div className="mx-auto grid w-full max-w-[86rem] items-center gap-14 px-4 sm:px-6 lg:grid-cols-[1.05fr_0.95fr] lg:gap-8">
        {/* copy */}
        <div className="relative">
          <div
            className="animate-rise inline-flex items-center gap-2.5 rounded-full border border-white/10 bg-white/4 py-1.5 pl-1.5 pr-4 backdrop-blur"
            style={{ animationDelay: "60ms" }}
          >
            <span className="rounded-full bg-signal-400/15 px-2.5 py-1 font-mono text-[10px] tracking-[0.16em] text-signal-300 uppercase">
              v4 routes live
            </span>
            <span className="text-[12.5px] text-mist-300">
              Direct carrier connections in 190+ countries
            </span>
          </div>

          <h1 className="mt-6 font-display text-[clamp(2.6rem,7.2vw,4.6rem)] font-extrabold leading-[0.98] tracking-[-0.04em] text-mist-50">
            <MaskLine delay={140}>Bulk SMS that</MaskLine>
            <MaskLine delay={250}>
              lands in the <span className="aqua-text">pocket</span>,
            </MaskLine>
            <MaskLine delay={360}>not the spam folder.</MaskLine>
          </h1>

          <p
            className="animate-rise mt-6 max-w-xl text-[16.5px] leading-relaxed text-mist-300 sm:text-[17.5px]"
            style={{ animationDelay: "480ms" }}
          >
            Kfyklab is the order desk for serious senders. Pick a credit basket, register your
            Sender ID, upload your list and watch delivery reports stream in — priced per message,
            settled in minutes, no lock-in contracts.
          </p>

          <div
            className="animate-rise mt-8 flex flex-col gap-3 sm:flex-row sm:items-center"
            style={{ animationDelay: "580ms" }}
          >
            <button
              type="button"
              onClick={() => openOrder()}
              className="shine group relative flex items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-signal-400 to-signal-500 px-6 py-4 text-[15px] font-semibold text-ink-950 shadow-[0_20px_50px_-24px_rgba(56,232,172,0.85)] transition-all duration-300 hover:-translate-y-0.5 hover:shadow-[0_28px_60px_-24px_rgba(56,232,172,0.95)]"
            >
              <span className="shine-bar" />
              Order credits — from {formatMoney(cheapest)}
              <IconArrow className="size-4 transition-transform duration-300 group-hover:translate-x-1" />
            </button>
            <a
              href="#studio"
              className="group flex items-center justify-center gap-2 rounded-2xl border border-white/14 bg-white/4 px-6 py-4 text-[15px] font-semibold text-mist-100 backdrop-blur transition-all duration-300 hover:-translate-y-0.5 hover:border-white/28 hover:bg-white/8"
            >
              Try the campaign studio
              <span className="grid size-6 place-items-center rounded-full bg-white/10 transition-transform duration-300 group-hover:translate-x-0.5">
                <IconArrow className="size-3.5" />
              </span>
            </a>
          </div>

          <dl
            className="animate-rise mt-10 grid max-w-lg grid-cols-3 gap-4 border-t border-white/8 pt-6"
            style={{ animationDelay: "680ms" }}
          >
            <div>
              <dt className="font-mono text-[10px] tracking-[0.18em] text-mist-500 uppercase">
                Delivered
              </dt>
              <dd className="mt-1 font-display text-[20px] leading-none text-mist-50 tabular-nums sm:text-[22px]">
                {delivered}
              </dd>
            </div>
            <div>
              <dt className="font-mono text-[10px] tracking-[0.18em] text-mist-500 uppercase">
                Orders placed
              </dt>
              <dd className="mt-1 font-display text-[20px] leading-none text-mist-50 tabular-nums sm:text-[22px]">
                {ordersPlaced > 0 ? ordersPlaced.toLocaleString("en-US") : "12,480"}
              </dd>
            </div>
            <div>
              <dt className="font-mono text-[10px] tracking-[0.18em] text-mist-500 uppercase">
                Avg. DLR
              </dt>
              <dd className="mt-1 font-display text-[20px] leading-none text-signal-300 tabular-nums sm:text-[22px]">
                99.2%
              </dd>
            </div>
          </dl>
        </div>

        {/* visual */}
        <div
          className="animate-rise relative"
          style={{ animationDelay: "420ms", animationDuration: "1000ms" }}
        >
          <div aria-hidden className="absolute inset-0 -z-10 flex items-center justify-center">
            <div className="size-[26rem] rounded-full bg-gradient-to-tr from-signal-500/20 via-pulse-500/10 to-transparent blur-3xl" />
          </div>
          <LivePhone />
        </div>
      </div>
    </section>
  );
}

"use client";

import { useEffect, useState } from "react";
import { useOrder } from "@/components/order/OrderContext";
import { useScrollProgress } from "@/components/motion";
import { IconArrow, IconClose, IconMenu, IconSearch, LogoMark } from "@/components/icons";

const LINKS = [
  { href: "#platform", label: "Platform" },
  { href: "#studio", label: "Campaign studio" },
  { href: "#network", label: "Network" },
  { href: "#pricing", label: "Pricing" },
  { href: "#faq", label: "FAQ" },
];

export function Navbar() {
  const { openOrder } = useOrder();
  const { progress, scrolled } = useScrollProgress();
  const [menuOpen, setMenuOpen] = useState(false);
  const [active, setActive] = useState<string>("");

  useEffect(() => {
    const sections = LINKS.map((l) => document.querySelector(l.href)).filter(
      (el): el is Element => Boolean(el),
    );
    if (!sections.length) return;
    const io = new IntersectionObserver(
      (entries) => {
        const visible = entries
          .filter((e) => e.isIntersecting)
          .sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0];
        if (visible) setActive(`#${visible.target.id}`);
      },
      { rootMargin: "-30% 0px -55% 0px", threshold: [0.05, 0.3, 0.6] },
    );
    sections.forEach((s) => io.observe(s));
    return () => io.disconnect();
  }, []);

  useEffect(() => {
    document.body.style.overflow = menuOpen ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [menuOpen]);

  return (
    <>
      <header
        className={`fixed inset-x-0 top-0 z-[100] transition-all duration-500 ${
          scrolled ? "py-2" : "py-4"
        }`}
      >
        <div className="mx-auto w-full max-w-[86rem] px-4 sm:px-6">
          <nav
            aria-label="Primary"
            className={`relative flex items-center justify-between gap-4 rounded-2xl px-3.5 py-2.5 transition-all duration-500 sm:px-4 ${
              scrolled
                ? "glass shadow-[0_18px_50px_-30px_rgba(0,0,0,0.95)]"
                : "border border-transparent bg-transparent"
            }`}
          >
            <a
              href="#top"
              className="group flex items-center gap-2.5"
              aria-label="Kfyklab home"
            >
              <span className="relative">
                <LogoMark className="size-9 transition-transform duration-500 group-hover:rotate-[-6deg] group-hover:scale-105" />
              </span>
              <span className="leading-none">
                <span className="block font-display text-[17px] font-extrabold tracking-[-0.03em] text-mist-50">
                  Kfyklab
                </span>
                <span className="mt-0.5 block font-mono text-[9px] tracking-[0.28em] text-mist-500 uppercase">
                  Bulk SMS
                </span>
              </span>
            </a>

            <ul className="hidden items-center gap-1 lg:flex">
              {LINKS.map((link) => (
                <li key={link.href}>
                  <a
                    href={link.href}
                    aria-current={active === link.href ? "true" : undefined}
                    className={`group relative block rounded-lg px-3 py-2 text-[13.5px] font-medium transition-colors ${
                      active === link.href ? "text-mist-50" : "text-mist-400 hover:text-mist-100"
                    }`}
                  >
                    {link.label}
                    <span
                      className={`absolute inset-x-3 -bottom-0.5 h-px origin-left bg-gradient-to-r from-signal-400 to-pulse-400 transition-transform duration-400 ${
                        active === link.href ? "scale-x-100" : "scale-x-0 group-hover:scale-x-100"
                      }`}
                    />
                  </a>
                </li>
              ))}
            </ul>

            <div className="flex items-center gap-2">
              <a
                href="#track"
                className="hidden items-center gap-1.5 rounded-xl px-3 py-2 text-[13px] font-medium text-mist-300 transition hover:bg-white/6 hover:text-mist-50 md:flex"
              >
                <IconSearch className="size-4" />
                Track order
              </a>
              <button
                type="button"
                onClick={() => openOrder()}
                className="shine group relative hidden items-center gap-1.5 rounded-xl bg-mist-50 px-4 py-2.5 text-[13.5px] font-semibold text-ink-950 transition-all duration-300 hover:bg-signal-300 hover:shadow-[0_10px_30px_-12px_rgba(56,232,172,0.7)] sm:flex"
              >
                <span className="shine-bar" />
                Order credits
                <IconArrow className="size-4 transition-transform duration-300 group-hover:translate-x-0.5" />
              </button>
              <button
                type="button"
                onClick={() => setMenuOpen((v) => !v)}
                aria-expanded={menuOpen}
                aria-label={menuOpen ? "Close menu" : "Open menu"}
                className="grid size-10 place-items-center rounded-xl border border-white/10 text-mist-200 transition hover:border-white/25 hover:bg-white/6 lg:hidden"
              >
                {menuOpen ? <IconClose className="size-5" /> : <IconMenu className="size-5" />}
              </button>
            </div>

            <span
              aria-hidden
              className="absolute inset-x-4 bottom-0 h-px origin-left bg-gradient-to-r from-signal-400 via-pulse-400 to-ember-400 transition-transform duration-150"
              style={{ transform: `scaleX(${progress})` }}
            />
          </nav>
        </div>
      </header>

      {/* mobile sheet */}
      <div
        className={`fixed inset-0 z-[99] lg:hidden ${menuOpen ? "" : "pointer-events-none invisible"}`}
        aria-hidden={!menuOpen}
      >
        <button
          type="button"
          tabIndex={menuOpen ? 0 : -1}
          aria-label="Close menu"
          onClick={() => setMenuOpen(false)}
          className={`absolute inset-0 bg-ink-950/80 backdrop-blur-sm transition-opacity duration-400 ${
            menuOpen ? "opacity-100" : "opacity-0"
          }`}
        />
        <div
          className={`absolute inset-x-3 top-3 origin-top rounded-3xl border border-white/10 bg-ink-900/97 p-5 backdrop-blur-2xl transition-all duration-500 [transition-timing-function:var(--ease-out-expo)] ${
            menuOpen ? "translate-y-0 opacity-100" : "-translate-y-6 opacity-0"
          }`}
        >
          <ul className="space-y-1">
            {LINKS.map((link, index) => (
              <li
                key={link.href}
                style={{ transitionDelay: `${90 + index * 55}ms` }}
                className={`transition-all duration-500 ${
                  menuOpen ? "translate-x-0 opacity-100" : "-translate-x-3 opacity-0"
                }`}
              >
                <a
                  href={link.href}
                  tabIndex={menuOpen ? 0 : -1}
                  onClick={() => setMenuOpen(false)}
                  className="flex items-center justify-between rounded-xl px-3 py-3 text-[16px] font-medium text-mist-200 transition hover:bg-white/6 hover:text-mist-50"
                >
                  {link.label}
                  <IconArrow className="size-4 text-mist-600" />
                </a>
              </li>
            ))}
            <li
              style={{ transitionDelay: "380ms" }}
              className={`transition-all duration-500 ${
                menuOpen ? "translate-x-0 opacity-100" : "-translate-x-3 opacity-0"
              }`}
            >
              <a
                href="#track"
                tabIndex={menuOpen ? 0 : -1}
                onClick={() => setMenuOpen(false)}
                className="flex items-center justify-between rounded-xl px-3 py-3 text-[16px] font-medium text-mist-200 transition hover:bg-white/6"
              >
                Track an order
                <IconSearch className="size-4 text-mist-600" />
              </a>
            </li>
          </ul>
          <button
            type="button"
            tabIndex={menuOpen ? 0 : -1}
            onClick={() => {
              setMenuOpen(false);
              openOrder();
            }}
            className="mt-3 w-full rounded-xl bg-signal-400 px-4 py-3.5 text-[15px] font-semibold text-ink-950 transition hover:bg-signal-300"
          >
            Order credits →
          </button>
          <p className="mt-3 text-center font-mono text-[10.5px] tracking-[0.16em] text-mist-600 uppercase">
            Live route status · 99.98% · 190+ countries
          </p>
        </div>
      </div>
    </>
  );
}

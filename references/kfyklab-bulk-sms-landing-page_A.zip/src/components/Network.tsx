"use client";

import { useEffect, useRef, useState } from "react";
import { Eyebrow, Reveal } from "@/components/motion";
import { useOrder } from "@/components/order/OrderContext";
import { formatMoney } from "@/lib/plans";
import {
  IconArrow,
  IconBolt,
  IconCheck,
  IconCode,
  IconGlobe,
  IconPulse,
  IconShield,
  IconSparkle,
} from "@/components/icons";

const STEPS = [
  {
    id: 0,
    kicker: "01 · Order",
    title: "Buy credits like you buy anything else",
    copy: "Pick a basket, add your Sender ID and pay by card, bank transfer, mobile wallet or invoice. Credits are reserved the moment the order lands — no sales call, no minimum contract, no setup fee.",
    icon: IconBolt,
    stat: "4 min · median checkout",
  },
  {
    id: 1,
    kicker: "02 · Verify",
    title: "We register your Sender ID with every operator",
    copy: "Our compliance desk files your brand name across the destination networks and monitors approval. Most African and Gulf markets clear inside 24 hours; the UK and EU are instant on registered routes.",
    icon: IconShield,
    stat: "24 h · median approval",
  },
  {
    id: 2,
    kicker: "03 · Launch",
    title: "Send from the studio, the API, or your own cron",
    copy: "Upload a CSV, paste a list, or POST to /v4/send with a batch of 100,000 numbers. Throttle it, schedule it per timezone, split-test two versions of the copy and let the winner finish the job.",
    icon: IconCode,
    stat: "100k · numbers per request",
  },
  {
    id: 3,
    kicker: "04 · Measure",
    title: "Watch every receipt stream back in real time",
    copy: "Delivery receipts arrive in about 1.4 seconds median, tagged with the exact operator and error code. Reconcile them in the dashboard, export to CSV, or subscribe to signed webhooks.",
    icon: IconPulse,
    stat: "1.4 s · median DLR",
  },
  {
    id: 4,
    kicker: "05 · Never overpay",
    title: "Undelivered messages refund themselves",
    copy: "Invalid numbers, dead SIMs, operator rejections — credits bounce straight back to your balance automatically within the hour. You pay for what lands, and your rate only drops as volume grows.",
    icon: IconSparkle,
    stat: "100% · refund on failures",
  },
];

const ROUTES = [
  { region: "Kenya · Safaricom", latency: 0.8, dlr: 99.4 },
  { region: "Nigeria · MTN", latency: 1.1, dlr: 98.9 },
  { region: "South Africa · Vodacom", latency: 0.9, dlr: 99.6 },
  { region: "UAE · Etisalat", latency: 1.3, dlr: 99.1 },
  { region: "UK · O2 / EE", latency: 1.6, dlr: 99.8 },
  { region: "India · Jio", latency: 2.2, dlr: 97.6 },
];

function StepVisual({ active }: { active: number }) {
  return (
    <div className="glass relative overflow-hidden rounded-3xl p-6 sm:p-7">
      <div
        aria-hidden
        className="pointer-events-none absolute -right-16 -top-16 size-52 rounded-full bg-signal-500/18 blur-3xl transition-all duration-700"
        style={{ transform: `translateY(${active * 22}px)` }}
      />

      <div className="relative flex min-h-[22rem] flex-col sm:min-h-[24rem]">
        {active === 0 && (
          <div className="animate-rise space-y-3">
            <p className="font-mono text-[10px] tracking-[0.2em] text-mist-500 uppercase">
              Order receipt · KFY-8QK2M1-4XA
            </p>
            <div className="rounded-2xl border border-white/10 bg-ink-950/50 p-4">
              {[
                ["Surge · 50,000 credits", "$750.00"],
                ["Sender ID · ZANARA", "Free"],
                ["Route · direct tier-1", "Included"],
              ].map(([k, v]) => (
                <div key={k} className="flex items-baseline justify-between py-1.5">
                  <span className="text-[13px] text-mist-400">{k}</span>
                  <span className="font-mono text-[13px] text-mist-100">{v}</span>
                </div>
              ))}
              <div className="mt-2 flex items-baseline justify-between border-t border-white/10 pt-3">
                <span className="text-[13px] font-semibold text-mist-50">Paid</span>
                <span className="font-mono text-[17px] text-signal-300">{formatMoney(75_000)}</span>
              </div>
            </div>
            <div className="flex flex-wrap gap-2">
              {["Card", "Bank", "M-Pesa", "Invoice"].map((m) => (
                <span
                  key={m}
                  className="rounded-full border border-white/10 bg-white/4 px-3 py-1.5 text-[11.5px] text-mist-300"
                >
                  {m}
                </span>
              ))}
            </div>
          </div>
        )}

        {active === 1 && (
          <div className="animate-rise space-y-3">
            <p className="font-mono text-[10px] tracking-[0.2em] text-mist-500 uppercase">
              Sender ID · ZANARA
            </p>
            {[
              { op: "Safaricom", s: "Approved", t: "6h 12m", ok: true },
              { op: "Airtel Kenya", s: "Approved", t: "9h 40m", ok: true },
              { op: "MTN Nigeria", s: "In review", t: "—", ok: false },
              { op: "Vodacom ZA", s: "Approved", t: "3h 05m", ok: true },
            ].map((row, i) => (
              <div
                key={row.op}
                className="flex items-center gap-3 rounded-xl border border-white/8 bg-ink-950/40 px-3.5 py-3"
                style={{ animation: `rise 0.6s var(--ease-out-expo) ${i * 90}ms both` }}
              >
                <span
                  className={`grid size-7 shrink-0 place-items-center rounded-full ${
                    row.ok ? "bg-signal-400/15 text-signal-300" : "bg-ember-400/12 text-ember-300"
                  }`}
                >
                  {row.ok ? <IconCheck className="size-3.5" strokeWidth={3} /> : <IconGlobe className="size-3.5" />}
                </span>
                <span className="flex-1 text-[13px] text-mist-200">{row.op}</span>
                <span className="font-mono text-[11px] text-mist-500">{row.t}</span>
                <span className={`font-mono text-[10.5px] ${row.ok ? "text-signal-300" : "text-ember-300"}`}>
                  {row.s.toUpperCase()}
                </span>
              </div>
            ))}
          </div>
        )}

        {active === 2 && (
          <div className="animate-rise space-y-4">
            <p className="font-mono text-[10px] tracking-[0.2em] text-mist-500 uppercase">
              POST /v4/send
            </p>
            <div className="rounded-2xl border border-white/10 bg-ink-950/70 p-4 font-mono text-[11.5px] leading-relaxed">
              <p className="text-mist-500">{`{`}</p>
              <p className="pl-4 text-pulse-300">"sender_id": <span className="text-signal-300">"ZANARA"</span>,</p>
              <p className="pl-4 text-pulse-300">"recipients": <span className="text-ember-300">100000</span>,</p>
              <p className="pl-4 text-pulse-300">"throttle": <span className="text-ember-300">1200</span>,</p>
              <p className="pl-4 text-pulse-300">"split_test": <span className="text-signal-300">true</span></p>
              <p className="text-mist-500">{`}`}</p>
            </div>
            <div className="rounded-2xl border border-signal-400/25 bg-signal-400/8 px-4 py-3 font-mono text-[11.5px] text-signal-200">
              202 Accepted · batch 4f9a queued · eta 84s
            </div>
          </div>
        )}

        {active === 3 && (
          <div className="animate-rise space-y-2.5">
            <p className="font-mono text-[10px] tracking-[0.2em] text-mist-500 uppercase">
              Delivery receipts · streaming
            </p>
            {ROUTES.slice(0, 5).map((route, i) => (
              <div
                key={route.region}
                className="rounded-xl border border-white/8 bg-ink-950/40 px-3.5 py-2.5"
                style={{ animation: `rise 0.55s var(--ease-out-expo) ${i * 80}ms both` }}
              >
                <div className="flex items-center justify-between gap-3">
                  <span className="text-[12.5px] text-mist-200">{route.region}</span>
                  <span className="font-mono text-[11px] text-signal-300">{route.dlr}%</span>
                </div>
                <div className="mt-2 h-1 overflow-hidden rounded-full bg-white/8">
                  <span
                    className="block h-full rounded-full bg-gradient-to-r from-signal-400 to-pulse-400"
                    style={{ width: `${route.dlr}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        )}

        {active === 4 && (
          <div className="animate-rise space-y-4">
            <p className="font-mono text-[10px] tracking-[0.2em] text-mist-500 uppercase">
              Balance · auto refunds
            </p>
            <div className="rounded-2xl border border-white/10 bg-ink-950/50 p-5">
              <p className="text-[12.5px] text-mist-500">Available credits</p>
              <p className="mt-1 font-display text-[34px] leading-none text-mist-50 tabular-nums">
                42,180
              </p>
              <div className="mt-4 space-y-2">
                {[
                  ["Refund · 312 invalid numbers", "+312", "text-signal-300"],
                  ["Refund · operator rejection", "+48", "text-signal-300"],
                  ["Volume step · 250k tier", "−0.3c/SMS", "text-pulse-300"],
                ].map(([k, v, tone]) => (
                  <div key={k} className="flex items-baseline justify-between">
                    <span className="text-[12.5px] text-mist-400">{k}</span>
                    <span className={`font-mono text-[12.5px] ${tone}`}>{v}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        <div className="mt-auto pt-6">
          <div className="flex items-center justify-between border-t border-white/8 pt-4">
            <span className="font-mono text-[10px] tracking-[0.18em] text-mist-600 uppercase">
              Step {active + 1} / {STEPS.length}
            </span>
            <div className="flex gap-1.5">
              {STEPS.map((step, index) => (
                <span
                  key={step.id}
                  className={`h-1 rounded-full transition-all duration-500 ${
                    index === active ? "w-6 bg-signal-400" : "w-2 bg-white/15"
                  }`}
                />
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export function Network() {
  const [active, setActive] = useState(0);
  const refs = useRef<(HTMLLIElement | null)[]>([]);
  const { openOrder } = useOrder();

  useEffect(() => {
    const nodes = refs.current.filter(Boolean) as HTMLLIElement[];
    if (!nodes.length) return;
    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const index = Number((entry.target as HTMLElement).dataset.index);
            setActive(index);
          }
        });
      },
      { rootMargin: "-45% 0px -45% 0px", threshold: 0 },
    );
    nodes.forEach((node) => io.observe(node));
    return () => io.disconnect();
  }, []);

  return (
    <section id="network" className="relative scroll-mt-24 border-t border-white/6 py-20 sm:py-28">
      <div aria-hidden className="pointer-events-none absolute inset-0 -z-10">
        <div className="absolute left-[-14%] top-1/3 size-[32rem] animate-drift rounded-full bg-pulse-500/10 blur-[130px]" />
      </div>

      <div className="mx-auto w-full max-w-[86rem] px-4 sm:px-6">
        <div className="max-w-3xl">
          <Reveal>
            <Eyebrow>The network</Eyebrow>
          </Reveal>
          <Reveal delay={80}>
            <h2 className="mt-5 font-display text-[clamp(2rem,5vw,3.3rem)] font-bold leading-[1.03] tracking-[-0.035em] text-mist-50">
              Five steps from <span className="aqua-text">checkout</span> to lock screen.
            </h2>
          </Reveal>
          <Reveal delay={150}>
            <p className="mt-5 text-[16px] leading-relaxed text-mist-400">
              Most providers sell you a dashboard and disappear. We sell delivered messages — and
              show our work at every hop, across 680+ operator connections.
            </p>
          </Reveal>
        </div>

        <div className="mt-14 grid gap-10 lg:grid-cols-[0.95fr_1.05fr] lg:gap-14">
          {/* pinned visual */}
          <div className="hidden lg:block">
            <div className="sticky top-28">
              <StepVisual active={active} />
              <div className="glass mt-4 rounded-3xl p-5">
                <div className="flex items-center justify-between">
                  <span className="font-mono text-[10px] tracking-[0.2em] text-mist-500 uppercase">
                    Live route latency
                  </span>
                  <span className="flex items-center gap-1.5 font-mono text-[10.5px] text-signal-300">
                    <span className="size-1.5 animate-pulse rounded-full bg-signal-400" />
                    nominal
                  </span>
                </div>
                <div className="mt-3 space-y-2">
                  {ROUTES.map((route) => (
                    <div key={route.region} className="flex items-center gap-3">
                      <span className="w-44 shrink-0 truncate text-[12px] text-mist-400">{route.region}</span>
                      <span className="h-1 flex-1 overflow-hidden rounded-full bg-white/8">
                        <span
                          className="block h-full rounded-full bg-gradient-to-r from-signal-400 via-pulse-400 to-ember-400"
                          style={{ width: `${(route.latency / 2.4) * 100}%` }}
                        />
                      </span>
                      <span className="w-12 shrink-0 text-right font-mono text-[11px] text-mist-300 tabular-nums">
                        {route.latency.toFixed(1)}s
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* steps */}
          <ol className="space-y-4 lg:space-y-6">
            {STEPS.map((step, index) => {
              const isActive = index === active;
              return (
                <li
                  key={step.id}
                  data-index={index}
                  ref={(node) => {
                    refs.current[index] = node;
                  }}
                  className={`relative rounded-3xl border p-6 transition-all duration-500 sm:p-7 ${
                    isActive
                      ? "border-signal-400/35 bg-signal-400/[0.06] shadow-[0_30px_80px_-60px_rgba(56,232,172,0.8)]"
                      : "border-white/8 bg-ink-900/40"
                  }`}
                >
                  <span
                    className={`absolute left-0 top-8 h-10 w-[3px] rounded-r-full transition-all duration-500 ${
                      isActive ? "bg-gradient-to-b from-signal-400 to-pulse-400" : "bg-white/12"
                    }`}
                    aria-hidden
                  />
                  <div className="flex items-center gap-3">
                    <span
                      className={`grid size-10 place-items-center rounded-2xl border transition-all duration-500 ${
                        isActive
                          ? "border-signal-400/45 bg-signal-400/14 text-signal-300"
                          : "border-white/10 bg-white/4 text-mist-400"
                      }`}
                    >
                      <step.icon className="size-5" />
                    </span>
                    <span className="font-mono text-[10.5px] tracking-[0.2em] text-mist-500 uppercase">
                      {step.kicker}
                    </span>
                  </div>
                  <h3 className="mt-4 font-display text-[20px] leading-snug text-mist-50 sm:text-[23px]">
                    {step.title}
                  </h3>
                  <p className="mt-2.5 text-[14.5px] leading-relaxed text-mist-400">{step.copy}</p>
                  <div className="mt-4 flex flex-wrap items-center gap-3">
                    <span className="rounded-full border border-white/10 bg-ink-950/50 px-3 py-1 font-mono text-[10.5px] text-signal-300">
                      {step.stat}
                    </span>
                    {index === 0 && (
                      <button
                        type="button"
                        onClick={() => openOrder()}
                        className="group inline-flex items-center gap-1.5 rounded-full border border-signal-400/40 bg-signal-400/10 px-3.5 py-1.5 text-[12.5px] font-semibold text-signal-200 transition hover:bg-signal-400/20"
                      >
                        Start an order
                        <IconArrow className="size-3.5 transition-transform group-hover:translate-x-0.5" />
                      </button>
                    )}
                  </div>

                  {/* mobile-only visual */}
                  <div className="mt-5 lg:hidden">
                    <StepVisual active={index} />
                  </div>
                </li>
              );
            })}
          </ol>
        </div>
      </div>
    </section>
  );
}

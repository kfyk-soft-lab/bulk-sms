"use client";

import { Fragment, useMemo, useState } from "react";
import { formatMoney, formatNumber } from "@/lib/plans";
import { IconArrow, IconDoc, IconSearch } from "@/components/icons";

export type OrderRow = {
  id: number;
  orderNumber: string;
  planName: string;
  credits: number;
  totalCents: number;
  currency: string;
  senderId: string | null;
  campaignName: string | null;
  message: string | null;
  recipients: number | null;
  schedule: string;
  scheduledAt: string | null;
  customerName: string;
  customerEmail: string;
  customerPhone: string;
  company: string | null;
  country: string | null;
  paymentMethod: string;
  notes: string | null;
  status: string;
  createdAt: string;
};

const STATUSES = ["all", "pending", "paid", "processing", "delivered"] as const;

const STATUS_TONE: Record<string, string> = {
  pending: "text-ember-300 bg-ember-400/12 border-ember-400/30",
  paid: "text-pulse-300 bg-pulse-400/12 border-pulse-400/30",
  processing: "text-ember-300 bg-ember-400/10 border-ember-400/25",
  delivered: "text-signal-300 bg-signal-400/12 border-signal-400/30",
};

const PAYMENT_LABEL: Record<string, string> = {
  card: "Card",
  bank: "Bank transfer",
  wallet: "Mobile wallet",
  invoice: "Invoice",
};

export function OrdersTable({ rows }: { rows: OrderRow[] }) {
  const [status, setStatus] = useState<(typeof STATUSES)[number]>("all");
  const [query, setQuery] = useState("");
  const [expanded, setExpanded] = useState<number | null>(null);

  const filtered = useMemo(() => {
    const needle = query.trim().toLowerCase();
    return rows.filter((row) => {
      if (status !== "all" && row.status !== status) return false;
      if (!needle) return true;
      return [row.orderNumber, row.customerName, row.company, row.customerEmail, row.country, row.senderId, row.campaignName]
        .filter(Boolean)
        .some((field) => String(field).toLowerCase().includes(needle));
    });
  }, [query, rows, status]);

  const exportCsv = () => {
    const header = [
      "order_number",
      "created_at",
      "status",
      "plan",
      "credits",
      "total",
      "currency",
      "customer",
      "company",
      "email",
      "phone",
      "country",
      "sender_id",
      "campaign",
      "payment_method",
      "schedule",
    ];
    const body = filtered.map((row) =>
      [
        row.orderNumber,
        row.createdAt,
        row.status,
        row.planName,
        row.credits,
        (row.totalCents / 100).toFixed(2),
        row.currency,
        row.customerName,
        row.company ?? "",
        row.customerEmail,
        row.customerPhone,
        row.country ?? "",
        row.senderId ?? "",
        row.campaignName ?? "",
        row.paymentMethod,
        row.schedule,
      ]
        .map((cell) => `"${String(cell).replace(/"/g, '""')}"`)
        .join(","),
    );
    const blob = new Blob([[header.join(","), ...body].join("\n")], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = `kfyklab-orders-${new Date().toISOString().slice(0, 10)}.csv`;
    anchor.click();
    URL.revokeObjectURL(url);
  };

  return (
    <section className="mt-10">
      <div className="flex flex-col gap-4 rounded-t-2xl border border-white/10 bg-ink-900/60 p-4 backdrop-blur lg:flex-row lg:items-center lg:justify-between">
        <div className="flex flex-wrap items-center gap-1.5">
          {STATUSES.map((item) => {
            const count = item === "all" ? rows.length : rows.filter((r) => r.status === item).length;
            const active = status === item;
            return (
              <button
                key={item}
                type="button"
                onClick={() => setStatus(item)}
                aria-pressed={active}
                className={`rounded-xl px-3 py-2 text-[12.5px] font-medium capitalize transition-all duration-300 ${
                  active
                    ? "bg-signal-400/15 text-signal-200 ring-1 ring-signal-400/35"
                    : "text-mist-400 hover:bg-white/6 hover:text-mist-100"
                }`}
              >
                {item}
                <span className="ml-1.5 font-mono text-[10.5px] text-mist-600">{count}</span>
              </button>
            );
          })}
        </div>

        <div className="flex items-center gap-2">
          <div className="relative flex-1 lg:w-64">
            <IconSearch className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-mist-500" />
            <label htmlFor="order-search" className="sr-only">
              Search orders
            </label>
            <input
              id="order-search"
              className="field py-2.5 pl-9 text-[13px]"
              placeholder="Search name, company, ref…"
              value={query}
              onChange={(event) => setQuery(event.target.value)}
            />
          </div>
          <button
            type="button"
            onClick={exportCsv}
            disabled={!filtered.length}
            className="flex shrink-0 items-center gap-1.5 rounded-xl border border-white/12 bg-white/5 px-3.5 py-2.5 text-[12.5px] font-medium text-mist-200 transition hover:border-signal-400/40 hover:text-signal-200 disabled:opacity-40"
          >
            <IconDoc className="size-4" />
            CSV
          </button>
        </div>
      </div>

      <div className="overflow-x-auto rounded-b-2xl border border-t-0 border-white/10 bg-ink-950/40">
        {filtered.length === 0 ? (
          <div className="px-6 py-16 text-center">
            <p className="font-display text-[19px] text-mist-100">No orders match that filter.</p>
            <p className="mx-auto mt-2 max-w-sm text-[13.5px] leading-relaxed text-mist-500">
              Orders placed through the landing page checkout appear here instantly. Head back to the
              order desk and place a test basket.
            </p>
            <a
              href="/#pricing"
              className="group mt-5 inline-flex items-center gap-2 rounded-xl bg-signal-400 px-4 py-2.5 text-[13px] font-semibold text-ink-950 transition hover:bg-signal-300"
            >
              Open the order desk
              <IconArrow className="size-3.5 transition-transform group-hover:translate-x-0.5" />
            </a>
          </div>
        ) : (
          <table className="w-full min-w-[54rem] border-collapse text-left">
            <thead>
              <tr className="border-b border-white/8 font-mono text-[10px] tracking-[0.16em] text-mist-600 uppercase">
                <th className="px-4 py-3 font-medium">Order</th>
                <th className="px-4 py-3 font-medium">Customer</th>
                <th className="px-4 py-3 font-medium">Package</th>
                <th className="px-4 py-3 text-right font-medium">Credits</th>
                <th className="px-4 py-3 text-right font-medium">Value</th>
                <th className="px-4 py-3 font-medium">Status</th>
                <th className="px-4 py-3 font-medium">Placed</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((row) => {
                const isOpen = expanded === row.id;
                return (
                  <Fragment key={row.id}>
                    <tr
                      onClick={() => setExpanded(isOpen ? null : row.id)}
                      className={`cursor-pointer border-b border-white/6 transition-colors duration-300 ${
                        isOpen ? "bg-signal-400/[0.06]" : "hover:bg-white/[0.035]"
                      }`}
                    >
                      <td className="px-4 py-3.5">
                        <span className="flex items-center gap-2 font-mono text-[12px] text-signal-300">
                          {row.orderNumber}
                          <IconArrow
                            className={`size-3 text-mist-600 transition-transform duration-300 ${isOpen ? "rotate-90" : ""}`}
                          />
                        </span>
                        <span className="mt-1 block font-mono text-[10px] text-mist-600">
                          {PAYMENT_LABEL[row.paymentMethod] ?? row.paymentMethod}
                        </span>
                      </td>
                      <td className="px-4 py-3.5">
                        <span className="block text-[13px] text-mist-100">
                          {row.company ?? row.customerName}
                        </span>
                        <span className="block text-[11.5px] text-mist-500">
                          {row.country ?? "—"} · {row.customerEmail}
                        </span>
                      </td>
                      <td className="px-4 py-3.5">
                        <span className="block text-[13px] text-mist-200">{row.planName}</span>
                        <span className="block font-mono text-[11px] text-mist-600">
                          {row.senderId ?? "no sender id"}
                        </span>
                      </td>
                      <td className="px-4 py-3.5 text-right font-mono text-[12.5px] text-mist-100 tabular-nums">
                        {formatNumber(row.credits)}
                      </td>
                      <td className="px-4 py-3.5 text-right font-mono text-[12.5px] text-mist-50 tabular-nums">
                        {formatMoney(row.totalCents, row.currency)}
                      </td>
                      <td className="px-4 py-3.5">
                        <span
                          className={`inline-flex rounded-full border px-2.5 py-1 font-mono text-[10px] tracking-[0.12em] uppercase ${
                            STATUS_TONE[row.status] ?? "border-white/12 text-mist-400"
                          }`}
                        >
                          {row.status}
                        </span>
                      </td>
                      <td className="px-4 py-3.5 font-mono text-[11.5px] text-mist-500">
                        {new Date(row.createdAt).toLocaleDateString("en-GB", {
                          day: "2-digit",
                          month: "short",
                          hour: "2-digit",
                          minute: "2-digit",
                        })}
                      </td>
                    </tr>
                    {isOpen && (
                      <tr key={`${row.id}-detail`} className="border-b border-white/6 bg-ink-900/70">
                        <td colSpan={7} className="px-4 py-5">
                          <div className="grid gap-5 lg:grid-cols-3">
                            <div>
                              <p className="font-mono text-[10px] tracking-[0.18em] text-mist-600 uppercase">
                                Campaign
                              </p>
                              <p className="mt-2 text-[13px] text-mist-200">
                                {row.campaignName ?? "Untitled campaign"}
                              </p>
                              <p className="mt-2 rounded-xl border border-white/8 bg-ink-950/60 p-3 text-[12.5px] leading-relaxed text-mist-400">
                                {row.message ?? "No copy submitted with this order."}
                              </p>
                              <p className="mt-2 font-mono text-[11px] text-mist-600">
                                {row.schedule === "scheduled"
                                  ? `Scheduled · ${row.scheduledAt ?? "time pending"}`
                                  : "Immediate dispatch"}
                                {row.recipients ? ` · ${formatNumber(row.recipients)} recipients` : ""}
                              </p>
                            </div>
                            <div>
                              <p className="font-mono text-[10px] tracking-[0.18em] text-mist-600 uppercase">
                                Contact
                              </p>
                              <dl className="mt-2 space-y-1.5 text-[12.5px]">
                                {[
                                  ["Name", row.customerName],
                                  ["Email", row.customerEmail],
                                  ["Phone", row.customerPhone],
                                  ["Company", row.company ?? "—"],
                                  ["Country", row.country ?? "—"],
                                ].map(([k, v]) => (
                                  <div key={k} className="flex justify-between gap-4">
                                    <dt className="text-mist-600">{k}</dt>
                                    <dd className="text-right text-mist-200">{v}</dd>
                                  </div>
                                ))}
                              </dl>
                            </div>
                            <div>
                              <p className="font-mono text-[10px] tracking-[0.18em] text-mist-600 uppercase">
                                Commercial
                              </p>
                              <dl className="mt-2 space-y-1.5 text-[12.5px]">
                                <div className="flex justify-between gap-4">
                                  <dt className="text-mist-600">Credits</dt>
                                  <dd className="font-mono text-mist-200">{formatNumber(row.credits)}</dd>
                                </div>
                                <div className="flex justify-between gap-4">
                                  <dt className="text-mist-600">Rate</dt>
                                  <dd className="font-mono text-mist-200">
                                    ${((row.totalCents / row.credits) / 100).toFixed(4)} / SMS
                                  </dd>
                                </div>
                                <div className="flex justify-between gap-4">
                                  <dt className="text-mist-600">Value</dt>
                                  <dd className="font-mono text-signal-300">
                                    {formatMoney(row.totalCents, row.currency)}
                                  </dd>
                                </div>
                              </dl>
                              {row.notes && (
                                <p className="mt-3 rounded-xl border border-ember-400/20 bg-ember-400/6 p-3 text-[12.5px] leading-relaxed text-ember-300/90">
                                  Note: {row.notes}
                                </p>
                              )}
                            </div>
                          </div>
                        </td>
                      </tr>
                    )}
                  </Fragment>
                );
              })}
            </tbody>
          </table>
        )}
      </div>

      <p className="mt-4 text-center font-mono text-[11px] text-mist-600">
        Showing {filtered.length} of {rows.length} orders · click a row for the full brief
      </p>
    </section>
  );
}

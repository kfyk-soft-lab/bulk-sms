"use client";

import { useEffect, useRef, useState } from "react";
import { Eyebrow, Reveal, useReducedMotion } from "@/components/motion";
import { useOrder } from "@/components/order/OrderContext";
import { PLANS, formatMoney, formatNumber, rateLabel } from "@/lib/plans";
import { SEGMENT_LADDER, etaMinutes, nearestLadderIndex, analyseMessage } from "@/lib/sms";
import { pricePerSmsTenthsFor, totalCentsFor } from "@/lib/plans";
import { IconArrow, IconBolt, IconCheck, IconSparkle } from "@/components/icons";

/** Smoothly tweens a number when it changes (respects reduced motion). */
function useTween(value: number, duration = 650) {
  const reduced = useReducedMotion();
  const [display, setDisplay] = useState(value);
  const from = useRef(value);
  const raf = useRef<number | null>(null);

  useEffect(() => {
    if (reduced) {
      setDisplay(value);
      from.current = value;
      return;
    }
    const start = performance.now();
    const origin = from.current;
    const tick = (now: number) => {
      const p = Math.min(1, (now - start) / duration);
      const eased = 1 - Math.pow(1 - p, 3);
      setDisplay(origin + (value - origin) * eased);
      if (p < 1) raf.current = requestAnimationFrame(tick);
      else from.current = value;
    };
    raf.current = requestAnimationFrame(tick);
    return () => {
      if (raf.current) cancelAnimationFrame(raf.current);
      from.current = value;
    };
  }, [duration, reduced, value]);

  return display;
}

function Price({ cents, dark }: { cents: number; dark?: boolean }) {
  const tweened = useTween(cents);
  return (
    <span
      className={`font-display text-[clamp(1.9rem,4.4vw,2.5rem)] font-bold leading-none tabular-nums ${
        dark ? "text-mist-50" : "text-ink-900"
      }`}
    >
      ${Math.round(tweened / 100).toLocaleString("en-US")}
    </span>
  );
}

export function Pricing() {
  const { openOrder } = useOrder();
  const [monthly, setMonthly] = useState(false);
  const [sliderIndex, setSliderIndex] = useState(nearestLadderIndex(120_000));

  const customCredits = SEGMENT_LADDER[sliderIndex];
  const customRate = pricePerSmsTenthsFor(customCredits);
  const customTotal = totalCentsFor(customCredits, 1);

  return (
    <section
      id="pricing"
      className="relative scroll-mt-24 overflow-hidden bg-paper py-20 text-ink-900 sm:py-28"
    >
      <div aria-hidden className="pointer-events-none absolute inset-0">
        <div className="absolute inset-0 opacity-[0.55] [background-image:radial-gradient(circle_at_18%_12%,rgba(18,201,151,0.16),transparent_45%),radial-gradient(circle_at_82%_78%,rgba(42,159,212,0.14),transparent_48%)]" />
        <div className="absolute inset-x-0 top-0 h-24 bg-gradient-to-b from-ink-950 to-transparent opacity-90" />
        <div className="absolute inset-x-0 bottom-0 h-28 bg-gradient-to-t from-ink-950 via-ink-950/45 to-transparent" />
      </div>

      <div className="relative mx-auto w-full max-w-[86rem] px-4 sm:px-6">
        <div className="flex flex-col items-start gap-8 lg:flex-row lg:items-end lg:justify-between">
          <div className="max-w-2xl">
            <Reveal>
              <Eyebrow tone="ink">Pricing</Eyebrow>
            </Reveal>
            <Reveal delay={80}>
              <h2 className="mt-5 font-display text-[clamp(2rem,5vw,3.3rem)] font-bold leading-[1.03] tracking-[-0.035em] text-ink-950">
                Pay for messages. Not for meetings.
              </h2>
            </Reveal>
            <Reveal delay={140}>
              <p className="mt-5 text-[16px] leading-relaxed text-ink-700/75">
                Buy a basket whenever you need it, or subscribe monthly and get 12% bonus credits.
                Volume tiers apply automatically, credits never expire, and undelivered messages
                refund themselves.
              </p>
            </Reveal>
          </div>

          <Reveal delay={200}>
            <div className="flex items-center gap-3 rounded-2xl border border-ink-900/12 bg-white/70 p-1.5 backdrop-blur">
              {(
                [
                  { id: false, label: "One-off basket" },
                  { id: true, label: "Monthly · +12% credits" },
                ] as const
              ).map((option) => (
                <button
                  key={option.label}
                  type="button"
                  onClick={() => setMonthly(option.id)}
                  aria-pressed={monthly === option.id}
                  className={`rounded-xl px-4 py-2.5 text-[13px] font-semibold transition-all duration-400 ${
                    monthly === option.id
                      ? "bg-ink-950 text-mist-50 shadow-[0_10px_26px_-16px_rgba(4,6,10,0.9)]"
                      : "text-ink-700/70 hover:text-ink-950"
                  }`}
                >
                  {option.label}
                </button>
              ))}
            </div>
          </Reveal>
        </div>

        <div className="mt-12 grid gap-4 lg:grid-cols-4">
          {PLANS.map((plan, index) => {
            const price = plan.totalCents;
            const credits = monthly ? Math.round(plan.credits * 1.12) : plan.credits;
            const effectiveRate = monthly
              ? Math.round((plan.totalCents * 10) / credits)
              : plan.pricePerSmsTenths;
            const dark = Boolean(plan.highlight);
            const throughput = { spark: 60, surge: 300, orbit: 1200, atlas: 5000 }[plan.id] ?? 300;

            return (
              <Reveal key={plan.id} delay={index * 90}>
                <article
                  className={`group relative flex h-full flex-col overflow-hidden rounded-3xl p-6 transition-all duration-500 [transition-timing-function:var(--ease-out-expo)] hover:-translate-y-1.5 sm:p-7 ${
                    dark
                      ? "bg-ink-950 text-mist-100 shadow-[0_40px_90px_-45px_rgba(4,6,10,0.85)] ring-1 ring-signal-400/25"
                      : "border border-ink-900/10 bg-white/85 text-ink-900 shadow-[0_24px_60px_-46px_rgba(4,6,10,0.6)] backdrop-blur hover:shadow-[0_36px_80px_-46px_rgba(4,6,10,0.55)]"
                  }`}
                >
                  {dark && (
                    <span
                      aria-hidden
                      className="pointer-events-none absolute -right-20 -top-20 size-52 rounded-full bg-signal-500/25 blur-3xl transition-opacity duration-700 group-hover:opacity-100"
                    />
                  )}
                  {plan.badge && (
                    <span className="absolute right-5 top-5 inline-flex items-center gap-1.5 rounded-full bg-signal-400 px-2.5 py-1 font-mono text-[9.5px] tracking-[0.16em] text-ink-950 uppercase">
                      <IconSparkle className="size-3" />
                      {plan.badge}
                    </span>
                  )}

                  <h3
                    className={`font-display text-[21px] font-bold tracking-[-0.02em] ${
                      dark ? "text-mist-50" : "text-ink-950"
                    }`}
                  >
                    {plan.name}
                  </h3>
                  <p
                    className={`mt-2 min-h-[3.4rem] text-[13px] leading-relaxed ${
                      dark ? "text-mist-400" : "text-ink-700/70"
                    }`}
                  >
                    {plan.tagline}
                  </p>

                  <div className="mt-5 flex items-end gap-2">
                    <Price cents={price} dark={dark} />
                    <span
                      className={`mb-1 font-mono text-[11px] ${dark ? "text-mist-500" : "text-ink-700/55"}`}
                    >
                      {monthly ? "/month" : "one-off"}
                    </span>
                  </div>

                  <div
                    className={`mt-4 flex flex-wrap items-center gap-x-3 gap-y-1 border-t pt-4 font-mono text-[11px] ${
                      dark ? "border-white/10 text-mist-400" : "border-ink-900/10 text-ink-700/65"
                    }`}
                  >
                    <span>{formatNumber(credits)} credits</span>
                    <span className={dark ? "text-mist-600" : "text-ink-900/25"}>·</span>
                    <span>
                      {rateLabel(effectiveRate)}/SMS
                      {monthly && (
                        <span className={dark ? "text-signal-300" : "text-signal-600"}> ↓</span>
                      )}
                    </span>
                    <span className={dark ? "text-mist-600" : "text-ink-900/25"}>·</span>
                    <span>{plan.throughput}</span>
                  </div>

                  <ul className="mt-5 flex-1 space-y-2.5">
                    {plan.features.map((feature) => (
                      <li key={feature} className="flex items-start gap-2.5">
                        <span
                          className={`mt-0.5 grid size-4 shrink-0 place-items-center rounded-full ${
                            dark ? "bg-signal-400/18 text-signal-300" : "bg-signal-500/12 text-signal-600"
                          }`}
                        >
                          <IconCheck className="size-2.5" strokeWidth={3} />
                        </span>
                        <span
                          className={`text-[13px] leading-relaxed ${
                            dark ? "text-mist-300" : "text-ink-700/85"
                          }`}
                        >
                          {feature}
                        </span>
                      </li>
                    ))}
                  </ul>

                  <p
                    className={`mt-5 border-t pt-4 font-mono text-[10.5px] ${
                      dark ? "border-white/10 text-mist-500" : "border-ink-900/10 text-ink-700/55"
                    }`}
                  >
                    {plan.support}
                  </p>

                  <button
                    type="button"
                    onClick={() =>
                      openOrder({
                        planId: plan.id,
                        credits: plan.credits,
                        recipients: plan.credits,
                      })
                    }
                    className={`shine relative mt-5 flex w-full items-center justify-center gap-2 overflow-hidden rounded-2xl px-5 py-3.5 text-[14px] font-semibold transition-all duration-300 ${
                      dark
                        ? "bg-signal-400 text-ink-950 hover:bg-signal-300"
                        : "border border-ink-950/15 bg-ink-950 text-mist-50 hover:bg-ink-800"
                    }`}
                  >
                    <span className="shine-bar" />
                    Order {plan.name}
                    <IconArrow className="size-4 transition-transform duration-300 group-hover:translate-x-0.5" />
                  </button>
                  <p
                    className={`mt-3 text-center font-mono text-[10px] ${
                      dark ? "text-mist-600" : "text-ink-700/45"
                    }`}
                  >
                    Full send ≈ {etaMinutes(plan.credits, throughput)}
                  </p>
                </article>
              </Reveal>
            );
          })}
        </div>

        {/* custom volume */}
        <Reveal delay={120}>
          <div className="mt-6 grid gap-6 overflow-hidden rounded-3xl border border-ink-900/12 bg-white/80 p-6 backdrop-blur lg:grid-cols-[1.25fr_0.75fr] lg:items-center sm:p-8">
            <div>
              <h3 className="font-display text-[22px] font-bold text-ink-950">
                Need a number that is not on the menu?
              </h3>
              <p className="mt-2 max-w-lg text-[14.5px] leading-relaxed text-ink-700/75">
                Drag to your exact volume. The rate drops automatically as you climb a tier — the
                same engine that prices our enterprise contracts.
              </p>

              <div className="mt-6">
                <div className="flex items-baseline justify-between">
                  <label htmlFor="pricing-slider" className="font-mono text-[11px] tracking-[0.16em] text-ink-700/60 uppercase">
                    Volume
                  </label>
                  <span className="font-display text-[20px] font-bold text-ink-950 tabular-nums">
                    {formatNumber(customCredits)} SMS
                  </span>
                </div>
                <input
                  id="pricing-slider"
                  type="range"
                  min={0}
                  max={SEGMENT_LADDER.length - 1}
                  step={1}
                  value={sliderIndex}
                  onChange={(event) => setSliderIndex(Number(event.target.value))}
                  className="mt-3 h-1.5 w-full cursor-pointer appearance-none rounded-full bg-ink-900/12 accent-signal-600
                    [&::-webkit-slider-thumb]:size-5 [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:rounded-full
                    [&::-webkit-slider-thumb]:bg-ink-950 [&::-webkit-slider-thumb]:shadow-[0_0_0_4px_rgba(18,201,151,0.35)]
                    [&::-moz-range-thumb]:size-5 [&::-moz-range-thumb]:rounded-full [&::-moz-range-thumb]:border-0 [&::-moz-range-thumb]:bg-ink-950"
                />
                <div className="mt-2 flex justify-between font-mono text-[10px] text-ink-700/45">
                  <span>1K</span>
                  <span>50K</span>
                  <span>500K</span>
                  <span>2M</span>
                </div>
              </div>
            </div>

            <div className="rounded-2xl border border-ink-900/10 bg-ink-950 p-6 text-mist-100">
              <p className="font-mono text-[10px] tracking-[0.2em] text-mist-500 uppercase">
                Your rate
              </p>
              <p className="mt-2 font-display text-[34px] font-bold leading-none text-signal-300 tabular-nums">
                {(customRate / 1000).toFixed(4)}
                <span className="ml-1 font-mono text-[12px] font-normal text-mist-500">/ SMS</span>
              </p>
              <div className="mt-5 space-y-1.5 border-t border-white/10 pt-4 font-mono text-[11.5px]">
                <div className="flex justify-between">
                  <span className="text-mist-500">Basket</span>
                  <span className="text-mist-100">{formatMoney(customTotal)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-mist-500">Segments</span>
                  <span className="text-mist-100">1× (160 chars)</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-mist-500">Sender ID</span>
                  <span className="text-signal-300">Free</span>
                </div>
              </div>
              <button
                type="button"
                onClick={() =>
                  openOrder({
                    planId: customCredits >= 1_000_000 ? "atlas" : customCredits >= 250_000 ? "orbit" : customCredits >= 50_000 ? "surge" : "spark",
                    credits: customCredits,
                    recipients: customCredits,
                  })
                }
                className="shine group relative mt-5 flex w-full items-center justify-center gap-2 overflow-hidden rounded-xl bg-signal-400 px-4 py-3 text-[13.5px] font-semibold text-ink-950 transition hover:bg-signal-300"
              >
                <span className="shine-bar" />
                <IconBolt className="size-4" />
                Order this basket
              </button>
            </div>
          </div>
        </Reveal>

        <Reveal delay={80}>
          <p className="mt-6 flex flex-wrap items-center justify-center gap-x-6 gap-y-2 text-center font-mono text-[11px] text-ink-700/55">
            <span>Prices in USD · local invoicing available</span>
            <span>VAT handled at checkout</span>
            <span>{analyseMessage("").encoding} &amp; UCS-2 both supported</span>
            <span>Credits never expire</span>
          </p>
        </Reveal>
      </div>
    </section>
  );
}

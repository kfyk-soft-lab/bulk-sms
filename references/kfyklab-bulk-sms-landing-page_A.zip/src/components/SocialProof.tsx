"use client";

import { Reveal, useCountUp, useInView } from "@/components/motion";
import { IconSparkle } from "@/components/icons";

const BRANDS = [
  "Zanara Retail",
  "Paylent",
  "Sokoni Foods",
  "Ridewave",
  "Tanda Bank",
  "Kesho Media",
  "Halidi Logistics",
  "Nova Health",
  "Sasa Express",
  "Bluepeak Hotels",
];

function Brand({ name, index }: { name: string; index: number }) {
  const glyphs = ["◆", "◍", "▲", "✦", "◈", "❖", "◉", "✧", "◇", "▣"];
  return (
    <span className="flex shrink-0 items-center gap-2.5 px-7 text-mist-400 transition-colors duration-300 hover:text-mist-100">
      <span className="text-signal-400/70 transition-transform duration-500 hover:rotate-90">
        {glyphs[index % glyphs.length]}
      </span>
      <span className="font-display text-[15px] font-semibold tracking-[-0.01em] whitespace-nowrap sm:text-[16px]">
        {name}
      </span>
    </span>
  );
}

function Stat({
  value,
  suffix,
  prefix,
  label,
  decimals = 0,
}: {
  value: number;
  suffix?: string;
  prefix?: string;
  label: string;
  decimals?: number;
}) {
  const { ref, inView } = useInView<HTMLDivElement>({ threshold: 0.4 });
  const animated = useCountUp(value, inView, 1900);
  return (
    <div ref={ref} className="group px-5 py-6 text-center sm:px-6">
      <p className="font-display text-[clamp(1.7rem,4vw,2.4rem)] font-bold leading-none text-mist-50 tabular-nums transition-colors duration-300 group-hover:text-signal-300">
        {prefix}
        {animated.toLocaleString("en-US", {
          minimumFractionDigits: decimals,
          maximumFractionDigits: decimals,
        })}
        {suffix}
      </p>
      <p className="mt-2.5 font-mono text-[10.5px] tracking-[0.18em] text-mist-500 uppercase">
        {label}
      </p>
    </div>
  );
}

export function SocialProof() {
  return (
    <section aria-label="Customers and network statistics" className="relative border-y border-white/6 bg-ink-900/50">
      <div className="mx-auto w-full max-w-[86rem] px-4 py-12 sm:px-6 sm:py-14">
        <Reveal className="flex flex-col items-center gap-3 text-center">
          <span className="inline-flex items-center gap-2 font-mono text-[10.5px] tracking-[0.22em] text-mist-500 uppercase">
            <IconSparkle className="size-3.5 text-ember-400" />
            Trusted by 12,480 senders — from corner shops to national banks
          </span>
        </Reveal>

        <div className="mask-fade-x relative mt-8 overflow-hidden">
          <div className="flex w-max animate-marquee items-center">
            {[...BRANDS, ...BRANDS].map((brand, index) => (
              <Brand key={`${brand}-${index}`} name={brand} index={index} />
            ))}
          </div>
        </div>

        <Reveal delay={120}>
          <div className="mt-10 grid grid-cols-2 divide-x divide-y divide-white/8 overflow-hidden rounded-2xl border border-white/8 bg-ink-850/40 lg:grid-cols-4 lg:divide-y-0">
            <Stat value={190} suffix="+" label="Countries reached" />
            <Stat value={99.95} suffix="%" decimals={2} label="Route uptime · 90d" />
            <Stat value={1.4} suffix="s" decimals={1} label="Median delivery receipt" />
            <Stat value={4.9} suffix="/5" decimals={1} label="2,318 verified reviews" />
          </div>
        </Reveal>
      </div>
    </section>
  );
}

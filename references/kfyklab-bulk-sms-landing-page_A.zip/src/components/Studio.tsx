"use client";

import { useMemo, useState } from "react";
import { Eyebrow, Reveal } from "@/components/motion";
import { useOrder } from "@/components/order/OrderContext";
import { analyseMessage, etaMinutes, SEGMENT_LADDER } from "@/lib/sms";
import { formatMoney, formatNumber, PLANS, pricePerSmsTenthsFor, totalCentsFor } from "@/lib/plans";
import {
  IconArrow,
  IconAudience,
  IconBolt,
  IconCalendar,
  IconCheck,
  IconGauge,
  IconPulse,
  IconTarget,
} from "@/components/icons";

const TABS = [
  { id: "compose", label: "Compose", icon: IconBolt },
  { id: "audience", label: "Audience", icon: IconAudience },
  { id: "schedule", label: "Schedule", icon: IconCalendar },
  { id: "analyse", label: "Analyse", icon: IconGauge },
] as const;

type TabId = (typeof TABS)[number]["id"];

const REGIONS = [
  { id: "KE", label: "Kenya", flag: "🇰🇪", rate: 1.0, dlr: 99.4 },
  { id: "NG", label: "Nigeria", flag: "🇳🇬", rate: 1.06, dlr: 98.9 },
  { id: "ZA", label: "South Africa", flag: "🇿🇦", rate: 0.94, dlr: 99.6 },
  { id: "AE", label: "UAE", flag: "🇦🇪", rate: 1.22, dlr: 99.1 },
  { id: "GB", label: "United Kingdom", flag: "🇬🇧", rate: 1.48, dlr: 99.8 },
  { id: "IN", label: "India", flag: "🇮🇳", rate: 0.72, dlr: 97.6 },
];

const MERGE_TAGS = ["{{first_name}}", "{{order_id}}", "{{balance}}", "{{store}}", "{{link}}"];

function basketFor(needed: number) {
  const basket = SEGMENT_LADDER.find((c) => c >= needed) ?? SEGMENT_LADDER[SEGMENT_LADDER.length - 1];
  const plan = PLANS.find((p) => p.credits >= basket);
  return { basket, planId: plan ? plan.id : "atlas" };
}

export function Studio() {
  const { openOrder } = useOrder();
  const [tab, setTab] = useState<TabId>("compose");
  const [senderId, setSenderId] = useState("KFYKLAB");
  const [message, setMessage] = useState(
    "Hi {{first_name}}! Your order {{order_id}} left our Nairobi hub today. Track it live: kfyk.co/t Reply STOP to opt out.",
  );
  const [recipients, setRecipients] = useState(48_000);
  const [region, setRegion] = useState(REGIONS[0]);
  const [throttle, setThrottle] = useState(600);
  const [when, setWhen] = useState<"instant" | "scheduled">("instant");
  const [suppress, setSuppress] = useState(true);

  const analysis = useMemo(() => analyseMessage(message), [message]);
  const parts = analysis.segments * recipients;
  const { basket, planId } = basketFor(parts);
  const rateTenths = pricePerSmsTenthsFor(basket);
  const cost = totalCentsFor(basket, 1);
  const perRecipient = Math.round((rateTenths * analysis.segments * region.rate) / 10) / 100;
  const projectedCents = Math.round((parts * rateTenths * region.rate) / 10);

  const insertTag = (tag: string) => setMessage((m) => `${m}${m.length && !m.endsWith(" ") ? " " : ""}${tag}`);

  return (
    <section id="studio" className="relative scroll-mt-24 overflow-hidden py-20 sm:py-28">
      <div aria-hidden className="pointer-events-none absolute inset-0 -z-10">
        <div className="absolute right-[-10%] top-1/4 size-[34rem] animate-drift-slow rounded-full bg-pulse-500/10 blur-[130px]" />
        <div className="absolute inset-0 grid-lines opacity-30 mask-fade-b" />
      </div>

      <div className="mx-auto w-full max-w-[86rem] px-4 sm:px-6">
        <div className="flex flex-col gap-6 lg:flex-row lg:items-end lg:justify-between">
          <div className="max-w-2xl">
            <Reveal>
              <Eyebrow>Product showcase</Eyebrow>
            </Reveal>
            <Reveal delay={80}>
              <h2 className="mt-5 font-display text-[clamp(2rem,5vw,3.3rem)] font-bold leading-[1.03] tracking-[-0.035em] text-mist-50">
                Build the campaign right here. <span className="aqua-text">Then buy the credits.</span>
              </h2>
            </Reveal>
            <Reveal delay={150}>
              <p className="mt-5 text-[16px] leading-relaxed text-mist-400">
                This is the real studio, running in your browser. Write the copy, pick the audience
                and we will price the basket live — no account needed until you press order.
              </p>
            </Reveal>
          </div>
          <Reveal delay={200}>
            <div className="glass rounded-2xl px-5 py-4">
              <p className="font-mono text-[10px] tracking-[0.2em] text-mist-500 uppercase">
                Live estimate
              </p>
              <p className="mt-1 font-display text-3xl leading-none text-mist-50">
                {formatMoney(projectedCents)}
              </p>
              <p className="mt-1.5 font-mono text-[11px] text-mist-500">
                {formatNumber(parts)} message parts · {region.label}
              </p>
            </div>
          </Reveal>
        </div>

        <div className="mt-12 grid gap-5 lg:grid-cols-[1.15fr_0.85fr]">
          {/* controls */}
          <Reveal className="lg:col-span-1">
            <div className="glass h-full overflow-hidden rounded-3xl">
              <div
                role="tablist"
                aria-label="Campaign studio steps"
                className="flex gap-1 overflow-x-auto border-b border-white/8 p-2.5"
              >
                {TABS.map((item) => {
                  const active = tab === item.id;
                  const Icon = item.icon;
                  return (
                    <button
                      key={item.id}
                      role="tab"
                      id={`tab-${item.id}`}
                      aria-selected={active}
                      aria-controls={`panel-${item.id}`}
                      onClick={() => setTab(item.id)}
                      className={`flex shrink-0 items-center gap-2 rounded-xl px-3.5 py-2.5 text-[13px] font-medium transition-all duration-300 ${
                        active
                          ? "bg-signal-400/14 text-signal-200 ring-1 ring-signal-400/35"
                          : "text-mist-400 hover:bg-white/5 hover:text-mist-100"
                      }`}
                    >
                      <Icon className="size-4" />
                      {item.label}
                    </button>
                  );
                })}
              </div>

              <div className="p-5 sm:p-7">
                {tab === "compose" && (
                  <div role="tabpanel" id="panel-compose" aria-labelledby="tab-compose" className="space-y-5 animate-rise">
                    <div>
                      <label
                        htmlFor="studio-sender"
                        className="mb-1.5 block text-[12.5px] font-medium text-mist-200"
                      >
                        Sender ID
                      </label>
                      <input
                        id="studio-sender"
                        className="field max-w-56 font-mono tracking-[0.18em] uppercase"
                        maxLength={11}
                        value={senderId}
                        onChange={(e) => setSenderId(e.target.value.toUpperCase().replace(/[^A-Z0-9 ]/g, ""))}
                      />
                      <p className="mt-1.5 font-mono text-[10.5px] text-mist-600">
                        {senderId.length}/11 · registration included free
                      </p>
                    </div>

                    <div>
                      <div className="mb-1.5 flex items-baseline justify-between">
                        <label htmlFor="studio-message" className="text-[12.5px] font-medium text-mist-200">
                          Message copy
                        </label>
                        <span className="font-mono text-[10.5px] text-mist-500">
                          {analysis.chars}/160 · {analysis.segments} segment
                          {analysis.segments > 1 ? "s" : ""} · {analysis.encoding}
                        </span>
                      </div>
                      <textarea
                        id="studio-message"
                        className="field min-h-36 resize-y text-[14.5px] leading-relaxed"
                        value={message}
                        maxLength={900}
                        onChange={(e) => setMessage(e.target.value)}
                      />
                      <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-white/8">
                        <div
                          className={`h-full rounded-full transition-all duration-300 ${
                            analysis.chars > 160 ? "bg-ember-400" : "bg-signal-400"
                          }`}
                          style={{ width: `${Math.min(100, (analysis.chars / (analysis.segments * 153)) * 100)}%` }}
                        />
                      </div>
                    </div>

                    <div>
                      <p className="mb-2 text-[12.5px] font-medium text-mist-200">Personalise</p>
                      <div className="flex flex-wrap gap-2">
                        {MERGE_TAGS.map((tag) => (
                          <button
                            key={tag}
                            type="button"
                            onClick={() => insertTag(tag)}
                            className="rounded-lg border border-white/10 bg-ink-950/60 px-2.5 py-1.5 font-mono text-[11px] text-mist-300 transition hover:-translate-y-0.5 hover:border-signal-400/45 hover:text-signal-300"
                          >
                            + {tag}
                          </button>
                        ))}
                      </div>
                    </div>

                    <p className="flex items-start gap-2 rounded-xl border border-white/8 bg-ink-950/40 p-3 text-[12.5px] leading-relaxed text-mist-500">
                      <IconCheck className="mt-0.5 size-3.5 shrink-0 text-signal-400" strokeWidth={2.4} />
                      Unicode (emoji, Kiswahili diacritics, Arabic) automatically switches to UCS-2
                      at 70 characters per segment — you will see the cost change live.
                    </p>
                  </div>
                )}

                {tab === "audience" && (
                  <div role="tabpanel" id="panel-audience" aria-labelledby="tab-audience" className="space-y-6 animate-rise">
                    <div>
                      <div className="flex items-baseline justify-between">
                        <label htmlFor="studio-recipients" className="text-[12.5px] font-medium text-mist-200">
                          Recipients
                        </label>
                        <span className="font-mono text-[13px] text-signal-300 tabular-nums">
                          {formatNumber(recipients)}
                        </span>
                      </div>
                      <input
                        id="studio-recipients"
                        type="range"
                        min={500}
                        max={1_000_000}
                        step={500}
                        value={recipients}
                        onChange={(e) => setRecipients(Number(e.target.value))}
                        className="mt-3 h-1.5 w-full cursor-pointer appearance-none rounded-full bg-white/12 accent-signal-400
                          [&::-webkit-slider-thumb]:size-4 [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:rounded-full
                          [&::-webkit-slider-thumb]:bg-signal-400 [&::-webkit-slider-thumb]:shadow-[0_0_0_5px_rgba(56,232,172,0.18)]
                          [&::-moz-range-thumb]:size-4 [&::-moz-range-thumb]:rounded-full [&::-moz-range-thumb]:border-0 [&::-moz-range-thumb]:bg-signal-400"
                      />
                      <div className="mt-2 flex justify-between font-mono text-[10px] text-mist-600">
                        <span>500</span>
                        <span>250K</span>
                        <span>1M</span>
                      </div>
                    </div>

                    <div>
                      <p className="mb-2.5 text-[12.5px] font-medium text-mist-200">Destination network</p>
                      <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
                        {REGIONS.map((item) => {
                          const active = region.id === item.id;
                          return (
                            <button
                              key={item.id}
                              type="button"
                              onClick={() => setRegion(item)}
                              aria-pressed={active}
                              className={`rounded-xl border px-3 py-2.5 text-left transition-all duration-300 ${
                                active
                                  ? "border-signal-400/55 bg-signal-400/10"
                                  : "border-white/10 bg-ink-950/40 hover:border-white/24"
                              }`}
                            >
                              <span className="flex items-center gap-2 text-[13px] text-mist-100">
                                <span aria-hidden>{item.flag}</span>
                                {item.label}
                              </span>
                              <span className="mt-1 block font-mono text-[10px] text-mist-500">
                                DLR {item.dlr}%
                              </span>
                            </button>
                          );
                        })}
                      </div>
                    </div>

                    <label className="flex cursor-pointer items-center justify-between gap-4 rounded-xl border border-white/10 bg-ink-950/40 p-3.5">
                      <span>
                        <span className="block text-[13.5px] font-semibold text-mist-100">
                          Suppress opted-out numbers
                        </span>
                        <span className="mt-0.5 block text-[12.5px] text-mist-500">
                          Removes 1,204 previously unsubscribed contacts from this send.
                        </span>
                      </span>
                      <span className="relative inline-flex shrink-0">
                        <input
                          type="checkbox"
                          className="peer sr-only"
                          checked={suppress}
                          onChange={(e) => setSuppress(e.target.checked)}
                        />
                        <span className="block h-6 w-11 rounded-full bg-white/12 transition peer-checked:bg-signal-400/80 peer-focus-visible:outline peer-focus-visible:outline-2 peer-focus-visible:outline-signal-400" />
                        <span className="absolute left-0.5 top-0.5 size-5 rounded-full bg-mist-50 transition-transform duration-300 peer-checked:translate-x-5" />
                      </span>
                    </label>
                  </div>
                )}

                {tab === "schedule" && (
                  <div role="tabpanel" id="panel-schedule" aria-labelledby="tab-schedule" className="space-y-6 animate-rise">
                    <div className="grid gap-2 sm:grid-cols-2">
                      {(
                        [
                          { id: "instant", label: "Send now", copy: "Hits the carrier queue immediately.", icon: IconBolt },
                          { id: "scheduled", label: "Schedule", copy: "Queue for a future local time.", icon: IconCalendar },
                        ] as const
                      ).map((option) => {
                        const active = when === option.id;
                        return (
                          <button
                            key={option.id}
                            type="button"
                            onClick={() => setWhen(option.id)}
                            aria-pressed={active}
                            className={`rounded-2xl border p-4 text-left transition-all duration-300 ${
                              active
                                ? "border-signal-400/55 bg-signal-400/10"
                                : "border-white/10 bg-ink-950/40 hover:border-white/24"
                            }`}
                          >
                            <option.icon className={`size-5 ${active ? "text-signal-300" : "text-mist-400"}`} />
                            <span className="mt-3 block text-[14px] font-semibold text-mist-100">{option.label}</span>
                            <span className="mt-1 block text-[12.5px] leading-relaxed text-mist-500">{option.copy}</span>
                          </button>
                        );
                      })}
                    </div>

                    <div>
                      <div className="flex items-baseline justify-between">
                        <label htmlFor="studio-throttle" className="text-[12.5px] font-medium text-mist-200">
                          Throttle
                        </label>
                        <span className="font-mono text-[13px] text-signal-300 tabular-nums">
                          {formatNumber(throttle)} msg/s
                        </span>
                      </div>
                      <input
                        id="studio-throttle"
                        type="range"
                        min={50}
                        max={5000}
                        step={50}
                        value={throttle}
                        onChange={(e) => setThrottle(Number(e.target.value))}
                        className="mt-3 h-1.5 w-full cursor-pointer appearance-none rounded-full bg-white/12 accent-signal-400
                          [&::-webkit-slider-thumb]:size-4 [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:rounded-full
                          [&::-webkit-slider-thumb]:bg-signal-400 [&::-webkit-slider-thumb]:shadow-[0_0_0_5px_rgba(56,232,172,0.18)]
                          [&::-moz-range-thumb]:size-4 [&::-moz-range-thumb]:rounded-full [&::-moz-range-thumb]:border-0 [&::-moz-range-thumb]:bg-signal-400"
                      />
                      <div className="mt-3 flex items-center gap-2 rounded-xl border border-white/8 bg-ink-950/40 px-3.5 py-3">
                        <IconTarget className="size-4 shrink-0 text-pulse-300" />
                        <span className="text-[13px] text-mist-300">
                          Full send completes in about{" "}
                          <span className="font-mono text-signal-300">
                            {etaMinutes(recipients * analysis.segments, throttle)}
                          </span>{" "}
                          — quiet hours respected per region.
                        </span>
                      </div>
                    </div>
                  </div>
                )}

                {tab === "analyse" && (
                  <div role="tabpanel" id="panel-analyse" aria-labelledby="tab-analyse" className="animate-rise">
                    <div className="grid gap-3 sm:grid-cols-2">
                      {[
                        { label: "Projected delivery", value: `${region.dlr}%`, icon: IconPulse },
                        { label: "Cost per recipient", value: `$${perRecipient.toFixed(4)}`, icon: IconTarget },
                        { label: "Segments each", value: `${analysis.segments}×`, icon: IconBolt },
                        { label: "Basket required", value: formatNumber(basket), icon: IconGauge },
                      ].map((item) => (
                        <div
                          key={item.label}
                          className="rounded-2xl border border-white/10 bg-ink-950/40 p-4 transition hover:border-signal-400/30"
                        >
                          <item.icon className="size-4.5 text-signal-300" />
                          <p className="mt-3 font-display text-[22px] leading-none text-mist-50 tabular-nums">
                            {item.value}
                          </p>
                          <p className="mt-1.5 font-mono text-[10px] tracking-[0.16em] text-mist-500 uppercase">
                            {item.label}
                          </p>
                        </div>
                      ))}
                    </div>

                    <div className="mt-5 space-y-2 rounded-2xl border border-white/10 bg-ink-950/40 p-4">
                      {[
                        { s: "Queued", d: "0.0s", w: "100%" },
                        { s: "Submitted to carrier", d: "0.3s", w: "99.6%" },
                        { s: "Delivered to handset", d: "1.4s", w: `${region.dlr}%` },
                        { s: "Read (estimated)", d: "—", w: "94%" },
                      ].map((row, i) => (
                        <div key={row.s} className="flex items-center gap-3">
                          <span className="w-40 shrink-0 text-[12.5px] text-mist-300 sm:w-48">{row.s}</span>
                          <span className="h-1.5 flex-1 overflow-hidden rounded-full bg-white/8">
                            <span
                              className="block h-full rounded-full bg-gradient-to-r from-signal-400 to-pulse-400"
                              style={{ width: row.w, transitionDelay: `${i * 90}ms` }}
                            />
                          </span>
                          <span className="w-12 shrink-0 text-right font-mono text-[11px] text-mist-500">{row.d}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          </Reveal>

          {/* preview + buy */}
          <Reveal delay={120}>
            <div className="lg:sticky lg:top-28">
              <div className="glass overflow-hidden rounded-3xl p-5 sm:p-6">
                <p className="font-mono text-[10px] tracking-[0.2em] text-mist-500 uppercase">
                  Handset preview
                </p>
                <div className="mt-4 rounded-[1.6rem] border border-white/10 bg-ink-950/70 p-4">
                  <div className="flex items-center justify-between border-b border-white/8 pb-3">
                    <span className="font-mono text-[10.5px] tracking-[0.16em] text-mist-500 uppercase">
                      {senderId || "SENDER ID"}
                    </span>
                    <span className="font-mono text-[10.5px] text-signal-300">now</span>
                  </div>
                  <p className="mt-3 text-[13.5px] leading-relaxed text-mist-100">
                    {message || "Your message preview appears here…"}
                  </p>
                  <div className="mt-4 flex items-center gap-2">
                    <span className="flex items-center gap-1 rounded-full bg-signal-400/12 px-2 py-0.5 font-mono text-[10px] text-signal-300">
                      <IconCheck className="size-2.5" strokeWidth={3} /> Delivered
                    </span>
                    <span className="font-mono text-[10px] text-mist-600">
                      {analysis.encoding} · {analysis.segments} part{analysis.segments > 1 ? "s" : ""}
                    </span>
                  </div>
                </div>

                <dl className="mt-5 space-y-1 border-t border-white/8 pt-4">
                  {[
                    ["Message parts", formatNumber(parts)],
                    ["Recommended basket", `${formatNumber(basket)} credits`],
                    ["Rate", `${(rateTenths / 1000).toFixed(4)} / SMS`],
                    ["Region multiplier", `${region.rate.toFixed(2)}× ${region.label}`],
                  ].map(([k, v]) => (
                    <div key={k} className="flex items-baseline justify-between gap-3 py-1.5">
                      <dt className="text-[12.5px] text-mist-400">{k}</dt>
                      <dd className="font-mono text-[12.5px] text-mist-100 tabular-nums">{v}</dd>
                    </div>
                  ))}
                </dl>

                <div className="mt-4 flex items-end justify-between border-t border-white/8 pt-4">
                  <span className="text-[12.5px] text-mist-400">Basket total</span>
                  <span className="font-display text-[26px] leading-none text-signal-300 tabular-nums">
                    {formatMoney(cost)}
                  </span>
                </div>

                <button
                  type="button"
                  onClick={() =>
                    openOrder({
                      planId,
                      credits: basket,
                      recipients,
                      senderId,
                      message,
                      campaignName: `${region.label} campaign`,
                      schedule: when,
                    })
                  }
                  className="shine group relative mt-5 flex w-full items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-signal-400 to-pulse-400 px-5 py-4 text-[14.5px] font-semibold text-ink-950 transition-all duration-300 hover:-translate-y-0.5 hover:shadow-[0_22px_50px_-22px_rgba(56,232,172,0.9)]"
                >
                  <span className="shine-bar" />
                  Add {formatNumber(basket)} credits to my order
                  <IconArrow className="size-4 transition-transform duration-300 group-hover:translate-x-1" />
                </button>
                <p className="mt-3 text-center font-mono text-[10.5px] text-mist-600">
                  {suppress ? "Opt-outs suppressed · " : ""}No card needed to reserve credits
                </p>
              </div>
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}

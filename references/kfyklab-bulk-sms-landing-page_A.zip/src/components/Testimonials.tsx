"use client";

import { useState } from "react";
import Image from "next/image";
import { Eyebrow, Reveal, useCountUp, useInView } from "@/components/motion";
import { IconCheck, IconSparkle } from "@/components/icons";

type Testimonial = {
  quote: string;
  name: string;
  role: string;
  city: string;
  avatar: string;
  metric: string;
  metricLabel: string;
  tilt: string;
};

const px = (id: number) =>
  `https://images.pexels.com/photos/${id}/pexels-photo-${id}.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=240&w=240`;

const ITEMS: Testimonial[] = [
  {
    quote:
      "We dropped a 48,000-message flash sale on a Friday evening. Every single one landed in six minutes and the redemption codes told us exactly which cohort moved. That weekend beat our entire previous month.",
    name: "Amara Nwosu",
    role: "Head of Growth, Zanara Retail",
    city: "Lagos",
    avatar: px(19537356),
    metric: "+31%",
    metricLabel: "revenue vs. previous drop",
    tilt: "-rotate-[1.1deg]",
  },
  {
    quote:
      "OTP delivery was our churn engine — 91% on the old aggregator, constant support tickets. Kfyklab's direct route took us to 99.3% and the signed webhooks reconcile against our ledger automatically.",
    name: "Daniel Kiptoo",
    role: "CTO, Paylent Financial",
    city: "Nairobi",
    avatar: px(28442318),
    metric: "99.3%",
    metricLabel: "OTP delivery rate",
    tilt: "rotate-[0.9deg]",
  },
  {
    quote:
      "Appointment reminders cut our no-shows by more than a third. I did not believe the Sender ID would be approved overnight in the UAE — it was, and patients now recognise us before they open the message.",
    name: "Dr. Leila Haddad",
    role: "Operations Lead, Bloom Clinic",
    city: "Dubai",
    avatar: px(37272329),
    metric: "−38%",
    metricLabel: "missed appointments",
    tilt: "-rotate-[0.7deg]",
  },
  {
    quote:
      "I ordered 250,000 credits on a Tuesday, migrated three brands onto the API by Thursday, and cancelled our old contract the same week. The throttling controls alone saved our call centre during peak.",
    name: "Thabo Mokoena",
    role: "Ecommerce Director, Ridewave",
    city: "Cape Town",
    avatar: px(16764124),
    metric: "3 days",
    metricLabel: "full API migration",
    tilt: "rotate-[1.2deg]",
  },
  {
    quote:
      "The refund-on-failure policy is the thing nobody else offers. We sent to a stale list of 60,000 and got 4,120 credits back in under an hour without opening a single ticket.",
    name: "Fatima Bello",
    role: "Marketing Manager, Sokoni Foods",
    city: "Accra",
    avatar: px(25651531),
    metric: "4,120",
    metricLabel: "credits auto-refunded",
    tilt: "-rotate-[1deg]",
  },
  {
    quote:
      "We ship 1.2 million logistics updates a month across four countries. One invoice, one dashboard, one engineer on speed dial. It is the first SMS vendor my finance team has never complained about.",
    name: "Rajesh Menon",
    role: "Founder, Sasa Express",
    city: "Mumbai",
    avatar: px(14950779),
    metric: "1.2M",
    metricLabel: "messages / month",
    tilt: "rotate-[0.8deg]",
  },
];

function Avatar({ src, name }: { src: string; name: string }) {
  const [failed, setFailed] = useState(false);
  const initials = name
    .replace(/^Dr\.\s*/, "")
    .split(" ")
    .filter((word) => word.length > 0)
    .slice(0, 2)
    .map((word) => word[0]?.toUpperCase() ?? "")
    .join("");

  return (
    <span className="relative grid size-11 shrink-0 place-items-center overflow-hidden rounded-full bg-gradient-to-br from-signal-400/35 via-ink-700 to-pulse-400/30 ring-1 ring-white/12 transition duration-500 group-hover:ring-signal-400/50">
      <span className="font-display text-[13px] font-bold text-mist-50">{initials}</span>
      {!failed && (
        <Image
          src={src}
          alt={`Portrait of ${name}`}
          width={88}
          height={88}
          loading="lazy"
          onError={() => setFailed(true)}
          className="absolute inset-0 size-full object-cover transition-transform duration-700 group-hover:scale-110"
        />
      )}
    </span>
  );
}

function RatingPill() {
  const { ref, inView } = useInView<HTMLDivElement>({ threshold: 0.5 });
  const value = useCountUp(4.9, inView, 1400);
  const reviews = useCountUp(2318, inView, 1800);
  return (
    <div ref={ref} className="glass flex items-center gap-4 rounded-2xl px-5 py-4">
      <div className="flex gap-0.5 text-ember-400" aria-hidden>
        {Array.from({ length: 5 }).map((_, i) => (
          <svg key={i} viewBox="0 0 20 20" className="size-4 fill-current">
            <path d="M10 1.6 12.4 7l5.9.5-4.5 3.9 1.4 5.8L10 14.1l-5.2 3.1 1.4-5.8L1.7 7.5 7.6 7Z" />
          </svg>
        ))}
      </div>
      <p className="text-[13.5px] text-mist-300">
        <span className="font-display text-[17px] font-bold text-mist-50 tabular-nums">
          {value.toFixed(1)}
        </span>{" "}
        average from{" "}
        <span className="font-semibold text-mist-100 tabular-nums">
          {Math.round(reviews).toLocaleString("en-US")}
        </span>{" "}
        verified senders
      </p>
    </div>
  );
}

export function Testimonials() {
  return (
    <section
      id="testimonials"
      className="relative scroll-mt-24 overflow-hidden border-t border-white/6 py-20 sm:py-28"
    >
      <div aria-hidden className="pointer-events-none absolute inset-0 -z-10">
        <div className="absolute right-[10%] top-0 size-[26rem] animate-drift-slow rounded-full bg-ember-500/7 blur-[130px]" />
      </div>

      <div className="mx-auto w-full max-w-[86rem] px-4 sm:px-6">
        <div className="flex flex-col gap-8 lg:flex-row lg:items-end lg:justify-between">
          <div className="max-w-2xl">
            <Reveal>
              <Eyebrow tone="ember">Proof, not promises</Eyebrow>
            </Reveal>
            <Reveal delay={80}>
              <h2 className="mt-5 font-display text-[clamp(2rem,5vw,3.3rem)] font-bold leading-[1.03] tracking-[-0.035em] text-mist-50">
                Senders who stopped guessing <span className="aqua-text">where messages die</span>.
              </h2>
            </Reveal>
          </div>
          <Reveal delay={140}>
            <RatingPill />
          </Reveal>
        </div>

        <div className="mt-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {ITEMS.map((item, index) => (
            <Reveal key={item.name} delay={index * 90}>
              <figure
                className={`group relative flex h-full flex-col rounded-3xl border border-white/9 bg-gradient-to-b from-ink-850/90 to-ink-900/70 p-6 transition-all duration-500 [transition-timing-function:var(--ease-out-expo)] hover:-translate-y-1.5 hover:border-signal-400/30 hover:shadow-[0_40px_90px_-50px_rgba(56,232,172,0.75)] sm:p-7 ${item.tilt} hover:rotate-0`}
              >
                <span
                  aria-hidden
                  className="pointer-events-none absolute right-6 top-4 font-display text-[64px] leading-none text-white/5 transition-colors duration-500 group-hover:text-signal-400/12"
                >
                  &rdquo;
                </span>

                <div className="flex items-center gap-1.5 text-ember-400" aria-label="Rated 5 out of 5">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <svg key={i} viewBox="0 0 20 20" className="size-3 fill-current">
                      <path d="M10 1.6 12.4 7l5.9.5-4.5 3.9 1.4 5.8L10 14.1l-5.2 3.1 1.4-5.8L1.7 7.5 7.6 7Z" />
                    </svg>
                  ))}
                </div>

                <blockquote className="mt-4 flex-1 text-[14.5px] leading-relaxed text-mist-200">
                  {item.quote}
                </blockquote>

                <div className="mt-6 flex items-center gap-2.5 rounded-2xl border border-signal-400/18 bg-signal-400/6 px-3.5 py-2.5">
                  <IconSparkle className="size-4 shrink-0 text-signal-300" />
                  <span className="font-display text-[17px] leading-none text-signal-300 tabular-nums">
                    {item.metric}
                  </span>
                  <span className="font-mono text-[10px] tracking-[0.14em] text-mist-400 uppercase">
                    {item.metricLabel}
                  </span>
                </div>

                <figcaption className="mt-5 flex items-center gap-3 border-t border-white/8 pt-5">
                  <Avatar src={item.avatar} name={item.name} />
                  <span className="min-w-0">
                    <span className="block truncate text-[13.5px] font-semibold text-mist-50">
                      {item.name}
                    </span>
                    <span className="block truncate text-[12px] text-mist-500">{item.role}</span>
                  </span>
                  <span className="ml-auto shrink-0 rounded-full border border-white/10 px-2.5 py-1 font-mono text-[10px] text-mist-500">
                    {item.city}
                  </span>
                </figcaption>
              </figure>
            </Reveal>
          ))}
        </div>

        <Reveal delay={120}>
          <div className="mt-10 flex flex-wrap items-center justify-center gap-x-8 gap-y-3 rounded-2xl border border-white/8 bg-ink-900/50 px-6 py-5">
            {[
              "SOC 2 Type II in progress",
              "GDPR & NDPR aligned",
              "DPA signed on request",
              "Opt-out honoured in 200ms",
            ].map((item) => (
              <span key={item} className="flex items-center gap-2 text-[12.5px] text-mist-400">
                <IconCheck className="size-3.5 text-signal-400" strokeWidth={2.4} />
                {item}
              </span>
            ))}
          </div>
        </Reveal>
      </div>
    </section>
  );
}

"use client";

import { useState } from "react";
import { Eyebrow, Reveal } from "@/components/motion";
import { IconArrow, IconCheck, IconLock, IconSearch } from "@/components/icons";
import { formatMoney, formatNumber } from "@/lib/plans";

type TrackedOrder = {
  orderNumber: string;
  status: string;
  planName: string;
  credits: number;
  totalCents: number;
  currency: string;
  senderId: string | null;
  campaignName: string | null;
  schedule: string;
  scheduledAt: string | null;
  paymentMethod: string;
  country: string;
  createdAt: string;
};

const RAIL = [
  { id: "pending", label: "Order received", copy: "Credits reserved" },
  { id: "paid", label: "Payment cleared", copy: "Balance funded" },
  { id: "processing", label: "Sender ID filing", copy: "Operator approval" },
  { id: "delivered", label: "Live & sending", copy: "Receipts streaming" },
];

export function TrackOrder() {
  const [ref, setRef] = useState("");
  const [email, setEmail] = useState("");
  const [state, setState] = useState<"idle" | "loading" | "done" | "error">("idle");
  const [message, setMessage] = useState("");
  const [order, setOrder] = useState<TrackedOrder | null>(null);

  const submit = async (event: React.FormEvent) => {
    event.preventDefault();
    const reference = ref.trim().toUpperCase();
    if (reference.length < 4) {
      setState("error");
      setMessage("Enter the order number from your confirmation, e.g. KFY-8QK2M1-4XA.");
      return;
    }
    setState("loading");
    setMessage("");
    try {
      const params = email.trim() ? `?email=${encodeURIComponent(email.trim())}` : "";
      const response = await fetch(`/api/orders/${encodeURIComponent(reference)}${params}`);
      const data = await response.json();
      if (!response.ok || !data.ok) {
        setState("error");
        setMessage(data?.error ?? "We could not find that order.");
        setOrder(null);
        return;
      }
      setOrder(data.order as TrackedOrder);
      setState("done");
    } catch {
      setState("error");
      setMessage("Network hiccup. Try again in a moment.");
    }
  };

  const activeIndex = order ? Math.max(0, RAIL.findIndex((s) => s.id === order.status)) : -1;

  return (
    <section id="track" className="relative scroll-mt-24 overflow-hidden border-t border-white/6 py-20 sm:py-28">
      <div aria-hidden className="pointer-events-none absolute inset-0 -z-10">
        <div className="absolute inset-0 grid-lines opacity-25 mask-fade-b" />
        <div className="absolute right-[6%] top-[12%] size-[26rem] animate-drift rounded-full bg-pulse-500/10 blur-[120px]" />
      </div>

      <div className="mx-auto w-full max-w-[86rem] px-4 sm:px-6">
        <div className="grid gap-10 lg:grid-cols-[0.95fr_1.05fr] lg:gap-16">
          <div>
            <Reveal>
              <Eyebrow>Order tracking</Eyebrow>
            </Reveal>
            <Reveal delay={80}>
              <h2 className="mt-5 font-display text-[clamp(2rem,4.8vw,3.1rem)] font-bold leading-[1.04] tracking-[-0.035em] text-mist-50">
                Follow your order from <span className="aqua-text">checkout to carrier</span>.
              </h2>
            </Reveal>
            <Reveal delay={140}>
              <p className="mt-5 max-w-md text-[15.5px] leading-relaxed text-mist-400">
                Every order gets a reference the moment it is placed. Enter it below to see payment
                status, Sender ID filing progress and when your credits go live.
              </p>
            </Reveal>

            <Reveal delay={200}>
              <ol className="mt-8 space-y-3">
                {RAIL.map((stage, index) => {
                  const reached = index <= activeIndex;
                  const current = index === activeIndex;
                  return (
                    <li key={stage.id} className="flex items-start gap-3.5">
                      <span className="relative mt-0.5 grid size-7 shrink-0 place-items-center">
                        {current && (
                          <span className="absolute inset-0 animate-ring rounded-full border border-signal-400/60" />
                        )}
                        <span
                          className={`grid size-6 place-items-center rounded-full border transition-all duration-500 ${
                            reached
                              ? "border-signal-400/60 bg-signal-400/18 text-signal-300"
                              : "border-white/14 text-mist-600"
                          }`}
                        >
                          {reached ? (
                            <IconCheck className="size-3" strokeWidth={3} />
                          ) : (
                            <span className="font-mono text-[10px]">{index + 1}</span>
                          )}
                        </span>
                      </span>
                      <span>
                        <span
                          className={`block text-[14px] font-semibold transition-colors duration-500 ${
                            reached ? "text-mist-50" : "text-mist-500"
                          }`}
                        >
                          {stage.label}
                        </span>
                        <span className="block text-[12.5px] text-mist-600">{stage.copy}</span>
                      </span>
                    </li>
                  );
                })}
              </ol>
            </Reveal>
          </div>

          <Reveal delay={120}>
            <form onSubmit={submit} className="glass rounded-3xl p-6 sm:p-8" noValidate>
              <label htmlFor="track-ref" className="block text-[12.5px] font-medium text-mist-200">
                Order number
              </label>
              <div className="mt-2 flex flex-col gap-2.5 sm:flex-row">
                <div className="relative flex-1">
                  <IconSearch className="pointer-events-none absolute left-3.5 top-1/2 size-4 -translate-y-1/2 text-mist-500" />
                  <input
                    id="track-ref"
                    className="field pl-10 font-mono tracking-[0.12em] uppercase"
                    placeholder="KFY-8QK2M1-4XA"
                    value={ref}
                    autoComplete="off"
                    onChange={(event) => setRef(event.target.value.toUpperCase())}
                  />
                </div>
                <button
                  type="submit"
                  disabled={state === "loading"}
                  className="shine group relative flex items-center justify-center gap-2 rounded-xl bg-mist-50 px-5 py-3 text-[13.5px] font-semibold text-ink-950 transition hover:bg-signal-300 disabled:opacity-70"
                >
                  <span className="shine-bar" />
                  {state === "loading" ? (
                    <>
                      <span className="size-4 animate-spin rounded-full border-2 border-ink-950/30 border-t-ink-950" />
                      Searching
                    </>
                  ) : (
                    <>
                      Track
                      <IconArrow className="size-4 transition-transform group-hover:translate-x-0.5" />
                    </>
                  )}
                </button>
              </div>

              <label htmlFor="track-email" className="mt-4 block text-[12.5px] font-medium text-mist-200">
                Email on the order{" "}
                <span className="font-mono text-[10.5px] font-normal text-mist-600">optional · extra security</span>
              </label>
              <input
                id="track-email"
                type="email"
                className="field mt-2"
                placeholder="you@company.com"
                value={email}
                autoComplete="email"
                onChange={(event) => setEmail(event.target.value)}
              />

              <div aria-live="polite" className="mt-5 min-h-[7rem]">
                {state === "error" && (
                  <p className="animate-rise rounded-xl border border-ember-400/30 bg-ember-400/10 px-4 py-3 text-[13px] text-ember-300">
                    {message}
                  </p>
                )}

                {state === "done" && order && (
                  <div className="animate-rise rounded-2xl border border-signal-400/25 bg-signal-400/[0.07] p-5">
                    <div className="flex flex-wrap items-center justify-between gap-3">
                      <span className="font-mono text-[13px] tracking-[0.12em] text-signal-300">
                        {order.orderNumber}
                      </span>
                      <span className="rounded-full bg-signal-400/18 px-3 py-1 font-mono text-[10.5px] tracking-[0.16em] text-signal-200 uppercase">
                        {order.status}
                      </span>
                    </div>
                    <dl className="mt-4 grid gap-x-6 gap-y-2 sm:grid-cols-2">
                      {[
                        ["Package", `${order.planName} · ${formatNumber(order.credits)} credits`],
                        ["Amount", `${formatMoney(order.totalCents, order.currency)}`],
                        ["Sender ID", order.senderId ?? "Not submitted"],
                        ["Campaign", order.campaignName ?? "—"],
                        ["Destination", order.country],
                        [
                          "Schedule",
                          order.schedule === "scheduled"
                            ? order.scheduledAt ?? "Scheduled"
                            : "Immediate",
                        ],
                      ].map(([k, v]) => (
                        <div key={k} className="flex items-baseline justify-between gap-3">
                          <dt className="text-[12.5px] text-mist-500">{k}</dt>
                          <dd className="text-right font-mono text-[12.5px] text-mist-100">{v}</dd>
                        </div>
                      ))}
                    </dl>
                    <p className="mt-4 flex items-center gap-2 border-t border-white/10 pt-3 font-mono text-[10.5px] text-mist-500">
                      <IconLock className="size-3" />
                      Placed {new Date(order.createdAt).toLocaleString("en-GB", { dateStyle: "medium", timeStyle: "short" })}
                    </p>
                  </div>
                )}

                {state === "idle" && (
                  <p className="rounded-xl border border-white/8 bg-ink-950/40 px-4 py-3 text-[12.5px] leading-relaxed text-mist-500">
                    Try <button type="button" className="font-mono text-signal-300 underline decoration-signal-400/40 underline-offset-4 transition hover:text-signal-200" onClick={() => setRef("KFY-DEMO-002")}>KFY-DEMO-002</button>{" "}
                    to see a live order in progress.
                  </p>
                )}
              </div>
            </form>
          </Reveal>
        </div>
      </div>
    </section>
  );
}

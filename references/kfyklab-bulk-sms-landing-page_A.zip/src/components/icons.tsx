import type { SVGProps } from "react";

type IconProps = SVGProps<SVGSVGElement>;

const base = (props: IconProps) => ({
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: 1.6,
  strokeLinecap: "round" as const,
  strokeLinejoin: "round" as const,
  "aria-hidden": true,
  ...props,
});

export function LogoMark({ className = "", ...props }: IconProps) {
  return (
    <svg viewBox="0 0 40 40" className={className} aria-hidden {...props}>
      <defs>
        <linearGradient id="kfy-mark" x1="4" y1="4" x2="36" y2="36" gradientUnits="userSpaceOnUse">
          <stop stopColor="#7BF7D0" />
          <stop offset="0.55" stopColor="#38E8AC" />
          <stop offset="1" stopColor="#4CC4F0" />
        </linearGradient>
      </defs>
      <rect x="1.2" y="1.2" width="37.6" height="37.6" rx="12" fill="#070A10" stroke="url(#kfy-mark)" strokeOpacity="0.5" />
      <path
        d="M12 10v20M12 20.4 24.5 10M15.4 18.1 26 30"
        stroke="url(#kfy-mark)"
        strokeWidth="2.6"
        strokeLinecap="round"
        strokeLinejoin="round"
        fill="none"
      />
      <circle cx="27.4" cy="13.2" r="2.4" fill="#FFB35C" />
    </svg>
  );
}

export const IconBolt = (p: IconProps) => (
  <svg {...base(p)}>
    <path d="M13.2 2.5 4.8 13.1a.7.7 0 0 0 .55 1.13h5.1l-.65 7.02a.5.5 0 0 0 .88.36l8.4-10.6a.7.7 0 0 0-.55-1.13h-5.1l.65-7.02a.5.5 0 0 0-.88-.36Z" />
  </svg>
);

export const IconRoute = (p: IconProps) => (
  <svg {...base(p)}>
    <circle cx="6" cy="6" r="2.6" />
    <circle cx="18" cy="18" r="2.6" />
    <path d="M8.6 6h4.9a3.5 3.5 0 0 1 0 7H10a3.5 3.5 0 0 0 0 5h5.4" />
    <path d="m16.6 16.6 1.4 1.4-1.4 1.4" />
  </svg>
);

export const IconShield = (p: IconProps) => (
  <svg {...base(p)}>
    <path d="M12 2.8 4.8 5.6v6c0 4.3 2.9 8.2 7.2 9.6 4.3-1.4 7.2-5.3 7.2-9.6v-6Z" />
    <path d="m9.2 11.9 2 2 3.6-3.9" />
  </svg>
);

export const IconGlobe = (p: IconProps) => (
  <svg {...base(p)}>
    <circle cx="12" cy="12" r="9.2" />
    <path d="M2.9 12h18.2M12 2.8c2.4 2.5 3.7 5.7 3.7 9.2s-1.3 6.7-3.7 9.2c-2.4-2.5-3.7-5.7-3.7-9.2S9.6 5.3 12 2.8Z" />
  </svg>
);

export const IconPulse = (p: IconProps) => (
  <svg {...base(p)}>
    <path d="M2.8 12.4h3.9l2-5.6 3.3 11 2.4-7 1.6 3.4h5.2" />
  </svg>
);

export const IconCode = (p: IconProps) => (
  <svg {...base(p)}>
    <path d="m8.4 7.6-5 4.4 5 4.4M15.6 7.6l5 4.4-5 4.4M13.6 4.2l-3.2 15.6" />
  </svg>
);

export const IconCalendar = (p: IconProps) => (
  <svg {...base(p)}>
    <rect x="3.4" y="5" width="17.2" height="15.6" rx="3" />
    <path d="M3.4 9.8h17.2M8.2 3.2v3.4M15.8 3.2v3.4M8 14h2.4M13.6 14H16" />
  </svg>
);

export const IconAudience = (p: IconProps) => (
  <svg {...base(p)}>
    <circle cx="9" cy="8.4" r="3.4" />
    <path d="M2.9 19.6c.6-3.3 3.1-5.2 6.1-5.2s5.5 1.9 6.1 5.2" />
    <path d="M16.4 5.6a3.2 3.2 0 0 1 .3 6.2M18.1 14.9c2.1.6 3.5 2.3 3.9 4.7" />
  </svg>
);

export const IconHandset = (p: IconProps) => (
  <svg {...base(p)}>
    <rect x="6.6" y="2.6" width="10.8" height="18.8" rx="2.6" />
    <path d="M10.6 5.4h2.8M9.4 18.6h5.2" />
  </svg>
);

export const IconLayers = (p: IconProps) => (
  <svg {...base(p)}>
    <path d="m12 3.2 8.6 4.4L12 12 3.4 7.6Z" />
    <path d="m3.4 12 8.6 4.4L20.6 12M3.4 16.4 12 20.8l8.6-4.4" />
  </svg>
);

export const IconClock = (p: IconProps) => (
  <svg {...base(p)}>
    <circle cx="12" cy="12" r="9.1" />
    <path d="M12 7v5.3l3.4 2" />
  </svg>
);

export const IconCheck = (p: IconProps) => (
  <svg {...base(p)}>
    <path d="m4.8 12.6 4.6 4.6L19.4 6.8" />
  </svg>
);

export const IconArrow = (p: IconProps) => (
  <svg {...base(p)}>
    <path d="M4.6 12h14.2M13.4 6.6 18.8 12l-5.4 5.4" />
  </svg>
);

export const IconPlus = (p: IconProps) => (
  <svg {...base(p)}>
    <path d="M12 5v14M5 12h14" />
  </svg>
);

export const IconMinus = (p: IconProps) => (
  <svg {...base(p)}>
    <path d="M5 12h14" />
  </svg>
);

export const IconClose = (p: IconProps) => (
  <svg {...base(p)}>
    <path d="m6.4 6.4 11.2 11.2M17.6 6.4 6.4 17.6" />
  </svg>
);

export const IconLock = (p: IconProps) => (
  <svg {...base(p)}>
    <rect x="4.6" y="10.2" width="14.8" height="10.4" rx="2.8" />
    <path d="M8.2 10.2V7.6a3.8 3.8 0 0 1 7.6 0v2.6M12 14.4v2.4" />
  </svg>
);

export const IconCard = (p: IconProps) => (
  <svg {...base(p)}>
    <rect x="2.8" y="5.4" width="18.4" height="13.2" rx="2.8" />
    <path d="M2.8 10h18.4M6.4 14.6h3.4" />
  </svg>
);

export const IconBank = (p: IconProps) => (
  <svg {...base(p)}>
    <path d="m3.4 9.4 8.6-5 8.6 5M5.4 9.4v8.4M9.6 9.4v8.4M14.4 9.4v8.4M18.6 9.4v8.4M3 20.4h18" />
  </svg>
);

export const IconWallet = (p: IconProps) => (
  <svg {...base(p)}>
    <path d="M3.4 7.6A2.6 2.6 0 0 1 6 5h11.2a2.4 2.4 0 0 1 2.4 2.4v1.2" />
    <rect x="3.4" y="7.6" width="17.2" height="11.4" rx="2.6" />
    <circle cx="16.4" cy="13.3" r="1.2" fill="currentColor" stroke="none" />
  </svg>
);

export const IconInvoice = (p: IconProps) => (
  <svg {...base(p)}>
    <path d="M6 2.8h12v18.4l-2.4-1.6-2.4 1.6-2.4-1.6-2.4 1.6L6 21.2Z" />
    <path d="M9.4 7.6h5.2M9.4 11.4h5.2M9.4 15.2h3" />
  </svg>
);

export const IconSignal = (p: IconProps) => (
  <svg {...base(p)}>
    <path d="M4 20v-4.6M9.3 20V11M14.7 20V7.2M20 20V3.4" />
  </svg>
);

export const IconTarget = (p: IconProps) => (
  <svg {...base(p)}>
    <circle cx="12" cy="12" r="8.8" />
    <circle cx="12" cy="12" r="4.6" />
    <circle cx="12" cy="12" r="1" fill="currentColor" stroke="none" />
  </svg>
);

export const IconSparkle = (p: IconProps) => (
  <svg {...base(p)}>
    <path d="M12 3.2c.9 4.4 2.5 6 6.9 6.9-4.4.9-6 2.5-6.9 6.9-.9-4.4-2.5-6-6.9-6.9 4.4-.9 6-2.5 6.9-6.9Z" />
    <path d="M18.4 15.4c.4 2 1.1 2.7 3.1 3.1-2 .4-2.7 1.1-3.1 3.1-.4-2-1.1-2.7-3.1-3.1 2-.4 2.7-1.1 3.1-3.1Z" />
  </svg>
);

export const IconSearch = (p: IconProps) => (
  <svg {...base(p)}>
    <circle cx="10.8" cy="10.8" r="6.6" />
    <path d="m15.6 15.6 4.2 4.2" />
  </svg>
);

export const IconMenu = (p: IconProps) => (
  <svg {...base(p)}>
    <path d="M4 7.5h16M4 12h16M4 16.5h11" />
  </svg>
);

export const IconChat = (p: IconProps) => (
  <svg {...base(p)}>
    <path d="M20.6 12.4c0 4-3.86 7.2-8.6 7.2a10 10 0 0 1-2.7-.36L4.4 21l1.2-3.4A6.7 6.7 0 0 1 3.4 12.4c0-4 3.86-7.2 8.6-7.2s8.6 3.2 8.6 7.2Z" />
    <path d="M8.8 12h.01M12 12h.01M15.2 12h.01" strokeWidth="2.2" />
  </svg>
);

export const IconGauge = (p: IconProps) => (
  <svg {...base(p)}>
    <path d="M3.6 17.4a9.2 9.2 0 1 1 16.8 0" />
    <path d="m12 13.6 4-4.2" />
    <circle cx="12" cy="14.6" r="1.5" fill="currentColor" stroke="none" />
  </svg>
);

export const IconDoc = (p: IconProps) => (
  <svg {...base(p)}>
    <path d="M13.4 3H7a2.4 2.4 0 0 0-2.4 2.4v13.2A2.4 2.4 0 0 0 7 21h10a2.4 2.4 0 0 0 2.4-2.4V9Z" />
    <path d="M13.4 3v6h6M8.6 13.4h6.8M8.6 17h4.4" />
  </svg>
);

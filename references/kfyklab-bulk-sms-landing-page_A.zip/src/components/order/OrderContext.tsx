"use client";

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";
import { OrderDrawer } from "./OrderDrawer";
import { analyseMessage } from "@/lib/sms";
import { PLANS, totalCentsFor, pricePerSmsTenthsFor } from "@/lib/plans";

export type Draft = {
  planId: string;
  planName: string;
  credits: number;
  senderId: string;
  campaignName: string;
  message: string;
  recipients: number;
  schedule: "instant" | "scheduled";
  scheduledAt: string;
};

export type Contact = {
  customerName: string;
  customerEmail: string;
  customerPhone: string;
  company: string;
  country: string;
  paymentMethod: string;
  notes: string;
  accepted: boolean;
};

export type OrderResult = {
  orderNumber: string;
  status: string;
  credits: number;
  totalCents: number;
  planName: string;
};

type OrderContextValue = {
  isOpen: boolean;
  step: number;
  draft: Draft;
  contact: Contact;
  segments: number;
  rateTenths: number;
  totalCents: number;
  submitting: boolean;
  error: string | null;
  result: OrderResult | null;
  openOrder: (prefill?: Partial<Draft>) => void;
  close: () => void;
  setStep: (step: number) => void;
  updateDraft: (patch: Partial<Draft>) => void;
  updateContact: (patch: Partial<Contact>) => void;
  submit: () => Promise<void>;
  reset: () => void;
};

const defaultDraft = (): Draft => ({
  planId: "surge",
  planName: "Surge",
  credits: 50_000,
  senderId: "",
  campaignName: "",
  message: "Hey {{first_name}} — your Kfyklab order is confirmed. Track it any time: kfyklab.com/t. Reply STOP to opt out.",
  recipients: 50_000,
  schedule: "instant",
  scheduledAt: "",
});

const defaultContact = (): Contact => ({
  customerName: "",
  customerEmail: "",
  customerPhone: "",
  company: "",
  country: "Kenya",
  paymentMethod: "card",
  notes: "",
  accepted: false,
});

const OrderContext = createContext<OrderContextValue | null>(null);

export function useOrder() {
  const ctx = useContext(OrderContext);
  if (!ctx) throw new Error("useOrder must be used inside <OrderProvider>");
  return ctx;
}

export function OrderProvider({ children }: { children: ReactNode }) {
  const [isOpen, setIsOpen] = useState(false);
  const [step, setStep] = useState(0);
  const [draft, setDraft] = useState<Draft>(defaultDraft);
  const [contact, setContact] = useState<Contact>(defaultContact);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<OrderResult | null>(null);

  const segments = analyseMessage(draft.message).segments;
  const rateTenths = pricePerSmsTenthsFor(draft.credits);
  const totalCents = totalCentsFor(draft.credits, segments);

  const openOrder = useCallback((prefill?: Partial<Draft>) => {
    setResult(null);
    setError(null);
    setStep(0);
    setDraft((current) => {
      const merged = { ...current, ...prefill };
      const plan = PLANS.find((p) => p.id === merged.planId);
      if (plan) merged.planName = plan.name;
      return merged;
    });
    setIsOpen(true);
  }, []);

  const close = useCallback(() => setIsOpen(false), []);

  const reset = useCallback(() => {
    setDraft(defaultDraft());
    setContact(defaultContact());
    setResult(null);
    setError(null);
    setStep(0);
  }, []);

  const updateDraft = useCallback((patch: Partial<Draft>) => {
    setDraft((current) => {
      const next = { ...current, ...patch };
      if (patch.planId) {
        const plan = PLANS.find((p) => p.id === patch.planId);
        if (plan) {
          next.planName = plan.name;
          next.credits = plan.credits;
          next.recipients = Math.min(next.recipients || plan.credits, plan.credits);
        }
      }
      return next;
    });
  }, []);

  const updateContact = useCallback((patch: Partial<Contact>) => {
    setContact((current) => ({ ...current, ...patch }));
  }, []);

  const submit = useCallback(async () => {
    setSubmitting(true);
    setError(null);
    try {
      const response = await fetch("/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...draft,
          segments,
          customerName: contact.customerName,
          customerEmail: contact.customerEmail,
          customerPhone: contact.customerPhone,
          company: contact.company,
          country: contact.country,
          paymentMethod: contact.paymentMethod,
          notes: contact.notes,
        }),
      });
      const data = await response.json();
      if (!response.ok || !data.ok) {
        throw new Error(data?.error ?? "Something went wrong while placing your order.");
      }
      setResult(data.order as OrderResult);
      setStep(3);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Network error — please try again.");
    } finally {
      setSubmitting(false);
    }
  }, [contact, draft, segments]);

  useEffect(() => {
    if (!isOpen) return;
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") setIsOpen(false);
    };
    document.addEventListener("keydown", onKey);
    const previous = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = previous;
    };
  }, [isOpen]);

  const value = useMemo<OrderContextValue>(
    () => ({
      isOpen,
      step,
      draft,
      contact,
      segments,
      rateTenths,
      totalCents,
      submitting,
      error,
      result,
      openOrder,
      close,
      setStep,
      updateDraft,
      updateContact,
      submit,
      reset,
    }),
    [
      isOpen,
      step,
      draft,
      contact,
      segments,
      rateTenths,
      totalCents,
      submitting,
      error,
      result,
      openOrder,
      close,
      submit,
      reset,
      updateDraft,
      updateContact,
    ],
  );

  return (
    <OrderContext.Provider value={value}>
      {children}
      <OrderDrawer />
    </OrderContext.Provider>
  );
}

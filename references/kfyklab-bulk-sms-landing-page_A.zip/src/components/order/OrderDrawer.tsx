"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { useOrder } from "./OrderContext";
import {
  COUNTRIES,
  PAYMENT_METHODS,
  PLANS,
  formatMoney,
  formatNumber,
  rateLabel,
} from "@/lib/plans";
import { SEGMENT_LADDER, analyseMessage, etaMinutes, nearestLadderIndex } from "@/lib/sms";
import {
  IconArrow,
  IconBank,
  IconBolt,
  IconCalendar,
  IconCard,
  IconCheck,
  IconClose,
  IconInvoice,
  IconLock,
  IconWallet,
  LogoMark,
} from "@/components/icons";

const STEP_LABELS = ["Package", "Campaign", "Checkout"];

const PAYMENT_ICONS: Record<string, typeof IconCard> = {
  card: IconCard,
  bank: IconBank,
  wallet: IconWallet,
  invoice: IconInvoice,
};

const THROUGHPUT: Record<string, number> = {
  spark: 60,
  surge: 300,
  orbit: 1200,
  atlas: 5000,
};

function Row({ label, value, accent }: { label: string; value: string; accent?: boolean }) {
  return (
    <div className="flex items-baseline justify-between gap-4 py-2">
      <span className="text-[13px] text-mist-400">{label}</span>
      <span
        className={`font-mono text-[13px] tabular-nums ${accent ? "text-signal-300" : "text-mist-100"}`}
      >
        {value}
      </span>
    </div>
  );
}

function Field({
  label,
  hint,
  error,
  children,
  required,
}: {
  label: string;
  hint?: string;
  error?: string;
  children: React.ReactNode;
  required?: boolean;
}) {
  return (
    <label className="block">
      <span className="mb-1.5 flex items-baseline justify-between gap-3">
        <span className="text-[12.5px] font-medium tracking-wide text-mist-200">
          {label}
          {required && <span className="ml-1 text-ember-400">*</span>}
        </span>
        {hint && <span className="font-mono text-[10.5px] text-mist-500">{hint}</span>}
      </span>
      {children}
      {error && (
        <span className="mt-1.5 block text-[12px] font-medium text-ember-400" role="alert">
          {error}
        </span>
      )}
    </label>
  );
}

export function OrderDrawer() {
  const {
    isOpen,
    step,
    draft,
    contact,
    segments,
    rateTenths,
    totalCents,
    submitting,
    error,
    result,
    close,
    setStep,
    updateDraft,
    updateContact,
    submit,
    reset,
  } = useOrder();

  const [fieldErrors, setFieldErrors] = useState<Record<string, string>>({});
  const [copied, setCopied] = useState(false);
  const panelRef = useRef<HTMLDivElement>(null);
  const firstFieldRef = useRef<HTMLInputElement>(null);

  const analysis = useMemo(() => analyseMessage(draft.message), [draft.message]);
  const ladderIndex = nearestLadderIndex(draft.credits);
  const payAsYouGo = Math.round((draft.credits * segments * 24) / 10);
  const saved = Math.max(0, payAsYouGo - totalCents);
  const throughput = THROUGHPUT[draft.planId] ?? 300;

  useEffect(() => {
    if (isOpen && step !== 3) {
      const t = setTimeout(() => firstFieldRef.current?.focus({ preventScroll: true }), 260);
      return () => clearTimeout(t);
    }
  }, [isOpen, step]);

  useEffect(() => {
    if (isOpen) setFieldErrors({});
  }, [isOpen, step]);

  const validateStep = (target: number) => {
    const errors: Record<string, string> = {};

    if (target > 0) {
      if (draft.senderId && !/^[A-Za-z0-9 ]{2,11}$/.test(draft.senderId)) {
        errors.senderId = "2–11 letters, numbers or spaces.";
      }
    }
    if (target > 1) {
      if (draft.message.trim().length < 8) errors.message = "Write at least a sentence of copy.";
      if (!draft.recipients || draft.recipients < 1) errors.recipients = "How many people receive it?";
      else if (draft.recipients > draft.credits)
        errors.recipients = `That is more than your ${formatNumber(draft.credits)} credits.`;
      if (draft.schedule === "scheduled" && !draft.scheduledAt)
        errors.scheduledAt = "Pick a send time.";
    }
    if (target > 2) {
      if (contact.customerName.trim().length < 2) errors.customerName = "Required.";
      if (!/^[^\s@]+@[^\s@]+\.[a-z]{2,}$/i.test(contact.customerEmail)) errors.customerEmail = "Required.";
      if (contact.customerPhone.replace(/\D/g, "").length < 7) errors.customerPhone = "Required.";
      if (!contact.accepted) errors.accepted = "Please accept the acceptable-use policy.";
    }

    setFieldErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const goNext = () => {
    if (!validateStep(step + 1)) return;
    setStep(Math.min(3, step + 1));
  };

  const handleSubmit = async () => {
    if (!validateStep(3)) return;
    await submit();
  };

  const copyOrderNumber = async () => {
    if (!result) return;
    try {
      await navigator.clipboard.writeText(result.orderNumber);
      setCopied(true);
      setTimeout(() => setCopied(false), 1800);
    } catch {
      setCopied(false);
    }
  };

  return (
    <div
      className={`fixed inset-0 z-[120] ${isOpen ? "" : "pointer-events-none invisible"}`}
      aria-hidden={!isOpen}
    >
      {/* backdrop */}
      <button
        type="button"
        tabIndex={isOpen ? 0 : -1}
        aria-label="Close order panel"
        onClick={close}
        className={`absolute inset-0 cursor-default bg-ink-950/72 backdrop-blur-[6px] transition-opacity duration-500 ${
          isOpen ? "opacity-100" : "opacity-0"
        }`}
      />

      <aside
        ref={panelRef}
        role="dialog"
        aria-modal="true"
        aria-labelledby="order-drawer-title"
        className={`absolute inset-y-0 right-0 flex w-full max-w-[32rem] flex-col border-l border-white/10 bg-ink-900/95 shadow-[-40px_0_120px_-40px_rgba(0,0,0,0.9)] backdrop-blur-2xl transition-transform duration-[600ms] [transition-timing-function:var(--ease-out-expo)] ${
          isOpen ? "translate-x-0" : "translate-x-full"
        }`}
      >
        {/* header */}
        <header className="relative shrink-0 border-b border-white/8 px-5 pb-4 pt-5 sm:px-7">
          <div className="flex items-start justify-between gap-4">
            <div className="flex items-center gap-3">
              <LogoMark className="size-9" />
              <div>
                <h2 id="order-drawer-title" className="text-[17px] leading-tight text-mist-50">
                  {step === 3 ? "Order confirmed" : "Place your bulk SMS order"}
                </h2>
                <p className="font-mono text-[10.5px] tracking-[0.18em] text-mist-500 uppercase">
                  Secure checkout · Kfyklab
                </p>
              </div>
            </div>
            <button
              type="button"
              onClick={close}
              tabIndex={isOpen ? 0 : -1}
              className="grid size-9 place-items-center rounded-xl border border-white/10 text-mist-300 transition hover:border-white/25 hover:bg-white/5 hover:text-mist-50"
              aria-label="Close"
            >
              <IconClose className="size-4.5" />
            </button>
          </div>

          {step < 3 && (
            <ol className="mt-5 flex items-center gap-2">
              {STEP_LABELS.map((label, index) => {
                const done = index < step;
                const active = index === step;
                return (
                  <li key={label} className="flex flex-1 items-center gap-2">
                    <button
                      type="button"
                      tabIndex={isOpen ? 0 : -1}
                      onClick={() => index < step && setStep(index)}
                      disabled={index > step}
                      className={`flex items-center gap-2 rounded-full px-2 py-1 text-[11.5px] font-medium transition ${
                        index < step ? "cursor-pointer text-signal-300 hover:bg-signal-400/8" : ""
                      } ${active ? "text-mist-50" : index > step ? "text-mist-600" : ""}`}
                    >
                      <span
                        className={`grid size-5 place-items-center rounded-full border font-mono text-[10px] transition ${
                          done
                            ? "border-signal-400/60 bg-signal-400/15 text-signal-300"
                            : active
                              ? "border-mist-50/40 bg-mist-50/10 text-mist-50"
                              : "border-white/12 text-mist-600"
                        }`}
                      >
                        {done ? <IconCheck className="size-3" /> : index + 1}
                      </span>
                      <span className="hidden sm:inline">{label}</span>
                    </button>
                    {index < STEP_LABELS.length - 1 && (
                      <span
                        className={`h-px flex-1 transition-colors duration-500 ${
                          done ? "bg-signal-400/50" : "bg-white/10"
                        }`}
                      />
                    )}
                  </li>
                );
              })}
            </ol>
          )}
        </header>

        {/* body */}
        <div className="relative flex-1 overflow-y-auto overscroll-contain px-5 py-6 sm:px-7">
          {step === 3 && result ? (
            <div className="animate-rise">
              <div className="relative mx-auto mb-6 grid size-16 place-items-center">
                <span className="absolute inset-0 animate-ring rounded-full border border-signal-400/50" />
                <span className="absolute inset-0 animate-ring rounded-full border border-signal-400/40 [animation-delay:0.9s]" />
                <span className="grid size-14 place-items-center rounded-full bg-signal-400/15 text-signal-300 ring-1 ring-signal-400/40">
                  <IconCheck className="size-7" strokeWidth={2} />
                </span>
              </div>

              <h3 className="text-center font-display text-2xl text-mist-50">
                Your credits are reserved.
              </h3>
              <p className="mx-auto mt-2 max-w-sm text-center text-[14px] leading-relaxed text-mist-400">
                A launch specialist is reviewing your Sender ID now. You will get an email at{" "}
                <span className="text-mist-100">{contact.customerEmail || "your inbox"}</span> with
                onboarding steps within one business hour.
              </p>

              <div className="mt-6 rounded-2xl border border-white/10 bg-ink-850/70 p-5">
                <Row label="Order number" value={result.orderNumber} accent />
                <Row label="Package" value={result.planName} />
                <Row label="Credits" value={formatNumber(result.credits)} />
                <Row
                  label="Paid"
                  value={`${formatMoney(result.totalCents)} ${result.status === "pending" ? "(pending)" : ""}`}
                />
                <Row label="Status" value={result.status.toUpperCase()} />
                <div className="mt-4 flex gap-2">
                  <button
                    type="button"
                    onClick={copyOrderNumber}
                    className="flex-1 rounded-xl border border-white/12 bg-white/5 px-3 py-2.5 text-[13px] font-medium text-mist-100 transition hover:border-signal-400/45 hover:bg-signal-400/10 hover:text-signal-200"
                  >
                    {copied ? "Copied ✓" : "Copy order number"}
                  </button>
                  <a
                    href="/orders"
                    className="flex-1 rounded-xl border border-white/12 bg-white/5 px-3 py-2.5 text-center text-[13px] font-medium text-mist-100 transition hover:border-white/25 hover:bg-white/10"
                  >
                    Open dashboard
                  </a>
                </div>
              </div>

              <button
                type="button"
                onClick={() => {
                  reset();
                  close();
                }}
                className="mt-5 w-full rounded-xl bg-mist-50 px-4 py-3 text-[14px] font-semibold text-ink-950 transition hover:bg-white"
              >
                Done
              </button>
            </div>
          ) : step === 0 ? (
            <div className="space-y-6 animate-rise">
              <div>
                <p className="mb-3 text-[12.5px] font-medium tracking-wide text-mist-300">
                  Choose a package
                </p>
                <div className="grid grid-cols-2 gap-2.5">
                  {PLANS.map((plan) => {
                    const active = draft.planId === plan.id;
                    return (
                      <button
                        key={plan.id}
                        type="button"
                        tabIndex={isOpen ? 0 : -1}
                        onClick={() => updateDraft({ planId: plan.id })}
                        className={`group relative overflow-hidden rounded-2xl border p-3.5 text-left transition duration-300 ${
                          active
                            ? "border-signal-400/60 bg-signal-400/10 shadow-[0_0_0_1px_rgba(56,232,172,0.25)]"
                            : "border-white/10 bg-ink-850/60 hover:border-white/22 hover:bg-ink-800"
                        }`}
                        aria-pressed={active}
                      >
                        <span className="flex items-center justify-between">
                          <span className="font-display text-[15px] text-mist-50">{plan.name}</span>
                          <span
                            className={`grid size-4 place-items-center rounded-full border transition ${
                              active ? "border-signal-400 bg-signal-400" : "border-white/25"
                            }`}
                          >
                            {active && <IconCheck className="size-2.5 text-ink-950" strokeWidth={3.4} />}
                          </span>
                        </span>
                        <span className="mt-1 block font-mono text-[11px] text-mist-400">
                          {formatNumber(plan.credits)} SMS
                        </span>
                        <span className="mt-2 block text-[15px] font-semibold text-signal-300">
                          {formatMoney(plan.totalCents)}
                        </span>
                      </button>
                    );
                  })}
                </div>
              </div>

              <div className="rounded-2xl border border-white/10 bg-ink-850/60 p-4">
                <div className="flex items-baseline justify-between">
                  <span className="text-[12.5px] font-medium text-mist-300">Fine-tune volume</span>
                  <span className="font-mono text-[13px] text-signal-300 tabular-nums">
                    {formatNumber(draft.credits)} SMS
                  </span>
                </div>
                <input
                  type="range"
                  min={0}
                  max={SEGMENT_LADDER.length - 1}
                  step={1}
                  value={ladderIndex}
                  tabIndex={isOpen ? 0 : -1}
                  onChange={(event) => {
                    const credits = SEGMENT_LADDER[Number(event.target.value)];
                    updateDraft({ credits, recipients: credits });
                  }}
                  aria-label="Message credits"
                  className="mt-3 h-1.5 w-full cursor-pointer appearance-none rounded-full bg-white/12 accent-signal-400
                    [&::-webkit-slider-thumb]:size-4 [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:rounded-full
                    [&::-webkit-slider-thumb]:bg-signal-400 [&::-webkit-slider-thumb]:shadow-[0_0_0_5px_rgba(56,232,172,0.18)]
                    [&::-webkit-slider-thumb]:transition [&::-webkit-slider-thumb]:hover:bg-signal-300
                    [&::-moz-range-thumb]:size-4 [&::-moz-range-thumb]:rounded-full [&::-moz-range-thumb]:border-0 [&::-moz-range-thumb]:bg-signal-400"
                />
                <div className="mt-2 flex justify-between font-mono text-[10px] text-mist-600">
                  <span>1K</span>
                  <span>50K</span>
                  <span>250K</span>
                  <span>2M</span>
                </div>
                <div className="mt-3 grid grid-cols-3 gap-2 border-t border-white/8 pt-3">
                  <div>
                    <p className="font-mono text-[10px] tracking-wider text-mist-500 uppercase">Rate</p>
                    <p className="mt-0.5 text-[13px] text-mist-100">{rateLabel(rateTenths)}/SMS</p>
                  </div>
                  <div>
                    <p className="font-mono text-[10px] tracking-wider text-mist-500 uppercase">Throughput</p>
                    <p className="mt-0.5 text-[13px] text-mist-100">
                      {formatNumber(throughput)}/s
                    </p>
                  </div>
                  <div>
                    <p className="font-mono text-[10px] tracking-wider text-mist-500 uppercase">Send time</p>
                    <p className="mt-0.5 text-[13px] text-mist-100">
                      {etaMinutes(draft.credits, throughput)}
                    </p>
                  </div>
                </div>
              </div>

              <Field
                label="Sender ID"
                hint="free registration · 11 chars"
                error={fieldErrors.senderId}
              >
                <input
                  ref={firstFieldRef}
                  className="field font-mono tracking-[0.14em] uppercase"
                  placeholder="KFYKLAB"
                  maxLength={11}
                  value={draft.senderId}
                  tabIndex={isOpen ? 0 : -1}
                  onChange={(event) => updateDraft({ senderId: event.target.value.toUpperCase() })}
                />
              </Field>

              {saved > 0 && (
                <p className="flex items-start gap-2 rounded-xl border border-signal-400/20 bg-signal-400/6 p-3 text-[12.5px] text-signal-200">
                  <IconBolt className="mt-0.5 size-4 shrink-0" />
                  You save {formatMoney(saved)} versus pay-as-you-go at 2.4c per message.
                </p>
              )}
            </div>
          ) : step === 1 ? (
            <div className="space-y-5 animate-rise">
              <Field label="Campaign name" hint="internal only">
                <input
                  ref={firstFieldRef}
                  className="field"
                  placeholder="March restock alert"
                  value={draft.campaignName}
                  tabIndex={isOpen ? 0 : -1}
                  onChange={(event) => updateDraft({ campaignName: event.target.value })}
                />
              </Field>

              <Field
                label="Message copy"
                hint={`${analysis.chars} chars · ${analysis.segments} segment${analysis.segments > 1 ? "s" : ""} · ${analysis.encoding}`}
                error={fieldErrors.message}
                required
              >
                <textarea
                  className="field min-h-32 resize-y leading-relaxed"
                  placeholder="Hi {{first_name}}, your order #1234 is on the way…"
                  value={draft.message}
                  tabIndex={isOpen ? 0 : -1}
                  onChange={(event) => updateDraft({ message: event.target.value.slice(0, 900) })}
                />
              </Field>

              <div className="grid gap-2 sm:grid-cols-2">
                <Field label="Recipients" error={fieldErrors.recipients} required>
                  <input
                    type="number"
                    min={1}
                    className="field font-mono tabular-nums"
                    value={draft.recipients || ""}
                    tabIndex={isOpen ? 0 : -1}
                    onChange={(event) => updateDraft({ recipients: Number(event.target.value) })}
                  />
                </Field>
                <div className="flex items-end">
                  <button
                    type="button"
                    tabIndex={isOpen ? 0 : -1}
                    onClick={() => updateDraft({ recipients: draft.credits })}
                    className="w-full rounded-xl border border-white/12 bg-white/4 px-3 py-2.5 text-[13px] text-mist-200 transition hover:border-signal-400/40 hover:bg-signal-400/8 hover:text-signal-200"
                  >
                    Use all {formatNumber(draft.credits)} credits
                  </button>
                </div>
              </div>

              <div>
                <p className="mb-2 text-[12.5px] font-medium text-mist-300">When should it go out?</p>
                <div className="grid grid-cols-2 gap-2.5">
                  {(
                    [
                      { id: "instant", label: "Send immediately", icon: IconBolt },
                      { id: "scheduled", label: "Schedule it", icon: IconCalendar },
                    ] as const
                  ).map((option) => {
                    const active = draft.schedule === option.id;
                    const Icon = option.icon;
                    return (
                      <button
                        key={option.id}
                        type="button"
                        tabIndex={isOpen ? 0 : -1}
                        onClick={() => updateDraft({ schedule: option.id })}
                        aria-pressed={active}
                        className={`flex items-center gap-2.5 rounded-xl border px-3.5 py-3 text-[13px] transition ${
                          active
                            ? "border-signal-400/55 bg-signal-400/10 text-signal-200"
                            : "border-white/10 bg-ink-850/60 text-mist-300 hover:border-white/22"
                        }`}
                      >
                        <Icon className="size-4" />
                        {option.label}
                      </button>
                    );
                  })}
                </div>
                {draft.schedule === "scheduled" && (
                  <div className="mt-3">
                    <Field label="Send time" error={fieldErrors.scheduledAt} required>
                      <input
                        type="datetime-local"
                        className="field"
                        tabIndex={isOpen ? 0 : -1}
                        onChange={(event) => {
                          const raw = event.target.value;
                          if (!raw) return updateDraft({ scheduledAt: "" });
                          const date = new Date(raw);
                          updateDraft({
                            scheduledAt: Number.isNaN(date.getTime())
                              ? raw
                              : date.toLocaleString("en-GB", {
                                  weekday: "short",
                                  day: "2-digit",
                                  month: "short",
                                  hour: "2-digit",
                                  minute: "2-digit",
                                }),
                          });
                        }}
                      />
                    </Field>
                  </div>
                )}
              </div>

              <div className="rounded-2xl border border-white/10 bg-gradient-to-br from-ink-800 to-ink-900 p-4">
                <p className="font-mono text-[10px] tracking-[0.2em] text-mist-500 uppercase">
                  Handset preview
                </p>
                <div className="mt-3 max-w-[85%] rounded-2xl rounded-tl-sm bg-signal-400/12 px-3.5 py-2.5 text-[13px] leading-relaxed text-mist-100 ring-1 ring-signal-400/20">
                  {draft.senderId && (
                    <span className="mb-0.5 block font-mono text-[10.5px] tracking-[0.16em] text-signal-300 uppercase">
                      {draft.senderId}
                    </span>
                  )}
                  {draft.message || "Your message appears here…"}
                </div>
              </div>
            </div>
          ) : (
            <div className="space-y-5 animate-rise">
              <div className="grid gap-4 sm:grid-cols-2">
                <Field label="Full name" error={fieldErrors.customerName} required>
                  <input
                    ref={firstFieldRef}
                    className="field"
                    autoComplete="name"
                    placeholder="Amina Yusuf"
                    value={contact.customerName}
                    tabIndex={isOpen ? 0 : -1}
                    onChange={(event) => updateContact({ customerName: event.target.value })}
                  />
                </Field>
                <Field label="Work email" error={fieldErrors.customerEmail} required>
                  <input
                    className="field"
                    type="email"
                    autoComplete="email"
                    placeholder="amina@company.com"
                    value={contact.customerEmail}
                    tabIndex={isOpen ? 0 : -1}
                    onChange={(event) => updateContact({ customerEmail: event.target.value })}
                  />
                </Field>
                <Field label="Phone" error={fieldErrors.customerPhone} required>
                  <input
                    className="field font-mono"
                    autoComplete="tel"
                    placeholder="+254 712 000 000"
                    value={contact.customerPhone}
                    tabIndex={isOpen ? 0 : -1}
                    onChange={(event) => updateContact({ customerPhone: event.target.value })}
                  />
                </Field>
                <Field label="Company">
                  <input
                    className="field"
                    autoComplete="organization"
                    placeholder="Acme Retail"
                    value={contact.company}
                    tabIndex={isOpen ? 0 : -1}
                    onChange={(event) => updateContact({ company: event.target.value })}
                  />
                </Field>
              </div>

              <Field label="Country">
                <select
                  className="field appearance-none"
                  value={contact.country}
                  tabIndex={isOpen ? 0 : -1}
                  onChange={(event) => updateContact({ country: event.target.value })}
                >
                  {COUNTRIES.map((country) => (
                    <option key={country} value={country}>
                      {country}
                    </option>
                  ))}
                </select>
              </Field>

              <div>
                <p className="mb-2 text-[12.5px] font-medium text-mist-300">Payment method</p>
                <div className="grid gap-2 sm:grid-cols-2">
                  {PAYMENT_METHODS.map((method) => {
                    const active = contact.paymentMethod === method.id;
                    const Icon = PAYMENT_ICONS[method.id] ?? IconCard;
                    return (
                      <button
                        key={method.id}
                        type="button"
                        tabIndex={isOpen ? 0 : -1}
                        onClick={() => updateContact({ paymentMethod: method.id })}
                        aria-pressed={active}
                        className={`flex items-start gap-3 rounded-xl border p-3 text-left transition ${
                          active
                            ? "border-signal-400/55 bg-signal-400/10"
                            : "border-white/10 bg-ink-850/60 hover:border-white/22"
                        }`}
                      >
                        <Icon className={`mt-0.5 size-4.5 ${active ? "text-signal-300" : "text-mist-400"}`} />
                        <span>
                          <span className="block text-[13px] font-medium text-mist-100">{method.label}</span>
                          <span className="mt-0.5 block font-mono text-[10.5px] text-mist-500">
                            {method.hint}
                          </span>
                        </span>
                      </button>
                    );
                  })}
                </div>
              </div>

              <Field label="Anything we should know?">
                <textarea
                  className="field min-h-20 resize-y"
                  placeholder="Route preference, compliance contacts, invoice PO number…"
                  value={contact.notes}
                  tabIndex={isOpen ? 0 : -1}
                  onChange={(event) => updateContact({ notes: event.target.value.slice(0, 600) })}
                />
              </Field>

              <div className="rounded-2xl border border-white/10 bg-ink-850/60 p-4">
                <p className="mb-1 font-mono text-[10px] tracking-[0.2em] text-mist-500 uppercase">
                  Order summary
                </p>
                <Row label={`${draft.planName} · ${formatNumber(draft.credits)} credits`} value={formatMoney(totalCents)} />
                <Row
                  label={`Segments per message (${analysis.encoding})`}
                  value={`${segments}×`}
                />
                <Row label="Rate per message" value={rateLabel(rateTenths)} />
                <Row label="Sender ID registration" value="Free" />
                <div className="mt-1 flex items-baseline justify-between border-t border-white/10 pt-3">
                  <span className="text-[13px] font-semibold text-mist-50">Total due</span>
                  <span className="font-mono text-lg font-semibold text-signal-300 tabular-nums">
                    {formatMoney(totalCents)}
                  </span>
                </div>
              </div>

              <label className="flex cursor-pointer items-start gap-3 text-[12.5px] leading-relaxed text-mist-400">
                <input
                  type="checkbox"
                  className="mt-0.5 size-4 shrink-0 accent-signal-400"
                  checked={contact.accepted}
                  tabIndex={isOpen ? 0 : -1}
                  onChange={(event) => updateContact({ accepted: event.target.checked })}
                />
                <span>
                  I confirm my list is permission-based and I accept the Kfyklab acceptable-use and
                  anti-spam policy.
                  {fieldErrors.accepted && (
                    <span className="mt-1 block font-medium text-ember-400">{fieldErrors.accepted}</span>
                  )}
                </span>
              </label>
            </div>
          )}
        </div>

        {/* footer */}
        {step < 3 && (
          <footer className="shrink-0 border-t border-white/8 bg-ink-900/90 px-5 py-4 sm:px-7">
            {error && (
              <p
                role="alert"
                className="mb-3 rounded-xl border border-ember-400/30 bg-ember-400/10 px-3.5 py-2.5 text-[12.5px] text-ember-300"
              >
                {error}
              </p>
            )}
            <div className="flex items-center justify-between gap-4">
              <div>
                <p className="font-mono text-[10px] tracking-[0.2em] text-mist-500 uppercase">Total</p>
                <p className="font-display text-2xl leading-none text-mist-50 tabular-nums">
                  {formatMoney(totalCents)}
                </p>
              </div>
              <div className="flex items-center gap-2">
                {step > 0 && (
                  <button
                    type="button"
                    tabIndex={isOpen ? 0 : -1}
                    onClick={() => setStep(step - 1)}
                    className="rounded-xl border border-white/12 px-4 py-3 text-[13px] font-medium text-mist-200 transition hover:border-white/25 hover:bg-white/6"
                  >
                    Back
                  </button>
                )}
                <button
                  type="button"
                  tabIndex={isOpen ? 0 : -1}
                  onClick={step === 2 ? handleSubmit : goNext}
                  disabled={submitting}
                  className="shine group relative flex items-center gap-2 rounded-xl bg-signal-400 px-5 py-3 text-[13.5px] font-semibold text-ink-950 transition hover:bg-signal-300 disabled:cursor-wait disabled:opacity-70"
                >
                  <span className="shine-bar" />
                  {submitting ? (
                    <>
                      <span className="size-4 animate-spin rounded-full border-2 border-ink-950/30 border-t-ink-950" />
                      Placing order…
                    </>
                  ) : step === 2 ? (
                    <>
                      <IconLock className="size-4" />
                      Confirm &amp; pay
                    </>
                  ) : (
                    <>
                      Continue
                      <IconArrow className="size-4 transition-transform group-hover:translate-x-0.5" />
                    </>
                  )}
                </button>
              </div>
            </div>
            <p className="mt-3 flex items-center gap-1.5 font-mono text-[10.5px] text-mist-600">
              <IconLock className="size-3" />
              TLS 1.3 encrypted · No card data touches our servers · PCI-DSS via Kfyk Pay
            </p>
          </footer>
        )}
      </aside>
    </div>
  );
}

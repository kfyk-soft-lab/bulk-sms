import { bigint, integer, pgTable, serial, text, timestamp } from "drizzle-orm/pg-core";

/**
 * A customer order captured from the landing page checkout flow.
 */
export const orders = pgTable("orders", {
  id: serial("id").primaryKey(),
  orderNumber: text("order_number").notNull().unique(),

  planId: text("plan_id").notNull(),
  planName: text("plan_name").notNull(),
  credits: integer("credits").notNull(),
  pricePerSmsCents: integer("price_per_sms_cents").notNull(),
  totalCents: integer("total_cents").notNull(),
  currency: text("currency").notNull().default("USD"),

  senderId: text("sender_id"),
  campaignName: text("campaign_name"),
  message: text("message"),
  recipients: integer("recipients"),
  segmentsPerSms: integer("segments_per_sms"),
  schedule: text("schedule").notNull().default("instant"),
  scheduledAt: text("scheduled_at"),

  customerName: text("customer_name").notNull(),
  customerEmail: text("customer_email").notNull(),
  customerPhone: text("customer_phone").notNull(),
  company: text("company"),
  country: text("country"),
  paymentMethod: text("payment_method").notNull().default("card"),
  notes: text("notes"),

  status: text("status").notNull().default("pending"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

/**
 * Single-row table powering the live "network" counters on the landing page.
 */
export const platformStats = pgTable("platform_stats", {
  id: serial("id").primaryKey(),
  messagesDelivered: bigint("messages_delivered", { mode: "number" }).notNull().default(0),
  ordersPlaced: integer("orders_placed").notNull().default(0),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export type Order = typeof orders.$inferSelect;
export type NewOrder = typeof orders.$inferInsert;

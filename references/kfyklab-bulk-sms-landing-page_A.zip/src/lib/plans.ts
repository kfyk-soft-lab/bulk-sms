/**
 * Single source of truth for the credit packages sold on the landing page.
 * Prices are always handled in cents (integer maths) to avoid float drift.
 */

export type Plan = {
  id: string;
  name: string;
  tagline: string;
  credits: number;
  /** price per SMS in cents, e.g. 1.8 => 1.8c. Stored as tenths of a cent. */
  pricePerSmsTenths: number;
  totalCents: number;
  badge?: string;
  highlight?: boolean;
  throughput: string;
  features: string[];
  support: string;
};

export const CURRENCY = "USD";

/** Volume tiers: bigger baskets unlock a cheaper per-message rate. */
export const TIERS: { min: number; pricePerSmsTenths: number }[] = [
  { min: 1_000_000, pricePerSmsTenths: 9 }, // 0.9c
  { min: 250_000, pricePerSmsTenths: 12 }, // 1.2c
  { min: 50_000, pricePerSmsTenths: 15 }, // 1.5c
  { min: 10_000, pricePerSmsTenths: 18 }, // 1.8c
  { min: 0, pricePerSmsTenths: 24 }, // 2.4c
];

export function pricePerSmsTenthsFor(credits: number): number {
  const tier = TIERS.find((t) => credits >= t.min) ?? TIERS[TIERS.length - 1];
  return tier.pricePerSmsTenths;
}

export function totalCentsFor(credits: number, segments = 1): number {
  const rate = pricePerSmsTenthsFor(credits);
  return Math.round((credits * segments * rate) / 10);
}

export const PLANS: Plan[] = [
  {
    id: "spark",
    name: "Spark",
    tagline: "For boutiques, clinics and local launches finding their voice.",
    credits: 10_000,
    pricePerSmsTenths: 18,
    totalCents: 18_000,
    throughput: "60 SMS / second",
    support: "Chat support · 12h response",
    features: [
      "10,000 message credits",
      "1 free verified Sender ID",
      "Web dashboard + CSV import",
      "Real-time delivery reports",
      "Opt-out keyword handling",
    ],
  },
  {
    id: "surge",
    name: "Surge",
    tagline: "The workhorse for growing shops running weekly campaigns.",
    credits: 50_000,
    pricePerSmsTenths: 15,
    totalCents: 75_000,
    badge: "Most ordered",
    highlight: true,
    throughput: "300 SMS / second",
    support: "Priority support · 2h response",
    features: [
      "50,000 message credits",
      "3 free verified Sender IDs",
      "REST API + webhooks",
      "Audience segmentation & merge tags",
      "A/B split testing on copy",
      "Scheduled & drip campaigns",
    ],
  },
  {
    id: "orbit",
    name: "Orbit",
    tagline: "Multi-brand retailers and fintechs sending at national scale.",
    credits: 250_000,
    pricePerSmsTenths: 12,
    totalCents: 300_000,
    throughput: "1,200 SMS / second",
    support: "Dedicated manager · 30m SLA",
    features: [
      "250,000 message credits",
      "Unlimited Sender IDs",
      "Direct carrier routes (no grey hops)",
      "Team seats, roles & audit log",
      "Unicode + long SMS at best rate",
      "99.95% uptime SLA",
    ],
  },
  {
    id: "atlas",
    name: "Atlas",
    tagline: "Enterprise volumes with compliance, DPA and private routing.",
    credits: 1_000_000,
    pricePerSmsTenths: 9,
    totalCents: 900_000,
    throughput: "5,000+ SMS / second",
    support: "24/7 war-room · named engineers",
    features: [
      "1,000,000+ message credits",
      "Private dedicated connections",
      "DLR reconciliation & retries",
      "SOC 2 · GDPR · local DPA",
      "Custom invoicing & net-30 terms",
      "Onboarding & route warm-up",
    ],
  },
];

export function findPlan(id: string): Plan | undefined {
  return PLANS.find((p) => p.id === id);
}

export const PAYMENT_METHODS = [
  { id: "card", label: "Card / 3-D Secure", hint: "Visa, Mastercard, Amex" },
  { id: "bank", label: "Bank transfer", hint: "SWIFT · SEPA · local rails" },
  { id: "wallet", label: "Mobile wallet", hint: "M-Pesa, MTN MoMo, Airtel" },
  { id: "invoice", label: "Corporate invoice", hint: "Net-15 terms, PO supported" },
] as const;

export const COUNTRIES = [
  "Kenya",
  "Nigeria",
  "Ghana",
  "South Africa",
  "Uganda",
  "Tanzania",
  "Rwanda",
  "United Arab Emirates",
  "United Kingdom",
  "United States",
  "India",
  "Philippines",
  "Indonesia",
  "Brazil",
  "Germany",
  "Other",
];

export const formatMoney = (cents: number, currency = CURRENCY) =>
  new Intl.NumberFormat("en-US", {
    style: "currency",
    currency,
    maximumFractionDigits: cents % 100 === 0 ? 0 : 2,
  }).format(cents / 100);

export const formatNumber = (n: number) => new Intl.NumberFormat("en-US").format(n);

export const rateLabel = (tenths: number) => `$${(tenths / 1000).toFixed(4)}`;

/** GSM-7 / UCS-2 helpers used by the campaign studio and the order drawer. */

const GSM_7 = new Set(
  "@£$¥èéùìòÇ\nØø\rÅåΔ_ΦΓΛΩΠΨΣΘΞÆæßÉ !\"#¤%&'()*+,-./0123456789:;<=>?¡ABCDEFGHIJKLMNOPQRSTUVWXYZÄÖÑÜ§¿abcdefghijklmnopqrstuvwxyzäöñüà".split(
    "",
  ),
);

export type MessageAnalysis = {
  chars: number;
  encoding: "GSM-7" | "UCS-2";
  segments: number;
  perRecipient: number;
};

export function analyseMessage(text: string): MessageAnalysis {
  const chars = [...text].length;
  const unicode = [...text].some((c) => !GSM_7.has(c));
  const encoding: MessageAnalysis["encoding"] = unicode ? "UCS-2" : "GSM-7";

  if (chars === 0) return { chars, encoding, segments: 1, perRecipient: 1 };

  const single = unicode ? 70 : 160;
  const multi = unicode ? 67 : 153;
  const segments = chars <= single ? 1 : Math.ceil(chars / multi);

  return { chars, encoding, segments, perRecipient: segments };
}

export const SEGMENT_LADDER = [
  1_000, 2_500, 5_000, 10_000, 25_000, 50_000, 100_000, 250_000, 500_000, 1_000_000, 2_000_000,
];

export function nearestLadderIndex(credits: number) {
  let best = 0;
  let diff = Infinity;
  SEGMENT_LADDER.forEach((value, index) => {
    const d = Math.abs(value - credits);
    if (d < diff) {
      diff = d;
      best = index;
    }
  });
  return best;
}

export function compactNumber(n: number) {
  return new Intl.NumberFormat("en-US", { notation: "compact", maximumFractionDigits: 1 }).format(n);
}

/** Rough send-time estimate given the plan throughput (messages / second). */
export function etaMinutes(credits: number, perSecond: number) {
  const seconds = credits / Math.max(1, perSecond);
  if (seconds < 60) return `${Math.max(1, Math.round(seconds))} sec`;
  return `${Math.round(seconds / 60)} min`;
}

import { db } from "@/db";
import { orders, platformStats } from "@/db/schema";
import { eq, sql } from "drizzle-orm";

const BASE_DELIVERED = 1_284_530_112;

export type Stats = {
  messagesDelivered: number;
  ordersPlaced: number;
  updatedAt: string;
};

/** Guarantees the single stats row exists and returns it. */
export async function ensureStats(): Promise<Stats> {
  const existing = await db.select().from(platformStats).where(eq(platformStats.id, 1)).limit(1);
  if (existing[0]) {
    return {
      messagesDelivered: existing[0].messagesDelivered,
      ordersPlaced: existing[0].ordersPlaced,
      updatedAt: existing[0].updatedAt.toISOString(),
    };
  }

  await db
    .insert(platformStats)
    .values({ id: 1, messagesDelivered: BASE_DELIVERED, ordersPlaced: 0 })
    .onConflictDoNothing({ target: platformStats.id });

  await seedDemoOrders();

  const row = await db.select().from(platformStats).where(eq(platformStats.id, 1)).limit(1);
  return {
    messagesDelivered: row[0]?.messagesDelivered ?? BASE_DELIVERED,
    ordersPlaced: row[0]?.ordersPlaced ?? 0,
    updatedAt: new Date().toISOString(),
  };
}

export async function bumpStats(credits: number) {
  await ensureStats();
  await db
    .update(platformStats)
    .set({
      messagesDelivered: sql`${platformStats.messagesDelivered} + ${credits}`,
      ordersPlaced: sql`${platformStats.ordersPlaced} + 1`,
      updatedAt: new Date(),
    })
    .where(eq(platformStats.id, 1));
}

export function makeOrderNumber() {
  const stamp = Date.now().toString(36).toUpperCase().slice(-6);
  const salt = Math.random().toString(36).toUpperCase().slice(2, 5);
  return `KFY-${stamp}-${salt}`;
}

/** A few realistic rows so the operations dashboard has something to show. */
async function seedDemoOrders() {
  const count = await db.select({ n: sql<number>`count(*)::int` }).from(orders);
  if ((count[0]?.n ?? 0) > 0) return;

  const days = (n: number) => new Date(Date.now() - n * 86_400_000);
  await db.insert(orders).values([
    {
      orderNumber: "KFY-DEMO-001",
      planId: "surge",
      planName: "Surge",
      credits: 50_000,
      pricePerSmsCents: 2,
      totalCents: 75_000,
      senderId: "ZANARA",
      campaignName: "Ramadan flash sale",
      message: "Zanara: 40% off sitewide until midnight. Shop zanara.co/ramadan. Reply STOP to opt out.",
      recipients: 48_200,
      segmentsPerSms: 1,
      schedule: "instant",
      customerName: "Amara Nwosu",
      customerEmail: "amara@zanara.co",
      customerPhone: "+234 802 114 9930",
      company: "Zanara Retail",
      country: "Nigeria",
      paymentMethod: "card",
      status: "delivered",
      createdAt: days(4),
      updatedAt: days(4),
    },
    {
      orderNumber: "KFY-DEMO-002",
      planId: "orbit",
      planName: "Orbit",
      credits: 250_000,
      pricePerSmsCents: 1,
      totalCents: 300_000,
      senderId: "SAFARICOM",
      campaignName: "OTP failover traffic",
      message: "Your Kfyklab verification code is 481-220. Valid for 5 minutes.",
      recipients: 250_000,
      segmentsPerSms: 1,
      schedule: "instant",
      customerName: "Daniel Kiptoo",
      customerEmail: "d.kiptoo@paylent.ke",
      customerPhone: "+254 712 884 017",
      company: "Paylent Financial",
      country: "Kenya",
      paymentMethod: "bank",
      status: "processing",
      createdAt: days(2),
      updatedAt: days(1),
    },
    {
      orderNumber: "KFY-DEMO-003",
      planId: "spark",
      planName: "Spark",
      credits: 10_000,
      pricePerSmsCents: 2,
      totalCents: 18_000,
      senderId: "BLOOMCLINIC",
      campaignName: "Appointment reminders",
      message: "Bloom Clinic reminder: your dental check-up is tomorrow 10:30. Reply C to confirm.",
      recipients: 9_480,
      segmentsPerSms: 1,
      schedule: "scheduled",
      scheduledAt: "Tomorrow, 08:00 EAT",
      customerName: "Dr. Leila Haddad",
      customerEmail: "leila@bloomclinic.ae",
      customerPhone: "+971 50 774 2210",
      company: "Bloom Clinic",
      country: "United Arab Emirates",
      paymentMethod: "wallet",
      status: "paid",
      createdAt: days(1),
      updatedAt: days(1),
    },
  ]);

  await db
    .update(platformStats)
    .set({ ordersPlaced: 3 })
    .where(eq(platformStats.id, 1));
}

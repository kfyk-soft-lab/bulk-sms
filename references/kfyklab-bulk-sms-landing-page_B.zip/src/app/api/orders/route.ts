import { NextResponse } from "next/server";
import { db } from "@/db";
import { orders } from "@/db/schema";
import { desc } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const rows = await db.select().from(orders).orderBy(desc(orders.createdAt)).limit(20);
    return NextResponse.json({ orders: rows });
  } catch {
    return NextResponse.json({ orders: [] });
  }
}

export async function POST(request: Request) {
  try {
    const body = (await request.json()) as Record<string, unknown>;
    const name = String(body.name ?? "").trim();
    const email = String(body.email ?? "").trim();
    const plan = String(body.plan ?? "Growth").trim();

    if (name.length < 2) {
      return NextResponse.json({ error: "Please enter your full name." }, { status: 400 });
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      return NextResponse.json({ error: "Please enter a valid email address." }, { status: 400 });
    }

    const volumeRaw = Number(body.volume ?? 0);
    const volume = Number.isFinite(volumeRaw) ? Math.max(0, Math.round(volumeRaw)) : 0;

    const [created] = await db
      .insert(orders)
      .values({
        name,
        email,
        phone: body.phone ? String(body.phone).slice(0, 40) : null,
        company: body.company ? String(body.company).slice(0, 120) : null,
        plan,
        volume,
        notes: body.notes ? String(body.notes).slice(0, 1000) : null,
      })
      .returning();

    return NextResponse.json({ order: created }, { status: 201 });
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "Could not place your order. Please try again." }, { status: 500 });
  }
}

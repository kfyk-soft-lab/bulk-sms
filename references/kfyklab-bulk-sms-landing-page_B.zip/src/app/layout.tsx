import type { Metadata } from "next";
import type { ReactNode } from "react";
import { Inter } from "next/font/google";
import "./globals.css";

const inter = Inter({ subsets: ["latin"], variable: "--font-inter", display: "swap" });

export const metadata: Metadata = {
  title: "Kfyklab — Bulk SMS That Actually Lands",
  description:
    "Kfyklab is the premium bulk SMS platform for commerce teams. Direct carrier routes, 99.2% delivery, sub-3s latency, and pay-as-you-go pricing. Order credits in minutes.",
  openGraph: {
    title: "Kfyklab — Bulk SMS That Actually Lands",
    description:
      "Direct carrier routes, 99.2% delivery, sub-3s latency. Order bulk SMS credits in minutes.",
    type: "website",
  },
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" className={inter.variable}>
      <body className="bg-ink font-sans text-slate-200 antialiased">{children}</body>
    </html>
  );
}

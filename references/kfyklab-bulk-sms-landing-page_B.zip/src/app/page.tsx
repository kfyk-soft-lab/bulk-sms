import { Navbar } from "@/components/Navbar";
import { Reveal } from "@/components/Reveal";
import { OrderForm } from "@/components/OrderForm";
import { Pricing } from "@/components/Pricing";
import { Faq } from "@/components/Faq";
import { Counter } from "@/components/Counter";

const logos = ["NORTHWIND", "Lumen&Co", "VELOCITÉ", "Harborside", "OKRA", "Pinecrest", "Mavenly", "Tidewell"];

const features = [
  {
    title: "Direct carrier routing",
    body: "340+ tier-1 interconnects with per-country least-cost routing and automatic failover the moment a route degrades.",
    icon: "M3 12h4l3 8 4-16 3 8h4",
  },
  {
    title: "Sub-3 second delivery",
    body: "Median handset delivery of 2.4s worldwide. Flash-sale traffic bursts to 12,000 messages per second without queueing.",
    icon: "M13 2 4 14h7l-1 8 9-12h-7l1-8Z",
  },
  {
    title: "Commerce automations",
    body: "Abandoned cart, back-in-stock, delivery updates and win-back flows that trigger from your store events out of the box.",
    icon: "M3 5h2l2.4 11.2a2 2 0 0 0 2 1.6h7.7a2 2 0 0 0 2-1.5L21 8H6",
  },
  {
    title: "Two-way conversations",
    body: "Inbound replies land in a shared inbox with keyword automation, so support and sales never miss a customer.",
    icon: "M21 11.5a8.4 8.4 0 0 1-9 8.4L3 21l1.2-4.1A8.4 8.4 0 1 1 21 11.5Z",
  },
  {
    title: "Compliance built in",
    body: "Consent ledgers, opt-out keywords, quiet hours and regional sender-ID registration handled automatically.",
    icon: "M12 3 4 6v6c0 5 3.4 8.6 8 9.6 4.6-1 8-4.6 8-9.6V6Z",
  },
  {
    title: "Revenue attribution",
    body: "Every link is tracked. See delivered, clicked and purchased in one view, broken down by segment and campaign.",
    icon: "M4 19V5m0 14h16M8 16V9m4 7V6m4 10v-4",
  },
];

const benefits = [
  { stat: 38, suffix: "%", label: "more recovered carts", copy: "Teams switching to Kfyklab recover an average of 38% more abandoned carts in the first 60 days." },
  { stat: 11, suffix: "x", label: "return on spend", copy: "Median 11x ROAS across 2,400 commerce accounts sending transactional and promotional traffic." },
  { stat: 46, suffix: "%", label: "lower cost per message", copy: "Least-cost routing and volume tiers cut the typical aggregator bill nearly in half." },
];

const testimonials = [
  {
    quote:
      "We moved 1.4 million monthly messages to Kfyklab and delivery jumped from 91% to 99.3% overnight. The abandoned-cart flow alone paid for the year.",
    name: "Amara Okoye",
    role: "Head of Growth, Northwind Supply",
  },
  {
    quote:
      "Ordering credits took four minutes and we were live before lunch. Their routing dashboard is the first one I've actually enjoyed looking at.",
    name: "Daniel Ferreira",
    role: "CTO, Velocité Retail",
  },
  {
    quote:
      "Support answers in a shared Slack channel in minutes, not days. During Black Friday we burst to 9k messages a second with zero drops.",
    name: "Priya Raghunathan",
    role: "VP Engineering, Harborside",
  },
];

function Section({
  id,
  eyebrow,
  title,
  subtitle,
  children,
}: {
  id?: string;
  eyebrow: string;
  title: string;
  subtitle?: string;
  children: React.ReactNode;
}) {
  return (
    <section id={id} className="relative mx-auto max-w-6xl px-5 py-24 sm:px-6 sm:py-32">
      <Reveal className="mx-auto max-w-2xl text-center">
        <span className="inline-flex items-center rounded-full border border-white/12 bg-white/5 px-3.5 py-1.5 text-[11px] font-semibold uppercase tracking-[0.16em] text-[#9d8cff]">
          {eyebrow}
        </span>
        <h2 className="mt-5 text-3xl font-semibold tracking-tight text-white sm:text-4xl md:text-[2.75rem] md:leading-[1.1]">
          {title}
        </h2>
        {subtitle && <p className="mt-4 text-base leading-relaxed text-slate-400">{subtitle}</p>}
      </Reveal>
      <div className="mt-14">{children}</div>
    </section>
  );
}

export default function Home() {
  return (
    <main id="top" className="relative overflow-x-hidden">
      <Navbar />

      {/* ambient background */}
      <div aria-hidden className="pointer-events-none fixed inset-0 -z-10">
        <div className="absolute left-1/2 top-[-18rem] h-[38rem] w-[38rem] -translate-x-1/2 rounded-full bg-[#6d5efc]/25 blur-[140px] animate-float-slow" />
        <div className="absolute right-[-12rem] top-[22rem] h-[30rem] w-[30rem] rounded-full bg-[#19c6ff]/14 blur-[140px] animate-float-slower" />
        <div className="absolute bottom-[-10rem] left-[-10rem] h-[32rem] w-[32rem] rounded-full bg-[#ff5bb0]/12 blur-[150px] animate-float-slow" />
      </div>

      {/* HERO */}
      <section className="relative pt-36 pb-16 sm:pt-44">
        <div aria-hidden className="absolute inset-0 -z-10 grid-bg" />
        <div className="mx-auto grid max-w-6xl items-center gap-14 px-5 sm:px-6 lg:grid-cols-[1.05fr_0.95fr]">
          <div>
            <div className="animate-rise inline-flex items-center gap-2 rounded-full border border-white/12 bg-white/5 px-3 py-1.5 text-xs text-slate-300 backdrop-blur">
              <span className="relative flex h-2 w-2">
                <span className="absolute inline-flex h-full w-full rounded-full bg-emerald-400 animate-pulse-ring" />
                <span className="relative inline-flex h-2 w-2 rounded-full bg-emerald-400" />
              </span>
              99.2% global delivery · live network status
            </div>

            <h1
              className="animate-rise mt-6 text-[2.6rem] font-semibold leading-[1.05] tracking-tight text-white sm:text-6xl"
              style={{ animationDelay: "80ms" }}
            >
              Bulk SMS that <span className="text-shimmer">actually lands</span> in the pocket.
            </h1>

            <p
              className="animate-rise mt-6 max-w-xl text-base leading-relaxed text-slate-400 sm:text-lg"
              style={{ animationDelay: "160ms" }}
            >
              Kfyklab moves your campaigns over direct carrier routes in 214 countries — so promos, OTPs
              and order updates arrive in seconds, not minutes. Order credits today, send before dinner.
            </p>

            <div className="animate-rise mt-9 flex flex-col gap-3 sm:flex-row" style={{ animationDelay: "240ms" }}>
              <a
                href="#order"
                className="group relative overflow-hidden rounded-xl bg-gradient-to-r from-[#6d5efc] via-[#7f6bff] to-[#19c6ff] px-7 py-4 text-center text-sm font-semibold text-white transition-all duration-300 hover:-translate-y-0.5 hover:shadow-2xl hover:shadow-indigo-700/40"
              >
                Order SMS credits
              </a>
              <a
                href="#pricing"
                className="rounded-xl border border-white/15 bg-white/5 px-7 py-4 text-center text-sm font-semibold text-white backdrop-blur transition-all duration-300 hover:-translate-y-0.5 hover:bg-white/10"
              >
                See volume pricing
              </a>
            </div>

            <dl className="animate-rise mt-12 grid max-w-lg grid-cols-3 gap-6" style={{ animationDelay: "320ms" }}>
              {[
                { v: <Counter to={4.8} decimals={1} suffix="B+" />, l: "Messages / year" },
                { v: <Counter to={214} suffix="" />, l: "Countries covered" },
                { v: <Counter to={2.4} decimals={1} suffix="s" />, l: "Median delivery" },
              ].map((s, i) => (
                <div key={i}>
                  <dt className="text-2xl font-semibold tracking-tight text-white sm:text-3xl">{s.v}</dt>
                  <dd className="mt-1 text-xs text-slate-400">{s.l}</dd>
                </div>
              ))}
            </dl>
          </div>

          {/* Phone mock */}
          <div className="animate-rise relative mx-auto w-full max-w-sm" style={{ animationDelay: "200ms" }}>
            <div className="glass relative rounded-[2.2rem] p-3 shadow-2xl shadow-black/60">
              <div className="rounded-[1.7rem] bg-gradient-to-b from-[#0b0d16] to-[#05060a] p-5">
                <div className="mx-auto mb-5 h-1.5 w-16 rounded-full bg-white/15" />
                <p className="text-[11px] uppercase tracking-[0.18em] text-slate-500">Today · 09:41</p>
                <div className="mt-4 space-y-3">
                  {[
                    { from: "NORTHWIND", text: "Your cart is still warm 🔥 Finish checkout in the next hour for 15% off → nwd.co/x92", d: "0ms" },
                    { from: "KFYKLAB", text: "Your verification code is 418 209. It expires in 10 minutes.", d: "150ms" },
                    { from: "LUMEN&CO", text: "Order #4821 is out for delivery. Track live → lmn.co/t/4821", d: "300ms" },
                  ].map((m) => (
                    <div
                      key={m.from}
                      className="animate-rise rounded-2xl border border-white/8 bg-white/[0.05] p-3.5"
                      style={{ animationDelay: `calc(400ms + ${m.d})` }}
                    >
                      <p className="text-[10px] font-semibold uppercase tracking-[0.14em] text-[#9d8cff]">{m.from}</p>
                      <p className="mt-1.5 text-[13px] leading-relaxed text-slate-200">{m.text}</p>
                      <p className="mt-2 flex items-center gap-1 text-[10px] text-emerald-400">
                        <svg viewBox="0 0 20 20" className="h-3 w-3" fill="currentColor" aria-hidden>
                          <path d="M8.1 14.3 4.4 10.6l1.3-1.3 2.4 2.4 6-6 1.3 1.3z" />
                        </svg>
                        Delivered · 2.1s
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            </div>
            <div className="glass absolute -bottom-6 -left-6 hidden rounded-2xl px-4 py-3 shadow-xl shadow-black/50 sm:block">
              <p className="text-[10px] uppercase tracking-[0.14em] text-slate-400">Delivery rate</p>
              <p className="text-xl font-semibold text-white">
                <Counter to={99.2} decimals={1} suffix="%" />
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* SOCIAL PROOF */}
      <section aria-label="Trusted by" className="relative py-10">
        <Reveal className="mx-auto max-w-6xl px-5 sm:px-6">
          <p className="text-center text-xs uppercase tracking-[0.2em] text-slate-500">
            Powering messaging for 2,400+ commerce teams
          </p>
          <div className="relative mt-7 overflow-hidden [mask-image:linear-gradient(to_right,transparent,#000_12%,#000_88%,transparent)]">
            <div className="flex w-max animate-marquee gap-14">
              {[...logos, ...logos].map((l, i) => (
                <span key={i} className="whitespace-nowrap text-lg font-semibold tracking-tight text-white/35 transition-colors hover:text-white/70">
                  {l}
                </span>
              ))}
            </div>
          </div>
        </Reveal>
      </section>

      {/* FEATURES */}
      <Section
        id="features"
        eyebrow="Platform"
        title="Everything you need to send at scale"
        subtitle="One API, one dashboard, one invoice. Kfyklab replaces the patchwork of aggregators, spreadsheets and cron jobs holding your messaging together."
      >
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {features.map((f, i) => (
            <Reveal key={f.title} delay={i * 80}>
              <article className="group glass relative h-full overflow-hidden rounded-2xl p-6 transition-all duration-500 hover:-translate-y-1.5 hover:border-white/20">
                <div className="pointer-events-none absolute -right-16 -top-16 h-40 w-40 rounded-full bg-[#6d5efc]/0 blur-2xl transition-all duration-700 group-hover:bg-[#6d5efc]/30" />
                <span className="relative grid h-11 w-11 place-items-center rounded-xl border border-white/10 bg-gradient-to-br from-white/15 to-white/5">
                  <svg viewBox="0 0 24 24" className="h-5 w-5 text-[#9d8cff] transition-transform duration-500 group-hover:scale-110" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
                    <path d={f.icon} />
                  </svg>
                </span>
                <h3 className="relative mt-5 text-base font-semibold text-white">{f.title}</h3>
                <p className="relative mt-2 text-sm leading-relaxed text-slate-400">{f.body}</p>
              </article>
            </Reveal>
          ))}
        </div>
      </Section>

      {/* PRODUCT SHOWCASE */}
      <Section
        id="platform"
        eyebrow="Product tour"
        title="A console your team will fight over"
        subtitle="Compose, segment, schedule and reconcile — all from a workspace built for speed."
      >
        <div className="grid gap-6 lg:grid-cols-5">
          <Reveal className="lg:col-span-3">
            <div className="glass h-full overflow-hidden rounded-3xl p-6 sm:p-8">
              <div className="flex items-center gap-2">
                {["#ff5f57", "#febc2e", "#28c840"].map((c) => (
                  <span key={c} className="h-3 w-3 rounded-full" style={{ background: c }} />
                ))}
                <span className="ml-3 text-xs text-slate-500">app.kfyklab.com / campaigns / spring-drop</span>
              </div>
              <div className="mt-6 grid gap-4 sm:grid-cols-2">
                {[
                  { k: "Sent", v: "812,400", c: "text-white" },
                  { k: "Delivered", v: "806,118", c: "text-emerald-300" },
                  { k: "Clicked", v: "214,903", c: "text-[#19c6ff]" },
                  { k: "Revenue", v: "$1,284,610", c: "text-[#9d8cff]" },
                ].map((m) => (
                  <div key={m.k} className="rounded-2xl border border-white/8 bg-black/30 p-4">
                    <p className="text-xs uppercase tracking-[0.14em] text-slate-500">{m.k}</p>
                    <p className={`mt-1.5 text-2xl font-semibold tracking-tight ${m.c}`}>{m.v}</p>
                  </div>
                ))}
              </div>
              <div className="mt-5 rounded-2xl border border-white/8 bg-black/30 p-5">
                <p className="text-xs uppercase tracking-[0.14em] text-slate-500">Throughput · last 60s</p>
                <div className="mt-4 flex h-28 items-end gap-1.5">
                  {[32, 48, 40, 62, 55, 78, 70, 92, 84, 96, 74, 88, 60, 72, 99, 81, 67, 90, 76, 94].map((h, i) => (
                    <span
                      key={i}
                      className="flex-1 rounded-t bg-gradient-to-t from-[#6d5efc]/40 to-[#19c6ff] transition-all duration-500 hover:from-[#ff5bb0]/50 hover:to-[#ff5bb0]"
                      style={{ height: `${h}%` }}
                    />
                  ))}
                </div>
              </div>
            </div>
          </Reveal>

          <div className="grid gap-6 lg:col-span-2">
            {[
              { t: "Drop-in SDKs", b: "Send your first message in four lines of code. Node, Python, PHP, Go, Ruby and a typed REST API with webhooks." },
              { t: "Smart segments", b: "Build audiences from purchase history, location and engagement — refreshed in real time as orders flow in." },
              { t: "Spend guardrails", b: "Hard caps, per-campaign budgets and anomaly alerts so a misconfigured loop never drains your balance." },
            ].map((c, i) => (
              <Reveal key={c.t} delay={120 + i * 110}>
                <div className="glass h-full rounded-2xl p-6 transition-all duration-500 hover:-translate-y-1 hover:border-white/20">
                  <h3 className="text-base font-semibold text-white">{c.t}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-slate-400">{c.b}</p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </Section>

      {/* BENEFITS */}
      <Section
        eyebrow="Outcomes"
        title="Numbers your CFO will like"
        subtitle="SMS is the highest-intent channel you own. Kfyklab makes it the cheapest one too."
      >
        <div className="grid gap-5 md:grid-cols-3">
          {benefits.map((b, i) => (
            <Reveal key={b.label} delay={i * 110}>
              <div className="relative h-full overflow-hidden rounded-3xl border border-white/10 bg-gradient-to-b from-white/[0.08] to-white/[0.01] p-8 transition-all duration-500 hover:-translate-y-1.5">
                <p className="bg-gradient-to-r from-white to-[#9d8cff] bg-clip-text text-5xl font-semibold tracking-tight text-transparent">
                  <Counter to={b.stat} suffix={b.suffix} />
                </p>
                <p className="mt-3 text-sm font-semibold text-white">{b.label}</p>
                <p className="mt-2 text-sm leading-relaxed text-slate-400">{b.copy}</p>
              </div>
            </Reveal>
          ))}
        </div>
      </Section>

      {/* TESTIMONIALS */}
      <Section
        id="testimonials"
        eyebrow="Customers"
        title="Loved by the teams who send the most"
        subtitle="From DTC launches to fintech OTP traffic at 4am, Kfyklab keeps the message moving."
      >
        <div className="grid gap-5 md:grid-cols-3">
          {testimonials.map((t, i) => (
            <Reveal key={t.name} delay={i * 110}>
              <figure className="glass flex h-full flex-col rounded-3xl p-7 transition-all duration-500 hover:-translate-y-1.5 hover:border-white/20">
                <div className="flex gap-1 text-[#ffcc5c]" aria-label="5 out of 5 stars">
                  {Array.from({ length: 5 }).map((_, s) => (
                    <svg key={s} viewBox="0 0 20 20" className="h-4 w-4" fill="currentColor" aria-hidden>
                      <path d="m10 1.8 2.5 5.1 5.6.8-4 3.9 1 5.6-5.1-2.7-5 2.7 1-5.6-4.1-3.9 5.6-.8z" />
                    </svg>
                  ))}
                </div>
                <blockquote className="mt-5 flex-1 text-sm leading-relaxed text-slate-300">“{t.quote}”</blockquote>
                <figcaption className="mt-6 flex items-center gap-3 border-t border-white/8 pt-5">
                  <span className="grid h-10 w-10 place-items-center rounded-full bg-gradient-to-br from-[#6d5efc] to-[#19c6ff] text-sm font-semibold text-white">
                    {t.name.charAt(0)}
                  </span>
                  <span>
                    <span className="block text-sm font-semibold text-white">{t.name}</span>
                    <span className="block text-xs text-slate-400">{t.role}</span>
                  </span>
                </figcaption>
              </figure>
            </Reveal>
          ))}
        </div>
      </Section>

      {/* PRICING */}
      <Section
        id="pricing"
        eyebrow="Pricing"
        title="Pay per message. Nothing else."
        subtitle="No platform fee, no seat licences, no expiry. Volume discounts apply automatically as you grow."
      >
        <Pricing />
        <Reveal className="mt-8 text-center text-sm text-slate-400">
          <p>
            Sending more than 1M/month?{" "}
            <a href="#order" className="font-semibold text-[#9d8cff] underline-offset-4 hover:underline">
              Talk to us about Enterprise rates from $0.0029
            </a>
            .
          </p>
        </Reveal>
      </Section>

      {/* ORDER / CTA */}
      <section id="order" className="relative mx-auto max-w-6xl px-5 py-24 sm:px-6 sm:py-28">
        <div className="grid items-center gap-12 lg:grid-cols-2">
          <Reveal>
            <span className="inline-flex items-center rounded-full border border-white/12 bg-white/5 px-3.5 py-1.5 text-[11px] font-semibold uppercase tracking-[0.16em] text-[#9d8cff]">
              Get started
            </span>
            <h2 className="mt-5 text-3xl font-semibold tracking-tight text-white sm:text-[2.6rem] sm:leading-[1.1]">
              Your first campaign could be live in two hours.
            </h2>
            <p className="mt-4 max-w-lg text-base leading-relaxed text-slate-400">
              Tell us your volume and we&apos;ll provision routes, sender ID and API keys the same day. No sales
              theatre, no annual lock-in — just a balance you can start sending from.
            </p>
            <ul className="mt-8 space-y-3.5">
              {[
                "Free test credits with every order",
                "Dedicated onboarding engineer",
                "Migrate from Twilio, Vonage or MessageBird in a day",
                "Invoice, card or crypto billing",
              ].map((b) => (
                <li key={b} className="flex items-start gap-3 text-sm text-slate-300">
                  <span className="mt-0.5 grid h-5 w-5 shrink-0 place-items-center rounded-full bg-[#6d5efc]/25 text-[#19c6ff]">
                    <svg viewBox="0 0 20 20" className="h-3 w-3" fill="currentColor" aria-hidden>
                      <path d="M8.1 14.3 4.4 10.6l1.3-1.3 2.4 2.4 6-6 1.3 1.3z" />
                    </svg>
                  </span>
                  {b}
                </li>
              ))}
            </ul>
          </Reveal>
          <Reveal delay={140}>
            <OrderForm />
          </Reveal>
        </div>
      </section>

      {/* FAQ */}
      <Section id="faq" eyebrow="FAQ" title="Questions, answered" subtitle="Still curious? Our team replies in under 10 minutes during business hours.">
        <Faq />
      </Section>

      {/* FINAL CTA */}
      <section className="mx-auto max-w-6xl px-5 pb-24 sm:px-6">
        <Reveal>
          <div className="relative overflow-hidden rounded-[2rem] border border-white/10 bg-gradient-to-br from-[#6d5efc]/30 via-[#1a1333]/60 to-[#19c6ff]/20 px-7 py-16 text-center sm:px-14">
            <div aria-hidden className="pointer-events-none absolute -left-20 -top-20 h-72 w-72 rounded-full bg-[#ff5bb0]/25 blur-3xl animate-float-slower" />
            <h2 className="relative text-3xl font-semibold tracking-tight text-white sm:text-5xl sm:leading-[1.08]">
              Stop paying for messages
              <br className="hidden sm:block" /> that never arrive.
            </h2>
            <p className="relative mx-auto mt-5 max-w-xl text-base text-slate-300">
              Join 2,400+ teams sending on Kfyklab&apos;s direct routes. Order credits now — your first 500
              messages are on us.
            </p>
            <div className="relative mt-9 flex flex-col justify-center gap-3 sm:flex-row">
              <a
                href="#order"
                className="rounded-xl bg-white px-8 py-4 text-sm font-semibold text-[#05060a] transition-all duration-300 hover:-translate-y-0.5 hover:shadow-2xl hover:shadow-white/20"
              >
                Order SMS credits
              </a>
              <a
                href="#pricing"
                className="rounded-xl border border-white/20 bg-white/5 px-8 py-4 text-sm font-semibold text-white backdrop-blur transition-all duration-300 hover:-translate-y-0.5 hover:bg-white/10"
              >
                Compare plans
              </a>
            </div>
          </div>
        </Reveal>
      </section>

      {/* FOOTER */}
      <footer className="border-t border-white/8 bg-black/40">
        <div className="mx-auto max-w-6xl px-5 py-14 sm:px-6">
          <div className="grid gap-10 md:grid-cols-[1.4fr_1fr_1fr_1fr]">
            <div>
              <div className="flex items-center gap-2.5">
                <span className="grid h-9 w-9 place-items-center rounded-xl bg-gradient-to-br from-[#6d5efc] to-[#19c6ff]">
                  <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="white" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
                    <path d="M21 11.5a8.4 8.4 0 0 1-9 8.4L3 21l1.2-4.1A8.4 8.4 0 1 1 21 11.5Z" />
                  </svg>
                </span>
                <span className="text-[17px] font-semibold text-white">
                  Kfyk<span className="text-[#9d8cff]">lab</span>
                </span>
              </div>
              <p className="mt-4 max-w-xs text-sm leading-relaxed text-slate-400">
                Premium bulk SMS infrastructure for commerce teams who measure every message in revenue.
              </p>
            </div>
            {[
              { h: "Product", items: ["Features", "Platform", "Pricing", "API docs", "Status"] },
              { h: "Company", items: ["About", "Customers", "Careers", "Press", "Contact"] },
              { h: "Legal", items: ["Privacy", "Terms", "DPA", "Compliance", "Security"] },
            ].map((col) => (
              <div key={col.h}>
                <h3 className="text-xs font-semibold uppercase tracking-[0.16em] text-white">{col.h}</h3>
                <ul className="mt-4 space-y-2.5">
                  {col.items.map((it) => (
                    <li key={it}>
                      <a href="#top" className="text-sm text-slate-400 transition-colors hover:text-white">
                        {it}
                      </a>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
          <div className="mt-12 flex flex-col items-center justify-between gap-4 border-t border-white/8 pt-7 sm:flex-row">
            <p className="text-xs text-slate-500">© {new Date().getFullYear()} Kfyklab Ltd. All rights reserved.</p>
            <p className="text-xs text-slate-500">Built for deliverability · ISO 27001 · GDPR ready</p>
          </div>
        </div>
      </footer>
    </main>
  );
}

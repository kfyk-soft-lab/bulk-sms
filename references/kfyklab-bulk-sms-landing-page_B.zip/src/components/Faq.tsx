"use client";

import { useState } from "react";
import { Reveal } from "./Reveal";

const faqs = [
  {
    q: "How fast can we start sending?",
    a: "Most accounts are live within two hours. Place your order, our compliance team provisions your sender ID and routes, and you get API keys plus a dashboard login by email.",
  },
  {
    q: "Which countries do you cover?",
    a: "Kfyklab delivers to 214 countries through 340+ direct carrier connections, with intelligent failover to tier-1 backups when a route degrades.",
  },
  {
    q: "Do SMS credits expire?",
    a: "Never. Credits stay on your balance indefinitely, and unused volume rolls over month to month with no penalties.",
  },
  {
    q: "Can I integrate with my store?",
    a: "Yes. One-click plugins for Shopify, WooCommerce and Magento, plus a REST API, webhooks, Zapier and official SDKs for Node, Python, PHP and Go.",
  },
  {
    q: "How do you handle compliance?",
    a: "Built-in opt-out keyword handling, consent logs, quiet-hour enforcement, GDPR/TCPA tooling and regional sender-ID registration are included on every plan.",
  },
  {
    q: "What if a campaign underdelivers?",
    a: "Every message is reconciled against carrier DLRs. Any message that fails on our side is automatically credited back to your balance within 24 hours.",
  },
];

export function Faq() {
  const [open, setOpen] = useState<number | null>(0);
  return (
    <div className="mx-auto max-w-3xl divide-y divide-white/8 overflow-hidden rounded-3xl border border-white/10 bg-white/[0.03]">
      {faqs.map((f, i) => {
        const isOpen = open === i;
        return (
          <Reveal key={f.q} delay={i * 60}>
            <div>
              <h3>
                <button
                  type="button"
                  aria-expanded={isOpen}
                  onClick={() => setOpen(isOpen ? null : i)}
                  className="flex w-full items-center justify-between gap-4 px-6 py-5 text-left transition-colors hover:bg-white/[0.04]"
                >
                  <span className="text-[15px] font-medium text-white">{f.q}</span>
                  <span
                    className={`grid h-7 w-7 shrink-0 place-items-center rounded-full border border-white/15 text-white transition-transform duration-300 ${
                      isOpen ? "rotate-45 bg-[#6d5efc]/30" : ""
                    }`}
                    aria-hidden
                  >
                    +
                  </span>
                </button>
              </h3>
              <div
                className={`grid transition-all duration-500 ease-out ${
                  isOpen ? "grid-rows-[1fr] opacity-100" : "grid-rows-[0fr] opacity-0"
                }`}
              >
                <div className="overflow-hidden">
                  <p className="px-6 pb-5 text-sm leading-relaxed text-slate-400">{f.a}</p>
                </div>
              </div>
            </div>
          </Reveal>
        );
      })}
    </div>
  );
}

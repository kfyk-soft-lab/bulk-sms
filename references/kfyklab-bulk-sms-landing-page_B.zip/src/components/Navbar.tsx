"use client";

import { useEffect, useState } from "react";

const links = [
  { href: "#features", label: "Features" },
  { href: "#platform", label: "Platform" },
  { href: "#testimonials", label: "Customers" },
  { href: "#pricing", label: "Pricing" },
  { href: "#faq", label: "FAQ" },
];

export function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 16);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header className="fixed inset-x-0 top-0 z-50">
      <div
        className={`mx-auto mt-3 max-w-6xl px-4 transition-all duration-500 sm:px-6 ${
          scrolled ? "mt-2" : "mt-5"
        }`}
      >
        <nav
          aria-label="Primary"
          className={`flex items-center justify-between rounded-2xl px-4 py-3 transition-all duration-500 sm:px-5 ${
            scrolled ? "glass shadow-2xl shadow-black/40" : "border border-transparent"
          }`}
        >
          <a href="#top" className="group flex items-center gap-2.5">
            <span className="relative grid h-9 w-9 place-items-center rounded-xl bg-gradient-to-br from-[#6d5efc] via-[#8b7bff] to-[#19c6ff] shadow-lg shadow-indigo-900/40">
              <span className="absolute inset-0 rounded-xl bg-[#6d5efc]/50 animate-pulse-ring" />
              <svg viewBox="0 0 24 24" className="relative h-4.5 w-4.5" width="18" height="18" fill="none" stroke="white" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
                <path d="M21 11.5a8.4 8.4 0 0 1-9 8.4L3 21l1.2-4.1A8.4 8.4 0 1 1 21 11.5Z" />
              </svg>
            </span>
            <span className="text-[17px] font-semibold tracking-tight text-white">
              Kfyk<span className="text-[#9d8cff]">lab</span>
            </span>
          </a>

          <ul className="hidden items-center gap-1 md:flex">
            {links.map((l) => (
              <li key={l.href}>
                <a
                  href={l.href}
                  className="rounded-lg px-3 py-2 text-sm text-slate-300 transition-colors hover:bg-white/5 hover:text-white"
                >
                  {l.label}
                </a>
              </li>
            ))}
          </ul>

          <div className="flex items-center gap-2">
            <a
              href="#order"
              className="group relative hidden overflow-hidden rounded-xl bg-white px-4 py-2.5 text-sm font-semibold text-[#05060a] transition-transform duration-300 hover:-translate-y-0.5 hover:shadow-lg hover:shadow-white/20 sm:inline-flex"
            >
              Order credits
            </a>
            <button
              type="button"
              onClick={() => setOpen((v) => !v)}
              aria-expanded={open}
              aria-label="Toggle navigation menu"
              className="grid h-10 w-10 place-items-center rounded-xl border border-white/10 bg-white/5 text-white md:hidden"
            >
              <span className="relative block h-3.5 w-5">
                <span className={`absolute left-0 h-0.5 w-5 bg-white transition-all ${open ? "top-1.5 rotate-45" : "top-0"}`} />
                <span className={`absolute left-0 top-1.5 h-0.5 w-5 bg-white transition-all ${open ? "opacity-0" : "opacity-100"}`} />
                <span className={`absolute left-0 h-0.5 w-5 bg-white transition-all ${open ? "top-1.5 -rotate-45" : "top-3"}`} />
              </span>
            </button>
          </div>
        </nav>

        <div
          className={`glass mt-2 overflow-hidden rounded-2xl transition-all duration-400 md:hidden ${
            open ? "max-h-96 opacity-100" : "pointer-events-none max-h-0 opacity-0"
          }`}
        >
          <ul className="flex flex-col p-2">
            {links.map((l) => (
              <li key={l.href}>
                <a
                  onClick={() => setOpen(false)}
                  href={l.href}
                  className="block rounded-xl px-4 py-3 text-sm text-slate-200 hover:bg-white/5"
                >
                  {l.label}
                </a>
              </li>
            ))}
            <li className="p-2">
              <a
                onClick={() => setOpen(false)}
                href="#order"
                className="block rounded-xl bg-white px-4 py-3 text-center text-sm font-semibold text-[#05060a]"
              >
                Order credits
              </a>
            </li>
          </ul>
        </div>
      </div>
    </header>
  );
}

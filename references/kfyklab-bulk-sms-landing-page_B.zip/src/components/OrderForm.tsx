"use client";

import { useEffect, useState } from "react";

const PLANS = [
  { name: "Starter", rate: 0.0089, min: 5000 },
  { name: "Growth", rate: 0.0062, min: 50000 },
  { name: "Scale", rate: 0.0041, min: 250000 },
  { name: "Enterprise", rate: 0.0029, min: 1000000 },
];

export function OrderForm() {
  const [plan, setPlan] = useState("Growth");
  const [volume, setVolume] = useState(50000);
  const [form, setForm] = useState({ name: "", email: "", phone: "", company: "", notes: "" });
  const [state, setState] = useState<"idle" | "loading" | "done" | "error">("idle");
  const [message, setMessage] = useState("");

  useEffect(() => {
    const handler = (e: Event) => {
      const detail = (e as CustomEvent<{ plan: string; volume: number }>).detail;
      if (!detail) return;
      setPlan(detail.plan);
      setVolume(detail.volume);
    };
    window.addEventListener("kfyklab:selectplan", handler);
    return () => window.removeEventListener("kfyklab:selectplan", handler);
  }, []);

  const active = PLANS.find((p) => p.name === plan) ?? PLANS[1];
  const total = volume * active.rate;

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setState("loading");
    setMessage("");
    try {
      const res = await fetch("/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...form, plan, volume }),
      });
      const data = (await res.json()) as { error?: string };
      if (!res.ok) throw new Error(data.error ?? "Something went wrong.");
      setState("done");
      setMessage("Order received — a Kfyklab specialist will activate your sender ID within 2 hours.");
      setForm({ name: "", email: "", phone: "", company: "", notes: "" });
    } catch (err) {
      setState("error");
      setMessage(err instanceof Error ? err.message : "Something went wrong.");
    }
  }

  const field =
    "w-full rounded-xl border border-white/10 bg-white/[0.04] px-4 py-3 text-sm text-white placeholder:text-slate-500 transition-colors focus:border-[#6d5efc]/60 focus:bg-white/[0.07]";

  return (
    <div className="glass relative overflow-hidden rounded-3xl p-6 shadow-2xl shadow-black/50 sm:p-8">
      <div className="pointer-events-none absolute -right-20 -top-24 h-60 w-60 rounded-full bg-[#6d5efc]/30 blur-3xl" />
      <div className="relative">
        <h3 className="text-xl font-semibold text-white sm:text-2xl">Place your bulk SMS order</h3>
        <p className="mt-2 text-sm text-slate-400">
          No contracts. Credits never expire. Go live the same day.
        </p>

        <form onSubmit={submit} className="mt-6 space-y-5">
          <fieldset>
            <legend className="mb-2 text-xs font-semibold uppercase tracking-[0.14em] text-slate-400">
              Plan
            </legend>
            <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
              {PLANS.map((p) => (
                <button
                  type="button"
                  key={p.name}
                  onClick={() => {
                    setPlan(p.name);
                    setVolume((v) => Math.max(v, p.min));
                  }}
                  aria-pressed={plan === p.name}
                  className={`rounded-xl border px-2 py-2.5 text-xs font-semibold transition-all duration-300 ${
                    plan === p.name
                      ? "border-[#6d5efc] bg-[#6d5efc]/20 text-white shadow-lg shadow-indigo-900/40"
                      : "border-white/10 bg-white/[0.03] text-slate-300 hover:border-white/25 hover:text-white"
                  }`}
                >
                  {p.name}
                </button>
              ))}
            </div>
          </fieldset>

          <div>
            <label htmlFor="volume" className="mb-2 flex items-baseline justify-between text-xs font-semibold uppercase tracking-[0.14em] text-slate-400">
              <span>Monthly volume</span>
              <span className="font-mono text-sm normal-case tracking-normal text-white">
                {volume.toLocaleString()} SMS
              </span>
            </label>
            <input
              id="volume"
              type="range"
              min={1000}
              max={2000000}
              step={1000}
              value={volume}
              onChange={(e) => setVolume(Number(e.target.value))}
              className="w-full accent-[#6d5efc]"
            />
            <div className="mt-3 flex items-center justify-between rounded-xl border border-white/10 bg-black/30 px-4 py-3">
              <span className="text-sm text-slate-400">
                ${active.rate.toFixed(4)} <span className="text-slate-500">/ message</span>
              </span>
              <span className="text-lg font-semibold text-white">
                ${total.toLocaleString(undefined, { maximumFractionDigits: 2 })}
                <span className="ml-1 text-xs font-normal text-slate-400">/ mo est.</span>
              </span>
            </div>
          </div>

          <div className="grid gap-3 sm:grid-cols-2">
            <div>
              <label htmlFor="name" className="sr-only">Full name</label>
              <input id="name" required className={field} placeholder="Full name"
                value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
            </div>
            <div>
              <label htmlFor="email" className="sr-only">Work email</label>
              <input id="email" type="email" required className={field} placeholder="Work email"
                value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
            </div>
            <div>
              <label htmlFor="company" className="sr-only">Company</label>
              <input id="company" className={field} placeholder="Company"
                value={form.company} onChange={(e) => setForm({ ...form, company: e.target.value })} />
            </div>
            <div>
              <label htmlFor="phone" className="sr-only">Phone</label>
              <input id="phone" className={field} placeholder="Phone (optional)"
                value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
            </div>
          </div>

          <div>
            <label htmlFor="notes" className="sr-only">Use case</label>
            <textarea id="notes" rows={3} className={field} placeholder="Tell us about your use case — countries, sender ID, campaign type…"
              value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} />
          </div>

          <button
            type="submit"
            disabled={state === "loading"}
            className="group relative w-full overflow-hidden rounded-xl bg-gradient-to-r from-[#6d5efc] via-[#7f6bff] to-[#19c6ff] px-6 py-3.5 text-sm font-semibold text-white transition-all duration-300 hover:-translate-y-0.5 hover:shadow-xl hover:shadow-indigo-700/40 disabled:cursor-not-allowed disabled:opacity-60"
          >
            <span className="relative">
              {state === "loading" ? "Submitting…" : "Place order — activate in 2 hours"}
            </span>
          </button>

          <p aria-live="polite" className="min-h-5 text-center text-sm">
            {message && (
              <span className={state === "done" ? "text-emerald-300" : "text-rose-300"}>{message}</span>
            )}
          </p>
        </form>
      </div>
    </div>
  );
}

"use client";

import { Reveal } from "./Reveal";

const tiers = [
  {
    name: "Starter",
    price: "$0.0089",
    volume: 5000,
    blurb: "For first campaigns and product launches.",
    features: ["5,000+ messages", "Shared sender ID", "Email support", "Delivery reports", "REST API + CSV upload"],
  },
  {
    name: "Growth",
    price: "$0.0062",
    volume: 50000,
    blurb: "For stores scaling abandoned-cart revenue.",
    featured: true,
    features: [
      "50,000+ messages",
      "Dedicated sender ID",
      "Shopify & Woo plugins",
      "Automations + segments",
      "Priority routes",
      "Slack support channel",
    ],
  },
  {
    name: "Scale",
    price: "$0.0041",
    volume: 250000,
    blurb: "For high-volume commerce and fintech.",
    features: ["250,000+ messages", "Multi-route failover", "99.9% uptime SLA", "Dedicated CSM", "Custom throughput"],
  },
];

export function Pricing() {
  function choose(plan: string, volume: number) {
    window.dispatchEvent(new CustomEvent("kfyklab:selectplan", { detail: { plan, volume } }));
    document.getElementById("order")?.scrollIntoView({ behavior: "smooth", block: "start" });
  }

  return (
    <div className="grid gap-6 md:grid-cols-3">
      {tiers.map((t, i) => (
        <Reveal key={t.name} delay={i * 110}>
          <div
            className={`group relative flex h-full flex-col rounded-3xl p-7 transition-all duration-500 hover:-translate-y-2 ${
              t.featured
                ? "border border-[#6d5efc]/50 bg-gradient-to-b from-[#6d5efc]/18 to-white/[0.02] shadow-2xl shadow-indigo-950/60"
                : "glass"
            }`}
          >
            {t.featured && (
              <span className="absolute -top-3 left-7 rounded-full bg-gradient-to-r from-[#6d5efc] to-[#19c6ff] px-3 py-1 text-[11px] font-semibold uppercase tracking-wider text-white">
                Most popular
              </span>
            )}
            <h3 className="text-lg font-semibold text-white">{t.name}</h3>
            <p className="mt-1 text-sm text-slate-400">{t.blurb}</p>
            <div className="mt-5 flex items-end gap-1.5">
              <span className="text-4xl font-semibold tracking-tight text-white">{t.price}</span>
              <span className="pb-1.5 text-sm text-slate-400">/ SMS</span>
            </div>
            <ul className="mt-6 space-y-3 text-sm text-slate-300">
              {t.features.map((f) => (
                <li key={f} className="flex items-start gap-2.5">
                  <svg viewBox="0 0 20 20" className="mt-0.5 h-4 w-4 shrink-0 text-[#19c6ff]" fill="currentColor" aria-hidden>
                    <path d="M8.1 14.3 4.4 10.6l1.3-1.3 2.4 2.4 6-6 1.3 1.3z" />
                  </svg>
                  {f}
                </li>
              ))}
            </ul>
            <button
              type="button"
              onClick={() => choose(t.name, t.volume)}
              className={`mt-7 w-full rounded-xl px-5 py-3 text-sm font-semibold transition-all duration-300 hover:-translate-y-0.5 ${
                t.featured
                  ? "bg-gradient-to-r from-[#6d5efc] to-[#19c6ff] text-white hover:shadow-lg hover:shadow-indigo-700/40"
                  : "border border-white/15 bg-white/5 text-white hover:bg-white/10"
              }`}
            >
              Order {t.name}
            </button>
          </div>
        </Reveal>
      ))}
    </div>
  );
}

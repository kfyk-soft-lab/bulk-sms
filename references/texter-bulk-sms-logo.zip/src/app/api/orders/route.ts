import { NextResponse } from "next/server";
import { desc } from "drizzle-orm";
import { db } from "@/db";
import { smsOrders } from "@/db/schema";

export const dynamic = "force-dynamic";

function parseRecipients(raw: string): string[] {
  return Array.from(
    new Set(
      raw
        .split(/[\n,;\s]+/)
        .map((n) => n.trim())
        .filter((n) => /^\+?\d{8,15}$/.test(n)),
    ),
  );
}

export async function GET() {
  const rows = await db.select().from(smsOrders).orderBy(desc(smsOrders.createdAt)).limit(50);
  return NextResponse.json(rows);
}

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const customerName = String(body.customerName ?? "").trim();
    const customerPhone = String(body.customerPhone ?? "").trim();
    const customerEmail = String(body.customerEmail ?? "").trim() || null;
    const senderId = String(body.senderId ?? "").trim();
    const message = String(body.message ?? "").trim();
    const recipients = parseRecipients(String(body.recipients ?? ""));
    const scheduledAt = new Date(String(body.scheduledAt ?? ""));

    if (!customerName || !customerPhone || !senderId || !message) {
      return NextResponse.json({ error: "Please fill in all required fields." }, { status: 400 });
    }
    if (recipients.length === 0) {
      return NextResponse.json({ error: "Add at least one valid recipient number." }, { status: 400 });
    }
    if (Number.isNaN(scheduledAt.getTime())) {
      return NextResponse.json({ error: "Please pick a valid schedule date & time." }, { status: 400 });
    }

    const [order] = await db
      .insert(smsOrders)
      .values({
        customerName,
        customerPhone,
        customerEmail,
        senderId,
        message,
        recipients: recipients.join("\n"),
        recipientCount: recipients.length,
        scheduledAt,
        status: scheduledAt.getTime() <= Date.now() ? "queued" : "scheduled",
      })
      .returning();

    return NextResponse.json(order, { status: 201 });
  } catch (err) {
    console.error(err);
    return NextResponse.json({ error: "Could not save the order." }, { status: 500 });
  }
}

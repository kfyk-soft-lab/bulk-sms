import Image from "next/image";
import { TexterLogo, TexterMark } from "@/components/TexterLogo";

export const metadata = {
  title: "Brand & Logo — Texter by Kfyklab",
};

const palette = [
  { name: "Deep Indigo", hex: "#3B1FA8", use: "Gradient start / primary dark" },
  { name: "Texter Violet", hex: "#5B2BD6", use: "Gradient mid / buttons" },
  { name: "Bright Violet", hex: "#7C3AED", use: "Gradient end / accents" },
  { name: "Clock Indigo", hex: "#4C25C2", use: "Clock badge face" },
  { name: "Ink Navy", hex: "#1A1660", use: "Wordmark text" },
  { name: "Slate Grey", hex: "#6B7280", use: "Tagline text" },
];

const downloads = [
  { label: "Logo mark (SVG)", href: "/brand/texter-mark.svg" },
  { label: "Horizontal logo (SVG)", href: "/brand/texter-logo-horizontal.svg" },
  { label: "Logo mark (PNG)", href: "/brand/texter-logo-mark.png" },
  { label: "Horizontal logo (PNG)", href: "/brand/texter-logo-horizontal.png" },
];

export default function BrandPage() {
  return (
    <main className="mx-auto max-w-6xl px-6 py-14">
      <p className="text-xs font-semibold uppercase tracking-[0.2em] text-indigo-600">Brand guidelines</p>
      <h1 className="mt-2 text-4xl font-extrabold tracking-tight text-slate-950">Texter logo & identity</h1>
      <p className="mt-3 max-w-2xl text-slate-600">
        The Texter mark combines a <strong>speech bubble</strong> (SMS), a bold <strong>T</strong> whose crossbar is built
        from stacked message lines (bulk sending), and a <strong>clock badge</strong> (scheduled delivery). It is a Kfyklab
        product, so the tagline “by Kfyklab” always accompanies the primary lockup.
      </p>

      {/* Primary lockups */}
      <section className="mt-12 grid gap-6 md:grid-cols-2">
        <div className="flex min-h-64 flex-col items-center justify-center rounded-3xl border border-slate-200 bg-white p-10 shadow-sm">
          <TexterLogo size={64} />
          <span className="mt-6 text-xs font-medium uppercase tracking-widest text-slate-400">Primary · on light</span>
        </div>
        <div className="flex min-h-64 flex-col items-center justify-center rounded-3xl bg-gradient-to-br from-[#2A1680] to-[#5B2BD6] p-10 shadow-sm">
          <TexterLogo size={64} tone="light" />
          <span className="mt-6 text-xs font-medium uppercase tracking-widest text-indigo-200">Primary · on dark</span>
        </div>
        <div className="flex min-h-56 flex-col items-center justify-center rounded-3xl border border-slate-200 bg-white p-10 shadow-sm">
          <div className="flex items-end gap-8">
            <TexterMark size={112} />
            <TexterMark size={64} />
            <TexterMark size={40} />
            <TexterMark size={24} />
          </div>
          <span className="mt-6 text-xs font-medium uppercase tracking-widest text-slate-400">Mark · scalable</span>
        </div>
        <div className="flex min-h-56 flex-col items-center justify-center rounded-3xl bg-slate-900 p-10 shadow-sm">
          <div className="flex items-end gap-8 text-white">
            <TexterMark size={112} variant="mono" />
            <TexterMark size={64} variant="mono" />
            <TexterMark size={40} variant="mono" />
          </div>
          <span className="mt-6 text-xs font-medium uppercase tracking-widest text-slate-400">Mark · monochrome</span>
        </div>
      </section>

      {/* AI rendered versions */}
      <section className="mt-14">
        <h2 className="text-2xl font-bold text-slate-950">Rendered artwork</h2>
        <p className="mt-1 text-sm text-slate-600">High-resolution raster versions for presentations and social media.</p>
        <div className="mt-6 grid gap-6 md:grid-cols-[1fr_2fr]">
          <div className="overflow-hidden rounded-3xl border border-slate-200 bg-white shadow-sm">
            <Image src="/brand/texter-logo-mark.png" alt="Texter logo mark" width={800} height={800} className="h-auto w-full" />
          </div>
          <div className="flex items-center overflow-hidden rounded-3xl border border-slate-200 bg-white shadow-sm">
            <Image
              src="/brand/texter-logo-horizontal.png"
              alt="Texter horizontal logo with tagline by Kfyklab"
              width={1600}
              height={540}
              className="h-auto w-full"
            />
          </div>
        </div>
      </section>

      {/* Palette */}
      <section className="mt-14">
        <h2 className="text-2xl font-bold text-slate-950">Colour palette</h2>
        <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {palette.map((c) => (
            <div key={c.hex} className="flex items-center gap-4 rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
              <span className="h-14 w-14 shrink-0 rounded-xl ring-1 ring-black/5" style={{ background: c.hex }} />
              <div>
                <p className="font-semibold text-slate-900">{c.name}</p>
                <p className="font-mono text-sm text-slate-500">{c.hex}</p>
                <p className="text-xs text-slate-500">{c.use}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Typography & usage */}
      <section className="mt-14 grid gap-6 md:grid-cols-2">
        <div className="rounded-3xl border border-slate-200 bg-white p-8 shadow-sm">
          <h2 className="text-xl font-bold text-slate-950">Typography</h2>
          <p className="mt-4 text-5xl font-extrabold tracking-tight text-[#1A1660]">Texter</p>
          <p className="mt-2 text-sm font-semibold uppercase tracking-[0.32em] text-slate-500">by Kfyklab</p>
          <p className="mt-4 text-sm text-slate-600">
            Wordmark: geometric sans-serif, weight 800, tight tracking (−2%). Tagline: weight 600, uppercase, wide
            tracking (+32%).
          </p>
        </div>
        <div className="rounded-3xl border border-slate-200 bg-white p-8 shadow-sm">
          <h2 className="text-xl font-bold text-slate-950">Usage rules</h2>
          <ul className="mt-4 space-y-2 text-sm text-slate-600">
            <li>• Keep clear space equal to the clock badge diameter around the logo.</li>
            <li>• Minimum size: 24px for the mark, 96px wide for the horizontal lockup.</li>
            <li>• Use the monochrome version on photos or busy backgrounds.</li>
            <li>• Do not rotate, stretch, recolour, or remove the clock badge.</li>
            <li>• Always pair with “by Kfyklab” in marketing materials.</li>
          </ul>
        </div>
      </section>

      {/* Downloads */}
      <section className="mt-14 rounded-3xl bg-gradient-to-r from-[#3B1FA8] to-[#7C3AED] p-8 text-white shadow-lg">
        <h2 className="text-2xl font-bold">Download assets</h2>
        <div className="mt-5 flex flex-wrap gap-3">
          {downloads.map((d) => (
            <a
              key={d.href}
              href={d.href}
              download
              className="rounded-full bg-white/15 px-5 py-2.5 text-sm font-semibold ring-1 ring-white/30 transition hover:bg-white/25"
            >
              ↓ {d.label}
            </a>
          ))}
        </div>
      </section>
    </main>
  );
}

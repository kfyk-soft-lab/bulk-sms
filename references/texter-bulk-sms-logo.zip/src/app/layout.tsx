import type { Metadata } from "next";
import type { ReactNode } from "react";
import Link from "next/link";
import { TexterLogo } from "@/components/TexterLogo";
import "./globals.css";

export const metadata: Metadata = {
  title: "Texter by Kfyklab — Bulk SMS Scheduling",
  description:
    "Texter collects bulk SMS orders online and delivers every message exactly on your schedule. A Kfyklab product.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body className="min-h-screen bg-slate-50 text-slate-900 antialiased">
        <header className="sticky top-0 z-20 border-b border-slate-200/70 bg-white/80 backdrop-blur">
          <div className="mx-auto flex max-w-6xl items-center justify-between px-6 py-3">
            <Link href="/" aria-label="Texter home">
              <TexterLogo size={36} />
            </Link>
            <nav className="flex items-center gap-6 text-sm font-medium text-slate-600">
              <Link href="/#order" className="hover:text-indigo-700">
                Place Order
              </Link>
              <Link href="/orders" className="hover:text-indigo-700">
                Orders
              </Link>
              <Link
                href="/brand"
                className="rounded-full bg-indigo-600 px-4 py-2 text-white shadow-sm transition hover:bg-indigo-700"
              >
                Brand & Logo
              </Link>
            </nav>
          </div>
        </header>
        {children}
        <footer className="mt-20 border-t border-slate-200 bg-white">
          <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-4 px-6 py-8 text-sm text-slate-500 sm:flex-row">
            <TexterLogo size={28} />
            <p>© {new Date().getFullYear()} Kfyklab. Texter — Bulk SMS, right on schedule.</p>
          </div>
        </footer>
      </body>
    </html>
  );
}

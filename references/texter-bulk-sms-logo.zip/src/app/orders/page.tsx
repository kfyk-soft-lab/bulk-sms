import Link from "next/link";
import { desc } from "drizzle-orm";
import { db } from "@/db";
import { smsOrders } from "@/db/schema";

export const dynamic = "force-dynamic";

const statusStyle: Record<string, string> = {
  scheduled: "bg-indigo-50 text-indigo-700 ring-indigo-200",
  queued: "bg-amber-50 text-amber-700 ring-amber-200",
  sent: "bg-emerald-50 text-emerald-700 ring-emerald-200",
  failed: "bg-rose-50 text-rose-700 ring-rose-200",
};

export default async function OrdersPage() {
  const orders = await db.select().from(smsOrders).orderBy(desc(smsOrders.createdAt)).limit(100);

  return (
    <main className="mx-auto max-w-6xl px-6 py-14">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.2em] text-indigo-600">Dashboard</p>
          <h1 className="mt-2 text-4xl font-extrabold tracking-tight text-slate-950">Scheduled SMS orders</h1>
        </div>
        <Link
          href="/#order"
          className="rounded-full bg-indigo-600 px-5 py-2.5 text-sm font-semibold text-white shadow-sm hover:bg-indigo-700"
        >
          + New order
        </Link>
      </div>

      {orders.length === 0 ? (
        <div className="mt-10 rounded-3xl border border-dashed border-slate-300 bg-white p-16 text-center text-slate-500">
          No orders yet. Place your first bulk SMS order from the home page.
        </div>
      ) : (
        <div className="mt-8 overflow-hidden rounded-3xl border border-slate-200 bg-white shadow-sm">
          <table className="w-full text-left text-sm">
            <thead className="bg-slate-50 text-xs uppercase tracking-wider text-slate-500">
              <tr>
                <th className="px-5 py-3">#</th>
                <th className="px-5 py-3">Customer</th>
                <th className="px-5 py-3">Sender ID</th>
                <th className="px-5 py-3">Message</th>
                <th className="px-5 py-3 text-right">Recipients</th>
                <th className="px-5 py-3">Scheduled for</th>
                <th className="px-5 py-3">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {orders.map((o) => (
                <tr key={o.id} className="align-top hover:bg-slate-50/60">
                  <td className="px-5 py-4 font-mono text-slate-400">{o.id}</td>
                  <td className="px-5 py-4">
                    <div className="font-semibold text-slate-900">{o.customerName}</div>
                    <div className="text-xs text-slate-500">{o.customerPhone}</div>
                  </td>
                  <td className="px-5 py-4 font-mono text-slate-700">{o.senderId}</td>
                  <td className="max-w-xs px-5 py-4 text-slate-600">
                    <span className="line-clamp-2">{o.message}</span>
                  </td>
                  <td className="px-5 py-4 text-right font-semibold text-slate-900">{o.recipientCount}</td>
                  <td className="px-5 py-4 text-slate-700">
                    {o.scheduledAt.toLocaleString("en-GB", { dateStyle: "medium", timeStyle: "short" })}
                  </td>
                  <td className="px-5 py-4">
                    <span
                      className={`rounded-full px-2.5 py-1 text-xs font-semibold capitalize ring-1 ${
                        statusStyle[o.status] ?? "bg-slate-50 text-slate-600 ring-slate-200"
                      }`}
                    >
                      {o.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </main>
  );
}

import Link from "next/link";
import { count, sum } from "drizzle-orm";
import { db } from "@/db";
import { smsOrders } from "@/db/schema";
import { TexterMark } from "@/components/TexterLogo";
import { OrderForm } from "@/components/OrderForm";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  const [stats] = await db
    .select({ orders: count(), recipients: sum(smsOrders.recipientCount) })
    .from(smsOrders);

  return (
    <main>
      {/* Hero */}
      <section className="relative overflow-hidden bg-gradient-to-br from-[#2A1680] via-[#4C25C2] to-[#7C3AED] text-white">
        <div className="pointer-events-none absolute -right-24 -top-24 h-96 w-96 rounded-full bg-white/10 blur-3xl" />
        <div className="pointer-events-none absolute -bottom-32 left-10 h-80 w-80 rounded-full bg-fuchsia-400/20 blur-3xl" />
        <div className="relative mx-auto grid max-w-6xl items-center gap-12 px-6 py-20 md:grid-cols-[1.2fr_1fr]">
          <div>
            <p className="inline-flex items-center gap-2 rounded-full border border-white/20 bg-white/10 px-3 py-1 text-xs font-semibold uppercase tracking-[0.2em] text-indigo-100">
              A Kfyklab product
            </p>
            <h1 className="mt-6 text-[clamp(2.4rem,6vw,4.25rem)] font-extrabold leading-[1.02] tracking-tight">
              Bulk SMS,
              <br />
              <span className="text-indigo-200">right on schedule.</span>
            </h1>
            <p className="mt-6 max-w-xl text-lg text-indigo-100/90">
              Texter collects your bulk SMS orders online, generates the delivery schedule, and sends every
              message exactly when you want it to arrive.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Link
                href="#order"
                className="rounded-full bg-white px-6 py-3 text-sm font-semibold text-indigo-800 shadow-xl transition hover:bg-indigo-50"
              >
                Place an order
              </Link>
              <Link
                href="/brand"
                className="rounded-full border border-white/30 px-6 py-3 text-sm font-semibold text-white transition hover:bg-white/10"
              >
                View brand assets
              </Link>
            </div>
            <dl className="mt-10 flex gap-10 text-sm text-indigo-100">
              <div>
                <dt className="text-indigo-200/80">Orders collected</dt>
                <dd className="text-3xl font-bold text-white">{stats.orders}</dd>
              </div>
              <div>
                <dt className="text-indigo-200/80">Recipients scheduled</dt>
                <dd className="text-3xl font-bold text-white">{stats.recipients ?? 0}</dd>
              </div>
            </dl>
          </div>
          <div className="flex justify-center">
            <div className="rounded-[2.5rem] bg-white/10 p-8 shadow-2xl ring-1 ring-white/20 backdrop-blur">
              <TexterMark size={220} />
            </div>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="mx-auto grid max-w-6xl gap-6 px-6 py-16 md:grid-cols-3">
        {[
          { t: "Collect orders online", d: "Customers submit sender ID, message and recipient list from any device." },
          { t: "Auto-generated schedule", d: "Pick a date & time — Texter queues the campaign and tracks its status." },
          { t: "Reliable delivery", d: "Messages are dispatched exactly on time with per-recipient tracking." },
        ].map((f) => (
          <div key={f.t} className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm">
            <div className="mb-4 inline-flex h-10 w-10 items-center justify-center rounded-xl bg-indigo-50 text-indigo-700">
              <TexterMark size={24} />
            </div>
            <h3 className="text-lg font-semibold text-slate-900">{f.t}</h3>
            <p className="mt-2 text-sm text-slate-600">{f.d}</p>
          </div>
        ))}
      </section>

      {/* Order form */}
      <section id="order" className="mx-auto max-w-4xl scroll-mt-24 px-6 pb-8">
        <div className="rounded-[2rem] border border-slate-200 bg-white p-8 shadow-[0_24px_60px_rgba(16,24,40,0.08)] sm:p-10">
          <p className="text-xs font-semibold uppercase tracking-[0.2em] text-indigo-600">New campaign</p>
          <h2 className="mt-2 text-3xl font-bold tracking-tight text-slate-950">Place a Bulk SMS order</h2>
          <p className="mt-2 text-sm text-slate-600">
            Fill in the details below. We&apos;ll schedule your SMS and send it at the chosen time.
          </p>
          <div className="mt-8">
            <OrderForm />
          </div>
        </div>
      </section>
    </main>
  );
}

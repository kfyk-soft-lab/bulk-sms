"use client";

import { useMemo, useState } from "react";
import { useRouter } from "next/navigation";

const SMS_SEGMENT = 160;

function defaultSchedule() {
  const d = new Date(Date.now() + 60 * 60 * 1000);
  d.setSeconds(0, 0);
  const pad = (n: number) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

export function OrderForm() {
  const router = useRouter();
  const [form, setForm] = useState({
    customerName: "",
    customerPhone: "",
    customerEmail: "",
    senderId: "",
    message: "",
    recipients: "",
    scheduledAt: defaultSchedule(),
  });
  const [status, setStatus] = useState<"idle" | "saving" | "done" | "error">("idle");
  const [error, setError] = useState<string | null>(null);

  const recipientCount = useMemo(
    () =>
      new Set(
        form.recipients
          .split(/[\n,;\s]+/)
          .map((n) => n.trim())
          .filter((n) => /^\+?\d{8,15}$/.test(n)),
      ).size,
    [form.recipients],
  );
  const segments = Math.max(1, Math.ceil(form.message.length / SMS_SEGMENT));

  const update = (k: keyof typeof form) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) =>
    setForm((f) => ({ ...f, [k]: e.target.value }));

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setStatus("saving");
    setError(null);
    const res = await fetch("/api/orders", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ...form, scheduledAt: new Date(form.scheduledAt).toISOString() }),
    });
    if (!res.ok) {
      const data = await res.json().catch(() => ({}));
      setError(data.error ?? "Something went wrong.");
      setStatus("error");
      return;
    }
    setStatus("done");
    router.refresh();
    setTimeout(() => router.push("/orders"), 900);
  }

  const input =
    "w-full rounded-xl border border-slate-200 bg-white px-4 py-2.5 text-sm text-slate-900 outline-none transition focus:border-indigo-500 focus:ring-4 focus:ring-indigo-100";

  return (
    <form onSubmit={submit} className="grid gap-5">
      <div className="grid gap-5 sm:grid-cols-2">
        <label className="grid gap-1.5 text-sm font-medium text-slate-700">
          Your name *
          <input required className={input} value={form.customerName} onChange={update("customerName")} />
        </label>
        <label className="grid gap-1.5 text-sm font-medium text-slate-700">
          Contact phone *
          <input required className={input} placeholder="01XXXXXXXXX" value={form.customerPhone} onChange={update("customerPhone")} />
        </label>
        <label className="grid gap-1.5 text-sm font-medium text-slate-700">
          Email
          <input type="email" className={input} value={form.customerEmail} onChange={update("customerEmail")} />
        </label>
        <label className="grid gap-1.5 text-sm font-medium text-slate-700">
          Sender ID / Masking name *
          <input required maxLength={11} className={input} placeholder="e.g. KFYKLAB" value={form.senderId} onChange={update("senderId")} />
        </label>
      </div>

      <label className="grid gap-1.5 text-sm font-medium text-slate-700">
        <span className="flex items-center justify-between">
          Message *
          <span className="text-xs font-normal text-slate-500">
            {form.message.length} chars · {segments} segment{segments > 1 ? "s" : ""}
          </span>
        </span>
        <textarea required rows={4} className={input} value={form.message} onChange={update("message")} />
      </label>

      <label className="grid gap-1.5 text-sm font-medium text-slate-700">
        <span className="flex items-center justify-between">
          Recipient numbers *
          <span className="text-xs font-normal text-slate-500">{recipientCount} valid number{recipientCount === 1 ? "" : "s"}</span>
        </span>
        <textarea
          required
          rows={5}
          className={`${input} font-mono`}
          placeholder={"One number per line or comma separated\n8801711000000\n8801911000000"}
          value={form.recipients}
          onChange={update("recipients")}
        />
      </label>

      <label className="grid gap-1.5 text-sm font-medium text-slate-700 sm:max-w-xs">
        Schedule send time *
        <input type="datetime-local" required className={input} value={form.scheduledAt} onChange={update("scheduledAt")} />
      </label>

      <div className="flex flex-wrap items-center justify-between gap-4 rounded-2xl bg-indigo-50 px-5 py-4">
        <div className="text-sm text-indigo-900">
          <span className="font-semibold">{recipientCount * segments}</span> SMS units will be sent to{" "}
          <span className="font-semibold">{recipientCount}</span> recipients.
        </div>
        <button
          type="submit"
          disabled={status === "saving" || status === "done"}
          className="rounded-full bg-gradient-to-r from-[#3B1FA8] to-[#7C3AED] px-6 py-2.5 text-sm font-semibold text-white shadow-lg shadow-indigo-200 transition hover:opacity-90 disabled:opacity-60"
        >
          {status === "saving" ? "Scheduling…" : status === "done" ? "Scheduled ✓" : "Schedule Bulk SMS"}
        </button>
      </div>

      {error && <p className="text-sm font-medium text-rose-600">{error}</p>}
    </form>
  );
}

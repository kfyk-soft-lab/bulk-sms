import type { SVGProps } from "react";

type MarkProps = SVGProps<SVGSVGElement> & {
  size?: number;
  /** "color" = gradient bubble, "mono" = single colour (currentColor) */
  variant?: "color" | "mono";
};

/**
 * Texter logo mark – speech bubble with a bold "T" whose crossbar is made of
 * stacked message lines (bulk send) and a clock badge (scheduling).
 */
export function TexterMark({ size = 48, variant = "color", ...rest }: MarkProps) {
  const id = variant === "color" ? "texter-grad" : undefined;
  const fill = variant === "color" ? `url(#${id})` : "currentColor";
  const fg = variant === "color" ? "#ffffff" : "#ffffff";

  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 120 120"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      role="img"
      aria-label="Texter logo"
      {...rest}
    >
      {variant === "color" && (
        <defs>
          <linearGradient id={id} x1="0" y1="0" x2="120" y2="120" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#3B1FA8" />
            <stop offset="55%" stopColor="#5B2BD6" />
            <stop offset="100%" stopColor="#7C3AED" />
          </linearGradient>
        </defs>
      )}

      {/* Speech bubble */}
      <path
        d="M30 10h60c11 0 20 9 20 20v48c0 11-9 20-20 20H46L22 112c-2 1.6-4.8 0.2-4.8-2.3V96C13 93 10 86 10 78V30c0-11 9-20 20-20Z"
        fill={fill}
      />

      {/* T – stacked lines as crossbar */}
      <rect x="32" y="34" width="56" height="9" rx="3" fill={fg} />
      <rect x="40" y="47" width="40" height="5" rx="2.5" fill={fg} opacity="0.75" />
      <rect x="47" y="56" width="26" height="4" rx="2" fill={fg} opacity="0.5" />
      <rect x="54" y="43" width="12" height="40" rx="3" fill={fg} />

      {/* Clock badge */}
      <circle cx="96" cy="24" r="17" fill={variant === "color" ? "#ffffff" : "currentColor"} />
      <circle cx="96" cy="24" r="12.5" fill={variant === "color" ? "#4C25C2" : "#ffffff"} />
      <path
        d="M96 16v8.5l5.5 3.5"
        stroke={variant === "color" ? "#ffffff" : "currentColor"}
        strokeWidth="3"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}

type LockupProps = {
  /** Height of the mark in px */
  size?: number;
  tone?: "dark" | "light";
  showTagline?: boolean;
  className?: string;
};

/** Horizontal lockup: mark + "Texter" wordmark + "BY KFYKLAB" tagline */
export function TexterLogo({ size = 44, tone = "dark", showTagline = true, className }: LockupProps) {
  const word = tone === "dark" ? "text-[#1A1660]" : "text-white";
  const tag = tone === "dark" ? "text-slate-500" : "text-indigo-200";

  return (
    <div className={`inline-flex items-center gap-3 ${className ?? ""}`}>
      <TexterMark size={size} />
      <div className="flex flex-col leading-none">
        <span
          className={`${word} font-extrabold tracking-tight`}
          style={{ fontSize: size * 0.72, lineHeight: 1 }}
        >
          Texter
        </span>
        {showTagline && (
          <span
            className={`${tag} mt-1 font-semibold uppercase`}
            style={{ fontSize: Math.max(9, size * 0.22), letterSpacing: "0.32em" }}
          >
            by Kfyklab
          </span>
        )}
      </div>
    </div>
  );
}

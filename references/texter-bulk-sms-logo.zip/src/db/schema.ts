import { integer, pgTable, serial, text, timestamp, varchar } from "drizzle-orm/pg-core";

export const smsOrders = pgTable("sms_orders", {
  id: serial("id").primaryKey(),
  customerName: varchar("customer_name", { length: 120 }).notNull(),
  customerPhone: varchar("customer_phone", { length: 32 }).notNull(),
  customerEmail: varchar("customer_email", { length: 160 }),
  senderId: varchar("sender_id", { length: 32 }).notNull(),
  message: text("message").notNull(),
  recipients: text("recipients").notNull(), // newline / comma separated numbers
  recipientCount: integer("recipient_count").notNull(),
  scheduledAt: timestamp("scheduled_at", { withTimezone: true }).notNull(),
  status: varchar("status", { length: 24 }).notNull().default("scheduled"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export type SmsOrder = typeof smsOrders.$inferSelect;
export type NewSmsOrder = typeof smsOrders.$inferInsert;

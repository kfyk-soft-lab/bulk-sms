import { redirect } from "next/navigation";
import type { ReactNode } from "react";
import { PortalFrame } from "@/components/chrome";
import { getCurrentUser } from "@/lib/auth";
import { getLang } from "@/lib/lang";

export const dynamic = "force-dynamic";

export default async function AdminLayout({ children }: { children: ReactNode }) {
  const user = await getCurrentUser();
  if (!user) redirect("/login?next=/admin");
  if (user.role !== "admin") redirect("/portal");
  const lang = await getLang();
  return (
    <PortalFrame user={user} lang={lang}>
      {children}
    </PortalFrame>
  );
}

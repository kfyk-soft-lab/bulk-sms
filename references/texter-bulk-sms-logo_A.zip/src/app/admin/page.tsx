import Link from "next/link";
import { desc, eq } from "drizzle-orm";
import { AdminActions } from "@/components/desk-widgets";
import { db } from "@/db";
import { campaigns, senderIds, users } from "@/db/schema";
import { formatDhaka, formatNumber, orderCode } from "@/lib/format";
import { pick, statusLabel } from "@/lib/i18n";
import { getLang } from "@/lib/lang";

export const dynamic = "force-dynamic";

export default async function AdminPage() {
  const lang = await getLang();
  const people = await db.select().from(users).orderBy(desc(users.createdAt)).limit(30);
  const senders = await db.select({
    id: senderIds.id,
    label: senderIds.label,
    status: senderIds.status,
    email: users.email,
    createdAt: senderIds.createdAt,
  }).from(senderIds).innerJoin(users, eq(senderIds.userId, users.id)).orderBy(desc(senderIds.createdAt)).limit(40);
  const orders = await db.select({
    id: campaigns.id,
    name: campaigns.name,
    status: campaigns.status,
    total: campaigns.totalRecipients,
    email: users.email,
    createdAt: campaigns.createdAt,
  }).from(campaigns).innerJoin(users, eq(campaigns.userId, users.id)).orderBy(desc(campaigns.createdAt)).limit(20);

  return (
    <>
      <div className="main-head">
        <div>
          <p className="kicker">Kfyklab</p>
          <h1>{pick(lang, "Operator desk", "অপারেটর ডেস্ক")}</h1>
        </div>
      </div>
      <section className="panel">
        <h2>{pick(lang, "Sender requests", "সেন্ডার অনুরোধ")}</h2>
        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                <th>ID</th>
                <th>{pick(lang, "Account", "অ্যাকাউন্ট")}</th>
                <th>{pick(lang, "Status", "অবস্থা")}</th>
                <th>{pick(lang, "Action", "কাজ")}</th>
              </tr>
            </thead>
            <tbody>
              {senders.map((row) => (
                <tr key={row.id}>
                  <td className="num">{row.label}</td>
                  <td>{row.email}<div className="fine">{formatDhaka(row.createdAt, lang)}</div></td>
                  <td><span className={`pill pill-${row.status}`}>{statusLabel(lang, row.status)}</span></td>
                  <td><AdminActions lang={lang} senderId={row.id} /></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
      <section className="panel" style={{ marginTop: 18 }}>
        <h2>{pick(lang, "Accounts", "অ্যাকাউন্ট")}</h2>
        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                <th>{pick(lang, "Name", "নাম")}</th>
                <th>{pick(lang, "Credits", "ক্রেডিট")}</th>
                <th>{pick(lang, "Adjust", "সমন্বয়")}</th>
              </tr>
            </thead>
            <tbody>
              {people.map((person) => (
                <tr key={person.id}>
                  <td>{person.name}<div className="fine">{person.email} · {person.role}</div></td>
                  <td className="num">{formatNumber(person.credits, lang)}</td>
                  <td><AdminActions lang={lang} userId={person.id} /></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
      <section className="panel" style={{ marginTop: 18 }}>
        <h2>{pick(lang, "Recent orders", "সাম্প্রতিক অর্ডার")}</h2>
        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                <th>{pick(lang, "Order", "অর্ডার")}</th>
                <th>{pick(lang, "Account", "অ্যাকাউন্ট")}</th>
                <th>{pick(lang, "Status", "অবস্থা")}</th>
              </tr>
            </thead>
            <tbody>
              {orders.map((order) => (
                <tr key={order.id}>
                  <td><Link href={`/portal/campaigns/${order.id}`}>{order.name}</Link><div className="fine num">{orderCode(order.id)} · {formatNumber(order.total, lang)}</div></td>
                  <td>{order.email}</td>
                  <td><span className={`pill pill-${order.status}`}>{statusLabel(lang, order.status)}</span></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </>
  );
}

import { randomUUID } from "crypto";
import { eq, sql } from "drizzle-orm";
import { NextResponse } from "next/server";
import { db } from "@/db";
import { ledger, users } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "auth" }, { status: 401 });
  if (user.role !== "admin") return NextResponse.json({ error: "forbidden" }, { status: 403 });
  const body = (await request.json().catch(() => null)) as { userId?: string; amount?: number; note?: string } | null;
  const amount = Math.trunc(Number(body?.amount));
  if (!body?.userId || !Number.isFinite(amount) || amount === 0 || Math.abs(amount) > 1000000) {
    return NextResponse.json({ error: "bad_action" }, { status: 400 });
  }
  const [updated] = await db
    .update(users)
    .set({ credits: sql`greatest(0, ${users.credits} + ${amount})` })
    .where(eq(users.id, body.userId))
    .returning({ credits: users.credits });
  if (!updated) return NextResponse.json({ error: "not_found" }, { status: 404 });
  await db.insert(ledger).values({
    id: randomUUID(),
    userId: body.userId,
    type: amount > 0 ? "grant" : "debit",
    amount,
    balanceAfter: updated.credits,
    note: body.note?.slice(0, 140) || "Operator adjustment",
  });
  return NextResponse.json({ ok: true, credits: updated.credits });
}

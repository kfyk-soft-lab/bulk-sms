import { eq } from "drizzle-orm";
import { NextResponse } from "next/server";
import { db } from "@/db";
import { senderIds } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "auth" }, { status: 401 });
  if (user.role !== "admin") return NextResponse.json({ error: "forbidden" }, { status: 403 });
  const body = (await request.json().catch(() => null)) as { id?: string; status?: string } | null;
  const status = body?.status;
  if (!body?.id || !status || !["approved", "rejected", "pending"].includes(status)) {
    return NextResponse.json({ error: "bad_action" }, { status: 400 });
  }
  await db.update(senderIds).set({ status }).where(eq(senderIds.id, body.id));
  return NextResponse.json({ ok: true });
}

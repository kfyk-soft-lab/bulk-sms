import { randomUUID } from "crypto";
import { NextResponse } from "next/server";
import { db } from "@/db";
import { ledger, senderIds, users } from "@/db/schema";
import { createSession, SESSION_COOKIE, SESSION_MAX_AGE } from "@/lib/auth";
import { ensureSeed } from "@/lib/seed";
import { hashPassword } from "@/lib/password";
import { normalizePhone } from "@/lib/sms";

export const dynamic = "force-dynamic";

const EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const STARTER = 400;

function uniqueError(error: unknown) {
  const text = error instanceof Error ? error.message : String(error);
  return text.toLowerCase().includes("duplicate") || text.toLowerCase().includes("unique");
}

export async function POST(request: Request) {
  await ensureSeed();
  const body = (await request.json().catch(() => null)) as {
    name?: string;
    email?: string;
    password?: string;
    company?: string;
    phone?: string;
  } | null;
  const name = body?.name?.trim() ?? "";
  const email = body?.email?.trim().toLowerCase() ?? "";
  const password = body?.password ?? "";
  const company = body?.company?.trim().slice(0, 80) || null;
  const phone = body?.phone?.trim() ? normalizePhone(body.phone) ?? body.phone.trim().slice(0, 20) : null;
  if (name.length < 2) return NextResponse.json({ error: "bad_name" }, { status: 400 });
  if (!EMAIL.test(email)) return NextResponse.json({ error: "bad_email" }, { status: 400 });
  if (password.length < 8) return NextResponse.json({ error: "bad_password" }, { status: 400 });

  const id = randomUUID();
  try {
    await db.insert(users).values({
      id,
      name,
      email,
      passwordHash: await hashPassword(password),
      company,
      phone,
      role: "customer",
      credits: STARTER,
    });
  } catch (error) {
    if (uniqueError(error)) return NextResponse.json({ error: "email_taken" }, { status: 409 });
    throw error;
  }
  await db.insert(ledger).values({
    id: randomUUID(),
    userId: id,
    type: "grant",
    amount: STARTER,
    balanceAfter: STARTER,
    note: "Signup lab credits",
  });
  await db.insert(senderIds).values({
    id: randomUUID(),
    userId: id,
    label: "TEXTER",
    status: "approved",
  });
  const token = await createSession(id);
  const response = NextResponse.json({ ok: true });
  response.cookies.set(SESSION_COOKIE, token, {
    httpOnly: true,
    sameSite: "lax",
    path: "/",
    maxAge: SESSION_MAX_AGE,
  });
  return response;
}

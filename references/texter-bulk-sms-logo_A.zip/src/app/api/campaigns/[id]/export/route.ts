import { eq } from "drizzle-orm";
import { db } from "@/db";
import { campaigns, recipients } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";
import { orderCode } from "@/lib/format";

export const dynamic = "force-dynamic";

function cell(value: string) {
  if (/[",\n]/.test(value)) return `"${value.replaceAll('"', '""')}"`;
  return value;
}

export async function GET(_request: Request, context: { params: Promise<{ id: string }> }) {
  const user = await getCurrentUser();
  if (!user) return new Response("auth", { status: 401 });
  const { id } = await context.params;
  const [order] = await db.select().from(campaigns).where(eq(campaigns.id, id)).limit(1);
  if (!order || (order.userId !== user.id && user.role !== "admin")) return new Response("not found", { status: 404 });
  const rows = await db.select().from(recipients).where(eq(recipients.campaignId, id));
  const lines = [
    "phone,name,status,scheduled_at,sent_at,provider_ref,error",
    ...rows.map((row) =>
      [
        row.phone,
        row.name ?? "",
        row.status,
        row.scheduledAt.toISOString(),
        row.sentAt?.toISOString() ?? "",
        row.providerRef ?? "",
        row.error ?? "",
      ]
        .map(cell)
        .join(","),
    ),
  ];
  return new Response(lines.join("\n"), {
    headers: {
      "Content-Type": "text/csv; charset=utf-8",
      "Content-Disposition": `attachment; filename="${orderCode(id)}.csv"`,
    },
  });
}

import { randomUUID } from "crypto";
import { and, eq, sql } from "drizzle-orm";
import { NextResponse } from "next/server";
import { db } from "@/db";
import { campaigns, ledger, recipients, users } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function POST(request: Request, context: { params: Promise<{ id: string }> }) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "auth" }, { status: 401 });
  const { id } = await context.params;
  const body = (await request.json().catch(() => null)) as { action?: string } | null;
  const action = body?.action;
  const [order] = await db.select().from(campaigns).where(eq(campaigns.id, id)).limit(1);
  if (!order || (order.userId !== user.id && user.role !== "admin")) {
    return NextResponse.json({ error: "not_found" }, { status: 404 });
  }

  if (action === "pause") {
    if (order.status !== "scheduled" && order.status !== "sending") {
      return NextResponse.json({ error: "bad_action" }, { status: 400 });
    }
    await db.update(campaigns).set({ status: "paused" }).where(eq(campaigns.id, id));
    return NextResponse.json({ ok: true });
  }

  if (action === "resume") {
    if (order.status !== "paused") return NextResponse.json({ error: "bad_action" }, { status: 400 });
    const [queued] = await db
      .select({ n: sql<number>`count(*)::int` })
      .from(recipients)
      .where(and(eq(recipients.campaignId, id), eq(recipients.status, "queued")));
    await db
      .update(campaigns)
      .set({ status: Number(queued?.n ?? 0) === 0 ? "completed" : order.sentCount > 0 ? "sending" : "scheduled" })
      .where(eq(campaigns.id, id));
    return NextResponse.json({ ok: true });
  }

  if (action === "cancel") {
    if (order.status === "completed" || order.status === "cancelled") {
      return NextResponse.json({ error: "bad_action" }, { status: 400 });
    }
    await db.transaction(async (tx) => {
      const [queued] = await tx
        .select({ n: sql<number>`count(*)::int` })
        .from(recipients)
        .where(and(eq(recipients.campaignId, id), eq(recipients.status, "queued")));
      const refund = Number(queued?.n ?? 0) * order.segments;
      await tx
        .update(recipients)
        .set({ status: "cancelled" })
        .where(and(eq(recipients.campaignId, id), eq(recipients.status, "queued")));
      await tx.update(campaigns).set({ status: "cancelled" }).where(eq(campaigns.id, id));
      if (refund > 0) {
        const [updated] = await tx
          .update(users)
          .set({ credits: sql`${users.credits} + ${refund}` })
          .where(eq(users.id, order.userId))
          .returning({ credits: users.credits });
        await tx.insert(ledger).values({
          id: randomUUID(),
          userId: order.userId,
          type: "refund",
          amount: refund,
          balanceAfter: updated.credits,
          note: `Refund unsent · ${order.name}`,
          campaignId: id,
        });
      }
    });
    return NextResponse.json({ ok: true });
  }

  return NextResponse.json({ error: "bad_action" }, { status: 400 });
}

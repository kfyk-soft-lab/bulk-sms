import { randomUUID } from "crypto";
import { and, eq, gte, sql } from "drizzle-orm";
import { NextResponse } from "next/server";
import { db } from "@/db";
import { campaigns, ledger, recipients, scheduleSlots, senderIds, users } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";
import { processDue } from "@/lib/dispatch";
import { analyzeMessage, parseAudience, planSchedule, scheduleSummary, type ScheduleMode, type WeekendMode } from "@/lib/sms";

export const dynamic = "force-dynamic";

function asMode(value: unknown): ScheduleMode {
  return value === "instant" || value === "fixed" || value === "generated" ? value : "generated";
}

export async function POST(request: Request) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "auth" }, { status: 401 });
  const body = (await request.json().catch(() => null)) as Record<string, unknown> | null;
  if (!body) return NextResponse.json({ error: "bad_json" }, { status: 400 });

  const name = typeof body.name === "string" ? body.name.trim().slice(0, 80) : "";
  const senderLabel = typeof body.senderId === "string" ? body.senderId.trim().toUpperCase() : "";
  const message = typeof body.message === "string" ? body.message.trim().slice(0, 1000) : "";
  const audience = typeof body.audience === "string" ? body.audience.slice(0, 200000) : "";
  const mode = asMode(body.mode);
  const perMinute = Math.max(1, Math.min(300, Number(body.perMinute) || 40));
  const skipWeekend = Boolean(body.skipWeekend);
  const weekendMode: WeekendMode = body.weekendMode === "west" ? "west" : "bd";
  const startLocal = typeof body.startLocal === "string" ? body.startLocal : "";
  const endLocal = typeof body.endLocal === "string" ? body.endLocal : "";
  const windowStart = typeof body.windowStart === "string" ? body.windowStart : "09:00";
  const windowEnd = typeof body.windowEnd === "string" ? body.windowEnd : "20:00";

  if (!name) return NextResponse.json({ error: "name_required" }, { status: 400 });
  if (!message) return NextResponse.json({ error: "message_required" }, { status: 400 });
  const analysis = analyzeMessage(message);
  if (analysis.segments < 1) return NextResponse.json({ error: "message_required" }, { status: 400 });
  if (analysis.segments > 6) return NextResponse.json({ error: "message_too_long" }, { status: 400 });

  const [sender] = await db
    .select()
    .from(senderIds)
    .where(and(eq(senderIds.userId, user.id), eq(senderIds.label, senderLabel), eq(senderIds.status, "approved")))
    .limit(1);
  if (!sender) return NextResponse.json({ error: "sender_not_approved" }, { status: 400 });

  const parsed = parseAudience(audience);
  if (!parsed.valid.length) return NextResponse.json({ error: "no_recipients" }, { status: 400 });
  if (parsed.valid.length > 2000) return NextResponse.json({ error: "too_many_recipients" }, { status: 400 });

  const plan = planSchedule({
    mode,
    count: parsed.valid.length,
    perMinute,
    startLocal,
    endLocal,
    windowStart,
    windowEnd,
    skipWeekend,
    weekendMode,
  });
  if (!plan.ok) return NextResponse.json({ error: plan.error, capacity: plan.capacity }, { status: 400 });
  const times = plan.times;
  const slots = plan.slots;
  const startsAt = plan.startsAt;
  const endsAt = plan.endsAt;

  const cost = parsed.valid.length * analysis.segments;
  const campaignId = randomUUID();
  try {
    await db.transaction(async (tx) => {
      const updated = await tx
        .update(users)
        .set({ credits: sql`${users.credits} - ${cost}` })
        .where(and(eq(users.id, user.id), gte(users.credits, cost)))
        .returning({ credits: users.credits });
      if (!updated.length) throw new Error("ORDER:insufficient_credits");
      await tx.insert(campaigns).values({
        id: campaignId,
        userId: user.id,
        name,
        senderLabel,
        message,
        encoding: analysis.encoding,
        segments: analysis.segments,
        status: new Date(startsAt).getTime() <= Date.now() + 2000 ? "sending" : "scheduled",
        scheduleMode: mode,
        windowStart: mode === "generated" ? windowStart : null,
        windowEnd: mode === "generated" ? windowEnd : null,
        perMinute,
        skipWeekend: mode === "generated" ? skipWeekend : false,
        weekendMode,
        scheduleLabel: scheduleSummary({ mode, perMinute, windowStart, windowEnd, skipWeekend, weekendMode }),
        startsAt: new Date(startsAt),
        endsAt: new Date(endsAt),
        totalRecipients: parsed.valid.length,
        creditCost: cost,
      });
      const people = parsed.valid.map((person, index) => ({
        id: randomUUID(),
        campaignId,
        phone: person.phone,
        name: person.name ?? null,
        status: "queued" as const,
        scheduledAt: new Date(times[index]),
      }));
      for (let i = 0; i < people.length; i += 400) {
        await tx.insert(recipients).values(people.slice(i, i + 400));
      }
      if (slots.length) {
        const slotRows = slots.map((slot, index) => ({
          id: randomUUID(),
          campaignId,
          slotIndex: index,
          startsAt: new Date(slot.at),
          recipientCount: slot.count,
          status: "pending",
        }));
        for (let i = 0; i < slotRows.length; i += 400) {
          await tx.insert(scheduleSlots).values(slotRows.slice(i, i + 400));
        }
      }
      await tx.insert(ledger).values({
        id: randomUUID(),
        userId: user.id,
        type: "debit",
        amount: -cost,
        balanceAfter: updated[0].credits,
        note: `Order · ${name}`,
        campaignId,
      });
    });
  } catch (error) {
    const messageText = error instanceof Error ? error.message : "";
    if (messageText.includes("insufficient_credits")) {
      return NextResponse.json({ error: "insufficient_credits" }, { status: 400 });
    }
    console.error(error);
    return NextResponse.json({ error: "server" }, { status: 500 });
  }

  await processDue(user.id, false, 30);
  return NextResponse.json({ id: campaignId });
}

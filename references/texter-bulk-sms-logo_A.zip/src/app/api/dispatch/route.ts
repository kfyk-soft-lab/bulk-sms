import { NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { processDue } from "@/lib/dispatch";

export const dynamic = "force-dynamic";

export async function POST() {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "auth" }, { status: 401 });
  const processed = await processDue(user.id, user.role === "admin", user.role === "admin" ? 80 : 40);
  return NextResponse.json({ processed });
}

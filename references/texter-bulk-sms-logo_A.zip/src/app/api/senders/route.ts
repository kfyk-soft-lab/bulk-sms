import { randomUUID } from "crypto";
import { and, eq } from "drizzle-orm";
import { NextResponse } from "next/server";
import { db } from "@/db";
import { senderIds } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "auth" }, { status: 401 });
  const body = (await request.json().catch(() => null)) as { label?: string } | null;
  const label = (body?.label ?? "").toUpperCase().replace(/[^A-Z0-9]/g, "");
  if (!/^[A-Z][A-Z0-9]{2,10}$/.test(label)) return NextResponse.json({ error: "bad_sender" }, { status: 400 });
  const existing = await db
    .select()
    .from(senderIds)
    .where(and(eq(senderIds.userId, user.id), eq(senderIds.label, label)))
    .limit(1);
  if (existing.length) return NextResponse.json({ error: "sender_exists" }, { status: 409 });
  await db.insert(senderIds).values({
    id: randomUUID(),
    userId: user.id,
    label,
    status: "pending",
  });
  return NextResponse.json({ ok: true });
}

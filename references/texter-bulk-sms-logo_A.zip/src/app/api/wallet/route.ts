import { randomUUID } from "crypto";
import { eq, sql } from "drizzle-orm";
import { NextResponse } from "next/server";
import { db } from "@/db";
import { ledger, users } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";
import { findPack } from "@/lib/packs";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "auth" }, { status: 401 });
  const body = (await request.json().catch(() => null)) as { packId?: string } | null;
  const pack = findPack(body?.packId ?? "");
  if (!pack) return NextResponse.json({ error: "bad_pack" }, { status: 400 });
  const reference = `PAY-${randomUUID().slice(0, 8).toUpperCase()}`;
  const [updated] = await db
    .update(users)
    .set({ credits: sql`${users.credits} + ${pack.credits}` })
    .where(eq(users.id, user.id))
    .returning({ credits: users.credits });
  await db.insert(ledger).values({
    id: randomUUID(),
    userId: user.id,
    type: "purchase",
    amount: pack.credits,
    balanceAfter: updated.credits,
    note: `${reference} · ${pack.en} · ৳${pack.bdt}`,
  });
  return NextResponse.json({ ok: true, reference, credits: pack.credits, balance: updated.credits });
}

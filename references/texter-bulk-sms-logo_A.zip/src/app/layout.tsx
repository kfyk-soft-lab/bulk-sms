import type { Metadata } from "next";
import type { ReactNode } from "react";
import { Fraunces, Hind_Siliguri, IBM_Plex_Mono, Outfit } from "next/font/google";
import { getLang } from "@/lib/lang";
import "./globals.css";

const sans = Outfit({ subsets: ["latin"], variable: "--font-sans", display: "swap" });
const display = Fraunces({ subsets: ["latin"], variable: "--font-display", display: "swap" });
const mono = IBM_Plex_Mono({ subsets: ["latin"], weight: ["400", "500"], variable: "--font-mono", display: "swap" });
const bn = Hind_Siliguri({
  subsets: ["bengali", "latin"],
  weight: ["400", "500", "600", "700"],
  variable: "--font-bn",
  display: "swap",
});

export const metadata: Metadata = {
  title: {
    default: "Texter — Bulk SMS by Kfyklab",
    template: "%s · Texter",
  },
  description: "Kfyklab Texter collects bulk SMS orders and sends each message on its generated schedule.",
  icons: { icon: "/brand/texter-mark.png" },
  openGraph: {
    title: "Texter — Bulk SMS by Kfyklab",
    description: "Place a bulk SMS order. Texter writes the timetable and fires each message when its slot opens.",
    images: ["/brand/texter-lockup.png"],
  },
};

export default async function RootLayout({ children }: { children: ReactNode }) {
  const lang = await getLang();
  return (
    <html lang={lang === "bn" ? "bn" : "en"} data-lang={lang} className={`${sans.variable} ${display.variable} ${mono.variable} ${bn.variable}`}>
      <body data-lang={lang}>{children}</body>
    </html>
  );
}

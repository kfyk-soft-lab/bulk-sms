import Link from "next/link";
import { redirect } from "next/navigation";
import type { Metadata } from "next";
import { LoginForm } from "@/components/auth-forms";
import { LangSwitch } from "@/components/chrome";
import { Logo } from "@/components/logo";
import { getCurrentUser } from "@/lib/auth";
import { pick } from "@/lib/i18n";
import { getLang } from "@/lib/lang";

export const metadata: Metadata = { title: "Log in" };

export default async function LoginPage({ searchParams }: { searchParams: Promise<{ next?: string }> }) {
  const user = await getCurrentUser();
  if (user) redirect("/portal");
  const lang = await getLang();
  const params = await searchParams;
  const next = params.next && params.next.startsWith("/") && !params.next.startsWith("//") ? params.next : "/portal";

  return (
    <main className="auth-grid">
      <section className="auth-brand">
        <div>
          <Logo dark />
          <h1 style={{ marginTop: 28 }}>{pick(lang, "The desk is open.", "ডেস্ক খোলা।")}</h1>
          <p>{pick(lang, "Orders, timetables, and the sandbox gateway live behind this door.", "অর্ডার, সময়সূচি আর স্যান্ডবক্স গেটওয়ে এই দরজার পেছনে।")}</p>
        </div>
        <img src="/brand/texter-lockup.png" alt="Texter by Kfyklab" style={{ background: "#f6f3ec", borderRadius: 16, padding: 8 }} />
      </section>
      <section className="auth-card">
        <div className="row-actions" style={{ justifyContent: "space-between" }}>
          <Link href="/">{pick(lang, "Back", "ফিরে যান")}</Link>
          <LangSwitch lang={lang} />
        </div>
        <h2>{pick(lang, "Log in", "লগ ইন")}</h2>
        <LoginForm lang={lang} next={next} />
        <div className="demo-box">
          <strong>{pick(lang, "Lab keys", "ল্যাব চাবি")}</strong>
          <p><code>demo@kfyklab.com</code> · <code>Demo#2048</code></p>
          <p><code>admin@kfyklab.com</code> · <code>Signal#2048</code></p>
          <p className="fine">{pick(lang, "The admin key opens the operator desk for sender approval.", "অ্যাডমিন চাবি সেন্ডার অনুমোদনের অপারেটর ডেস্ক খোলে।")}</p>
        </div>
        <p>{pick(lang, "New counter?", "নতুন কাউন্টার?")} <Link href="/register">{pick(lang, "Create a desk", "ডেস্ক তৈরি করুন")}</Link></p>
      </section>
    </main>
  );
}

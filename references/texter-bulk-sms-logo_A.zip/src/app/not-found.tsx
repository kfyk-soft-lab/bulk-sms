import Link from "next/link";
import { Logo } from "@/components/logo";

export default function NotFound() {
  return (
    <main className="wrap" style={{ padding: "80px 0" }}>
      <Logo />
      <h1>That page left the queue.</h1>
      <p>The address is not on this desk.</p>
      <Link className="btn" href="/">Back to Texter</Link>
    </main>
  );
}

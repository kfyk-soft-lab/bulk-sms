import Link from "next/link";
import { PaceSketch } from "@/components/pace-sketch";
import { SiteFooter, SiteHeader } from "@/components/chrome";
import { Logo } from "@/components/logo";
import { getLang } from "@/lib/lang";
import { pick } from "@/lib/i18n";

export default async function HomePage() {
  const lang = await getLang();
  return (
    <>
      <SiteHeader lang={lang} />
      <main id="main">
        <section className="hero">
          <div className="wrap hero-grid">
            <div>
              <p className="kicker">Kfyklab · Texter</p>
              <h1>{pick(lang, "Bulk SMS that waits for its minute.", "বাল্ক এসএমএস, নিজের মিনিটের জন্য অপেক্ষা করে।")}</h1>
              <hr className="rule" />
              <p className="lede">
                {pick(
                  lang,
                  "Shops, schools, and clinics place an order online. Texter counts the segments, prices the blast, and lays every number on a send slot — now, at a fixed hour, or paced across the hours you choose.",
                  "দোকান, স্কুল আর ক্লিনিক অনলাইনে অর্ডার দেয়। Texter সেগমেন্ট গুনে, খরচ বের করে, আর প্রতিটি নম্বরকে একটি সেন্ড স্লটে বসায় — এখনই, নির্দিষ্ট সময়ে, অথবা আপনার বেছে নেওয়া ঘণ্টাজুড়ে।",
                )}
              </p>
              <div className="cta-row">
                <Link className="btn btn-teal" href="/register">{pick(lang, "Place an SMS order", "এসএমএস অর্ডার দিন")}</Link>
                <Link className="btn btn-ghost" href="/login">{pick(lang, "Open the desk", "ডেস্ক খুলুন")}</Link>
              </div>
              <ul className="hero-stats">
                <li><strong className="num">160 / 70</strong><span>{pick(lang, "GSM / Bangla chars", "GSM / বাংলা অক্ষর")}</span></li>
                <li><strong className="num">+880</strong><span>{pick(lang, "numbers normalized", "নম্বর ঠিক করা হয়")}</span></li>
                <li><strong>Asia/Dhaka</strong><span>{pick(lang, "every slot", "প্রতিটি স্লট")}</span></li>
              </ul>
            </div>
            <PaceSketch lang={lang} />
          </div>
        </section>

        <section className="band" id="product">
          <div className="wrap steps">
            {[
              ["01", pick(lang, "Open a desk", "ডেস্ক খুলুন"), pick(lang, "Signup drops 400 lab credits on the counter.", "সাইনআপে কাউন্টারে ৪০০ ল্যাব ক্রেডিট পড়ে।")],
              ["02", pick(lang, "Write the list", "তালিকা লিখুন"), pick(lang, "Paste numbers, Bangla or English, and a sender ID.", "নম্বর, বাংলা বা ইংরেজি, আর সেন্ডার আইডি দিন।")],
              ["03", pick(lang, "Generate the clock", "ঘড়ি তৈরি করুন"), pick(lang, "Instant, fixed, or a window that skips Friday–Saturday.", "এখনই, নির্দিষ্ট সময়, অথবা শুক্র–শনি বাদ দিয়ে উইন্ডো।")],
              ["04", pick(lang, "Leave on the minute", "মিনিটে পাঠান"), pick(lang, "The gateway fires each row when its slot opens.", "স্লট খুললেই গেটওয়ে সেই সারি পাঠায়।")],
            ].map(([num, title, body]) => (
              <article className="step" key={num}>
                <b>{num}</b>
                <h3>{title}</h3>
                <p>{body}</p>
              </article>
            ))}
          </div>
        </section>

        <section className="band">
          <div className="wrap split">
            <figure className="photo-card">
              <img
                src="https://images.pexels.com/photos/12495827/pexels-photo-12495827.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=900"
                alt={pick(lang, "Shopkeeper arranging stock, the kind of counter Texter is built for", "দোকানি সামগ্রী গুছাচ্ছেন — Texter এমন কাউন্টারের জন্য")}
              />
              <figcaption>The.sahil.photography / Pexels</figcaption>
            </figure>
            <div className="story">
              <p className="kicker">{pick(lang, "Why a timetable", "সময়সূচি কেন")}</p>
              <h2>{pick(lang, "A blast is a queue, not a button.", "ব্লাস্ট একটি সারি, একটি বোতাম নয়।")}</h2>
              <p className="lede">
                {pick(
                  lang,
                  "Carriers throttle sender IDs. Customers do not want a promo at 1am. Texter turns the order into minutes: a daily window, a pace, and a weekend rule. You can see the roster before you pay in credits.",
                  "অপারেটর সেন্ডার আইডিকে থ্রটল করে। রাত ১টায় প্রোমো কেউ চায় না। Texter অর্ডারকে মিনিটে ভাঙে — দৈনিক উইন্ডো, গতি, আর ছুটির নিয়ম। ক্রেডিট কাটার আগেই রোস্টার দেখা যায়।",
                )}
              </p>
              <p>
                {pick(
                  lang,
                  "This preview runs a sandbox gateway. Delivery logs, failures, and refunds for unsent rows all behave like a live desk — without leaving the building.",
                  "এই প্রিভিউ একটি স্যান্ডবক্স গেটওয়ে চালায়। ডেলিভারি লগ, ব্যর্থতা, আর না-পাঠানো সারির ফেরত — সব লাইভ ডেস্কের মতো, কিন্তু ভবনের বাইরে যায় না।",
                )}
              </p>
            </div>
          </div>
        </section>

        <section className="band">
          <div className="wrap bento">
            <article className="panel logo-plate">
              <img src="/brand/texter-lockup.png" alt="Texter by Kfyklab logo" />
            </article>
            <article className="panel">
              <div className="mark-row">
                <img src="/brand/texter-mark.png" alt="Texter mark" />
                <div>
                  <p className="kicker">{pick(lang, "The mark", "চিহ্ন")}</p>
                  <h3>{pick(lang, "A send-bar T", "একটি সেন্ড-বার টি")}</h3>
                </div>
              </div>
              <p style={{ marginTop: 12 }}>
                {pick(
                  lang,
                  "Cream is the message. Coral is the moment it leaves. The teal bars are the schedule filling up — short, then taller, then due.",
                  "ক্রিম হলো বার্তা। কোরাল হলো পাঠানোর মুহূর্ত। তিল বার হলো ভরে ওঠা সময়সূচি — ছোট, তারপর লম্বা, তারপর সময়।",
                )}
              </p>
            </article>
            <article className="panel">
              <Logo />
              <h3 style={{ marginTop: 14 }}>{pick(lang, "Unicode, on purpose", "ইচ্ছে করেই ইউনিকোড")}</h3>
              <p>{pick(lang, "Bangla text is billed at 70 characters, then 67. English stays on the GSM 160 rail. The counter tells you before the order is placed.", "বাংলা বার্তা ৭০, তারপর ৬৭ অক্ষরে হিসাব হয়। ইংরেজি থাকে GSM ১৬০-এ। অর্ডারের আগেই কাউন্টার বলে দেয়।")}</p>
            </article>
          </div>
        </section>

        <section className="band">
          <div className="wrap split">
            <div>
              <p className="kicker">{pick(lang, "What the desk holds", "ডেস্কে কী থাকে")}</p>
              <h2>{pick(lang, "Orders, sender IDs, a wallet, a report.", "অর্ডার, সেন্ডার আইডি, ওয়ালেট, রিপোর্ট।")}</h2>
              <div className="steps" style={{ marginTop: 18 }}>
                <article className="panel feature">
                  <h3>{pick(lang, "Audience cleanup", "তালিকা পরিষ্কার")}</h3>
                  <p>{pick(lang, "01, 880, and +880 collapse to one handset. Duplicates drop out.", "০১, ৮৮০ আর +৮৮০ এক হ্যান্ডসেটে মেশে। ডুপ্লিকেট বাদ যায়।")}</p>
                </article>
                <article className="panel feature">
                  <h3>{pick(lang, "Credits", "ক্রেডিট")}</h3>
                  <p>{pick(lang, "One credit per segment per number. Cancel refunds only what has not left.", "প্রতি নম্বরে প্রতি সেগমেন্টে এক ক্রেডিট। বাতিলে শুধু না-পাঠানো ফেরে।")}</p>
                </article>
              </div>
            </div>
            <figure className="photo-card">
              <img
                src="https://images.pexels.com/photos/4979123/pexels-photo-4979123.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=1200"
                alt={pick(lang, "A hand holding a phone as a message arrives", "বার্তা আসার সময় হাতে একটি ফোন")}
              />
              <figcaption>Tranmautritam / Pexels</figcaption>
            </figure>
          </div>
        </section>

        <section className="band">
          <div className="wrap">
            <div className="main-head">
              <div>
                <p className="kicker">{pick(lang, "Packs", "প্যাক")}</p>
                <h2>{pick(lang, "Pay in BDT. Spend in segments.", "টাকা বিডিতে। খরচ সেগমেন্টে।")}</h2>
              </div>
              <Link className="btn" href="/pricing">{pick(lang, "See pricing", "মূল্য দেখুন")}</Link>
            </div>
            <div className="faq">
              <details open>
                <summary>{pick(lang, "Does this send to real phones?", "এটা কি সত্যিকারের ফোনে যায়?")}</summary>
                <p>{pick(lang, "Not in this preview. The gateway logs a provider reference and a delivered or failed result on the schedule you generated.", "এই প্রিভিউয়ে না। গেটওয়ে আপনার তৈরি সময়সূচিতে একটি রেফারেন্স আর ডেলিভার্ড বা ব্যর্থ ফল লগ করে।")}</p>
              </details>
              <details>
                <summary>{pick(lang, "What if I cancel?", "বাতিল করলে?")}</summary>
                <p>{pick(lang, "Queued rows return their credits. Messages already marked delivered or failed stay billed.", "সারিতে থাকা সারি ক্রেডিট ফেরত দেয়। যা ডেলিভার্ড বা ব্যর্থ হয়েছে, সেটা থেকে যায়।")}</p>
              </details>
              <details>
                <summary>{pick(lang, "Can I write in Bangla?", "বাংলায় লেখা যায়?")}</summary>
                <p>{pick(lang, "Yes. The desk switches to Unicode automatically and prices the longer segments.", "হ্যাঁ। ডেস্ক নিজেই ইউনিকোডে যায় এবং লম্বা সেগমেন্টের দাম ধরে।")}</p>
              </details>
            </div>
          </div>
        </section>
      </main>
      <SiteFooter lang={lang} />
    </>
  );
}

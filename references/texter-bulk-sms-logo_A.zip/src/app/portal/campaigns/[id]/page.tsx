import Link from "next/link";
import { notFound } from "next/navigation";
import { and, asc, eq, sql } from "drizzle-orm";
import { CampaignControls } from "@/components/desk-widgets";
import { LiveDispatch } from "@/components/live-dispatch";
import { db } from "@/db";
import { campaigns, recipients, scheduleSlots } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";
import { formatDhaka, formatNumber, orderCode } from "@/lib/format";
import { pick, statusLabel } from "@/lib/i18n";
import { getLang } from "@/lib/lang";

export const dynamic = "force-dynamic";

export default async function CampaignPage({
  params,
  searchParams,
}: {
  params: Promise<{ id: string }>;
  searchParams: Promise<{ status?: string }>;
}) {
  const user = await getCurrentUser();
  if (!user) return null;
  const lang = await getLang();
  const { id } = await params;
  const query = await searchParams;
  const [order] = await db.select().from(campaigns).where(eq(campaigns.id, id)).limit(1);
  if (!order || (order.userId !== user.id && user.role !== "admin")) notFound();

  const counts = await db
    .select({ status: recipients.status, n: sql<number>`count(*)::int` })
    .from(recipients)
    .where(eq(recipients.campaignId, id))
    .groupBy(recipients.status);
  const tally = Object.fromEntries(counts.map((row) => [row.status, Number(row.n)])) as Record<string, number>;
  const filter = ["queued", "delivered", "failed", "cancelled"].includes(query.status ?? "") ? query.status : undefined;
  const people = await db
    .select()
    .from(recipients)
    .where(filter ? and(eq(recipients.campaignId, id), eq(recipients.status, filter)) : eq(recipients.campaignId, id))
    .orderBy(asc(recipients.scheduledAt))
    .limit(60);
  const chartRows = await db
    .select({ status: recipients.status, scheduledAt: recipients.scheduledAt })
    .from(recipients)
    .where(eq(recipients.campaignId, id));
  const slots = await db.select().from(scheduleSlots).where(eq(scheduleSlots.campaignId, id)).orderBy(asc(scheduleSlots.slotIndex)).limit(8);
  const useHour = chartRows.length > 48;
  const buckets = new Map<number, { at: number; queued: number; delivered: number; failed: number }>();
  for (const row of chartRows) {
    const ms = row.scheduledAt.getTime();
    const span = useHour ? 60 * 60 * 1000 : 60 * 1000;
    const key = Math.floor(ms / span) * span;
    const item = buckets.get(key) ?? { at: key, queued: 0, delivered: 0, failed: 0 };
    if (row.status === "delivered") item.delivered += 1;
    else if (row.status === "failed") item.failed += 1;
    else if (row.status === "queued") item.queued += 1;
    buckets.set(key, item);
  }
  const bars = [...buckets.values()].sort((a, b) => a.at - b.at).slice(0, 24);
  const max = Math.max(...bars.map((bar) => bar.queued + bar.delivered + bar.failed), 1);
  const done = (tally.delivered ?? 0) + (tally.failed ?? 0);
  const progress = order.totalRecipients ? Math.round((done / order.totalRecipients) * 100) : 0;
  const active = order.status === "sending" || order.status === "scheduled";

  return (
    <>
      <LiveDispatch active={active} />
      <div className="main-head">
        <div>
          <p className="kicker num">{orderCode(order.id)} · {order.senderLabel}</p>
          <h1>{order.name}</h1>
          <p className="hint">{order.scheduleLabel}</p>
        </div>
        <CampaignControls lang={lang} id={order.id} status={order.status} />
      </div>
      <div className="stat-row">
        <article className="panel stat"><b><span className={`pill pill-${order.status}`}>{statusLabel(lang, order.status)}</span></b><span>{progress}%</span></article>
        <article className="panel stat"><b className="num">{formatNumber(tally.delivered ?? 0, lang)}</b><span>{pick(lang, "Delivered", "পৌঁছেছে")}</span></article>
        <article className="panel stat"><b className="num">{formatNumber(tally.failed ?? 0, lang)}</b><span>{pick(lang, "Failed", "ব্যর্থ")}</span></article>
        <article className="panel stat"><b className="num">{formatNumber(tally.queued ?? 0, lang)}</b><span>{pick(lang, "Still queued", "এখনো সারিতে")}</span></article>
      </div>
      <div className="desk-grid" style={{ marginTop: 18 }}>
        <section className="panel">
          <h2>{pick(lang, "Timetable", "সময়সূচি")}</h2>
          <div className="meter" style={{ margin: "8px 0 14px" }}><span style={{ width: `${progress}%` }} /></div>
          <div className="timeline">
            {bars.map((bar) => (
              <div className="tl-col" key={bar.at}>
                <div className="tl-stack">
                  <div className="tl-failed" style={{ height: `${(bar.failed / max) * 100}%` }} />
                  <div className="tl-queued" style={{ height: `${(bar.queued / max) * 100}%` }} />
                  <div className="tl-ok" style={{ height: `${(bar.delivered / max) * 100}%` }} />
                </div>
                <span>{formatDhaka(new Date(bar.at), "en", false)}</span>
              </div>
            ))}
          </div>
          {slots.length ? (
            <div className="table-wrap" style={{ marginTop: 12 }}>
              <table>
                <thead>
                  <tr>
                    <th>#</th>
                    <th>{pick(lang, "Slot", "স্লট")}</th>
                    <th>{pick(lang, "Planned", "পরিকল্পিত")}</th>
                  </tr>
                </thead>
                <tbody>
                  {slots.map((slot) => (
                    <tr key={slot.id}>
                      <td className="num">{slot.slotIndex + 1}</td>
                      <td className="num">{formatDhaka(slot.startsAt, lang)}</td>
                      <td className="num">{formatNumber(slot.recipientCount, lang)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : null}
        </section>
        <aside className="ticket">
          <h2>{pick(lang, "Receipt", "রসিদ")}</h2>
          <p><span className="hint">{pick(lang, "Placed", "দেওয়া")}</span><br />{formatDhaka(order.createdAt, lang)}</p>
          <p><span className="hint">{pick(lang, "Window", "উইন্ডো")}</span><br />{order.startsAt ? formatDhaka(order.startsAt, lang) : "—"} → {order.endsAt ? formatDhaka(order.endsAt, lang) : "—"}</p>
          <p><span className="hint">{pick(lang, "Segments", "সেগমেন্ট")}</span><br />{order.encoding} · {order.segments}</p>
          <p><span className="hint">{pick(lang, "Credits held", "ক্রেডিট")}</span><br /><span className="num">{formatNumber(order.creditCost, lang)}</span></p>
          <p className="fine">{order.message}</p>
          <Link href="/portal">{pick(lang, "All orders", "সব অর্ডার")}</Link>
        </aside>
      </div>
      <section className="panel" style={{ marginTop: 18 }}>
        <h2>{pick(lang, "Handsets", "হ্যান্ডসেট")}</h2>
        <div className="filters">
          {["all", "queued", "delivered", "failed", "cancelled"].map((status) => {
            const href = status === "all" ? `/portal/campaigns/${id}` : `/portal/campaigns/${id}?status=${status}`;
            const on = (filter ?? "all") === status;
            return <Link key={status} href={href} className={on ? "on" : undefined}>{status === "all" ? pick(lang, "All", "সব") : statusLabel(lang, status)}</Link>;
          })}
        </div>
        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                <th>{pick(lang, "Number", "নম্বর")}</th>
                <th>{pick(lang, "Name", "নাম")}</th>
                <th>{pick(lang, "Status", "অবস্থা")}</th>
                <th>{pick(lang, "Slot", "স্লট")}</th>
                <th>{pick(lang, "Ref", "রেফ")}</th>
              </tr>
            </thead>
            <tbody>
              {people.map((person) => (
                <tr key={person.id}>
                  <td className="num">{person.phone}</td>
                  <td>{person.name ?? "—"}</td>
                  <td><span className={`pill pill-${person.status}`}>{statusLabel(lang, person.status)}</span></td>
                  <td className="num">{formatDhaka(person.scheduledAt, lang)}</td>
                  <td className="num">{person.providerRef ?? person.error ?? "—"}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <p className="fine">{pick(lang, "Showing up to 60 rows. Export CSV for the full roster.", "৬০ সারি পর্যন্ত দেখাচ্ছে। পুরো রোস্টারের জন্য CSV নিন।")}</p>
      </section>
    </>
  );
}

import Link from "next/link";
import { and, eq } from "drizzle-orm";
import { OrderComposer } from "@/components/order-composer";
import { db } from "@/db";
import { senderIds } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";
import { pick } from "@/lib/i18n";
import { getLang } from "@/lib/lang";

export const dynamic = "force-dynamic";

export default async function OrderPage() {
  const user = await getCurrentUser();
  if (!user) return null;
  const lang = await getLang();
  const senders = await db
    .select({ label: senderIds.label })
    .from(senderIds)
    .where(and(eq(senderIds.userId, user.id), eq(senderIds.status, "approved")));

  return (
    <>
      <div className="main-head">
        <div>
          <p className="kicker">{pick(lang, "New order", "নতুন অর্ডার")}</p>
          <h1>{pick(lang, "Collect the list. Write the clock.", "তালিকা নিন। ঘড়ি লিখুন।")}</h1>
        </div>
      </div>
      {senders.length === 0 ? (
        <div className="panel">
          <p>{pick(lang, "You need an approved sender ID before an order can leave.", "অর্ডার ছাড়ার আগে একটি অনুমোদিত সেন্ডার আইডি লাগবে।")}</p>
          <Link className="btn" href="/portal/senders">{pick(lang, "Request a sender", "সেন্ডার চাই")}</Link>
        </div>
      ) : (
        <OrderComposer lang={lang} credits={user.credits} senders={senders} />
      )}
    </>
  );
}

import Link from "next/link";
import { and, asc, desc, eq, gte, sql } from "drizzle-orm";
import { LiveDispatch } from "@/components/live-dispatch";
import { db } from "@/db";
import { campaigns, recipients } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";
import { formatDhaka, formatNumber, orderCode } from "@/lib/format";
import { pick, statusLabel } from "@/lib/i18n";
import { getLang } from "@/lib/lang";
import { dateToDhakaParts, dhakaDate } from "@/lib/sms";
import { rearmSampleQueue } from "@/lib/seed";

export const dynamic = "force-dynamic";

export default async function DeskPage() {
  const user = await getCurrentUser();
  if (!user) return null;
  await rearmSampleQueue(user.id);
  const lang = await getLang();
  const orders = await db.select().from(campaigns).where(eq(campaigns.userId, user.id)).orderBy(desc(campaigns.createdAt));
  const parts = dateToDhakaParts(new Date());
  const todayStart = dhakaDate(parts.year, parts.month, parts.day, 0, 0);
  const [today] = await db
    .select({ n: sql<number>`count(*)::int` })
    .from(recipients)
    .innerJoin(campaigns, eq(recipients.campaignId, campaigns.id))
    .where(and(eq(campaigns.userId, user.id), eq(recipients.status, "delivered"), gte(recipients.sentAt, todayStart)));
  const upcoming = await db
    .select({
      id: recipients.id,
      phone: recipients.phone,
      scheduledAt: recipients.scheduledAt,
      name: campaigns.name,
      campaignId: campaigns.id,
    })
    .from(recipients)
    .innerJoin(campaigns, eq(recipients.campaignId, campaigns.id))
    .where(and(eq(campaigns.userId, user.id), eq(recipients.status, "queued"), gte(recipients.scheduledAt, new Date(Date.now() - 60 * 1000))))
    .orderBy(asc(recipients.scheduledAt))
    .limit(6);
  const active = orders.some((order) => order.status === "sending" || order.status === "scheduled");
  const delivered = orders.reduce((sum, order) => sum + order.deliveredCount, 0);
  const failed = orders.reduce((sum, order) => sum + order.failedCount, 0);

  return (
    <>
      <LiveDispatch active={active} />
      <div className="main-head">
        <div>
          <p className="kicker">{user.company ?? "Texter"}</p>
          <h1>{pick(lang, "Good shift,", "শুভ শিফট,")} {user.name.split(" ")[0]}</h1>
        </div>
        <Link className="btn btn-teal" href="/portal/order">{pick(lang, "New order", "নতুন অর্ডার")}</Link>
      </div>
      <div className="stat-row">
        {[
          [formatNumber(user.credits, lang), pick(lang, "Credits on the counter", "কাউন্টারে ক্রেডিট")],
          [formatNumber(orders.length, lang), pick(lang, "Orders", "অর্ডার")],
          [formatNumber(Number(today?.n ?? 0), lang), pick(lang, "Delivered today", "আজ পৌঁছেছে")],
          [formatNumber(failed, lang), pick(lang, "Failed, all time", "মোট ব্যর্থ")],
        ].map(([value, label]) => (
          <article className="panel stat" key={label}>
            <b className="num">{value}</b>
            <span>{label}</span>
          </article>
        ))}
      </div>
      <div className="desk-grid" style={{ marginTop: 18 }}>
        <section className="panel">
          <h2>{pick(lang, "Orders", "অর্ডার")}</h2>
          {orders.length === 0 ? (
            <div className="empty">
              <p>{pick(lang, "No orders yet. The first one writes the timetable.", "এখনো অর্ডার নেই। প্রথমটাই সময়সূচি লিখবে।")}</p>
              <Link className="btn" href="/portal/order">{pick(lang, "Place an order", "অর্ডার দিন")}</Link>
            </div>
          ) : (
            <div className="table-wrap">
              <table>
                <thead>
                  <tr>
                    <th>{pick(lang, "Order", "অর্ডার")}</th>
                    <th>{pick(lang, "Status", "অবস্থা")}</th>
                    <th>{pick(lang, "Audience", "দর্শক")}</th>
                    <th>{pick(lang, "Delivered", "পৌঁছেছে")}</th>
                    <th>{pick(lang, "When", "কখন")}</th>
                  </tr>
                </thead>
                <tbody>
                  {orders.map((order) => (
                    <tr key={order.id}>
                      <td>
                        <Link href={`/portal/campaigns/${order.id}`}><strong>{order.name}</strong></Link>
                        <div className="fine num">{orderCode(order.id)} · {order.senderLabel}</div>
                      </td>
                      <td><span className={`pill pill-${order.status}`}>{statusLabel(lang, order.status)}</span></td>
                      <td className="num">{formatNumber(order.totalRecipients, lang)}</td>
                      <td className="num">{formatNumber(order.deliveredCount, lang)}/{formatNumber(order.totalRecipients, lang)}</td>
                      <td className="num">{order.startsAt ? formatDhaka(order.startsAt, lang) : "—"}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </section>
        <aside className="ticket">
          <h2>{pick(lang, "Next slots", "পরের স্লট")}</h2>
          {active ? <p className="hint"><span className="live-dot" /> {pick(lang, "Gateway is watching the clock.", "গেটওয়ে ঘড়ি দেখছে।")}</p> : null}
          {upcoming.length === 0 ? <p className="fine">{pick(lang, "Nothing queued ahead.", "সামনে সারিতে কিছু নেই।")}</p> : null}
          {upcoming.map((row) => (
            <p key={row.id}>
              <Link href={`/portal/campaigns/${row.campaignId}`}><strong>{row.name}</strong></Link>
              <br />
              <span className="num">{row.phone}</span>
              <span className="fine"> · {formatDhaka(row.scheduledAt, lang)}</span>
            </p>
          ))}
          <p className="fine">{pick(lang, "Delivered across orders", "সব অর্ডারে পৌঁছেছে")}: <span className="num">{formatNumber(delivered, lang)}</span></p>
        </aside>
      </div>
    </>
  );
}

import Link from "next/link";
import { and, desc, eq, sql } from "drizzle-orm";
import { LiveDispatch } from "@/components/live-dispatch";
import { db } from "@/db";
import { campaigns, recipients } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";
import { formatDhaka, formatNumber, orderCode } from "@/lib/format";
import { pick, statusLabel } from "@/lib/i18n";
import { getLang } from "@/lib/lang";

export const dynamic = "force-dynamic";

export default async function ReportsPage({ searchParams }: { searchParams: Promise<{ status?: string }> }) {
  const user = await getCurrentUser();
  if (!user) return null;
  const lang = await getLang();
  const query = await searchParams;
  const status = ["delivered", "failed", "queued"].includes(query.status ?? "") ? query.status : undefined;
  const filters = [eq(campaigns.userId, user.id)];
  if (status) filters.push(eq(recipients.status, status));
  const rows = await db
    .select({
      id: recipients.id,
      phone: recipients.phone,
      status: recipients.status,
      scheduledAt: recipients.scheduledAt,
      sentAt: recipients.sentAt,
      providerRef: recipients.providerRef,
      error: recipients.error,
      campaignId: campaigns.id,
      campaignName: campaigns.name,
    })
    .from(recipients)
    .innerJoin(campaigns, eq(recipients.campaignId, campaigns.id))
    .where(and(...filters))
    .orderBy(desc(recipients.scheduledAt))
    .limit(80);
  const [active] = await db
    .select({ n: sql<number>`count(*)::int` })
    .from(campaigns)
    .where(and(eq(campaigns.userId, user.id), eq(campaigns.status, "sending")));

  return (
    <>
      <LiveDispatch active={Number(active?.n ?? 0) > 0} />
      <div className="main-head">
        <div>
          <p className="kicker">{pick(lang, "Delivery report", "ডেলিভারি রিপোর্ট")}</p>
          <h1>{pick(lang, "What left the building.", "যা বেরিয়েছে।")}</h1>
        </div>
      </div>
      <div className="filters">
        {["all", "delivered", "failed", "queued"].map((item) => (
          <Link key={item} className={(status ?? "all") === item ? "on" : undefined} href={item === "all" ? "/portal/reports" : `/portal/reports?status=${item}`}>
            {item === "all" ? pick(lang, "All", "সব") : statusLabel(lang, item)}
          </Link>
        ))}
      </div>
      <section className="panel">
        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                <th>{pick(lang, "Order", "অর্ডার")}</th>
                <th>{pick(lang, "Number", "নম্বর")}</th>
                <th>{pick(lang, "Status", "অবস্থা")}</th>
                <th>{pick(lang, "Slot", "স্লট")}</th>
                <th>{pick(lang, "Ref", "রেফ")}</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((row) => (
                <tr key={row.id}>
                  <td>
                    <Link href={`/portal/campaigns/${row.campaignId}`}>{row.campaignName}</Link>
                    <div className="fine num">{orderCode(row.campaignId)}</div>
                  </td>
                  <td className="num">{row.phone}</td>
                  <td><span className={`pill pill-${row.status}`}>{statusLabel(lang, row.status)}</span></td>
                  <td className="num">{formatDhaka(row.sentAt ?? row.scheduledAt, lang)}</td>
                  <td className="num">{row.providerRef ?? row.error ?? "—"}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <p className="fine">{formatNumber(rows.length, lang)} {pick(lang, "rows", "সারি")}</p>
      </section>
    </>
  );
}

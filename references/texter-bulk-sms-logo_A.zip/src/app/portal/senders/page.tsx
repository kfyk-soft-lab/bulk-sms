import { desc, eq } from "drizzle-orm";
import { SenderForm } from "@/components/desk-widgets";
import { db } from "@/db";
import { senderIds } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";
import { formatDhaka } from "@/lib/format";
import { pick, statusLabel } from "@/lib/i18n";
import { getLang } from "@/lib/lang";

export const dynamic = "force-dynamic";

export default async function SendersPage() {
  const user = await getCurrentUser();
  if (!user) return null;
  const lang = await getLang();
  const rows = await db.select().from(senderIds).where(eq(senderIds.userId, user.id)).orderBy(desc(senderIds.createdAt));
  return (
    <>
      <div className="main-head">
        <div>
          <p className="kicker">{pick(lang, "Sender IDs", "সেন্ডার আইডি")}</p>
          <h1>{pick(lang, "The name on the handset.", "হ্যান্ডসেটে যে নাম দেখায়।")}</h1>
        </div>
      </div>
      <div className="desk-grid">
        <section className="panel">
          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>ID</th>
                  <th>{pick(lang, "Status", "অবস্থা")}</th>
                  <th>{pick(lang, "Requested", "চাওয়া")}</th>
                </tr>
              </thead>
              <tbody>
                {rows.map((row) => (
                  <tr key={row.id}>
                    <td className="num">{row.label}</td>
                    <td><span className={`pill pill-${row.status}`}>{statusLabel(lang, row.status)}</span></td>
                    <td className="num">{formatDhaka(row.createdAt, lang)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>
        <aside className="ticket">
          <SenderForm lang={lang} />
          <p className="fine">{pick(lang, "Pending IDs cannot ride an order. TEXTER is cleared so you are never stuck. Ask the operator desk to approve a custom name.", "অপেক্ষমাণ আইডি অর্ডারে চড়ে না। TEXTER খোলা, তাই আটকে যাবেন না। নিজের নামের জন্য অপারেটর ডেস্ককে বলুন।")}</p>
        </aside>
      </div>
    </>
  );
}

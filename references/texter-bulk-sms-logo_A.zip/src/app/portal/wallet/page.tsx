import { desc, eq } from "drizzle-orm";
import { WalletPanel } from "@/components/desk-widgets";
import { db } from "@/db";
import { ledger } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";
import { formatDhaka, formatNumber } from "@/lib/format";
import { pick, statusLabel } from "@/lib/i18n";
import { getLang } from "@/lib/lang";

export const dynamic = "force-dynamic";

export default async function WalletPage() {
  const user = await getCurrentUser();
  if (!user) return null;
  const lang = await getLang();
  const rows = await db.select().from(ledger).where(eq(ledger.userId, user.id)).orderBy(desc(ledger.createdAt)).limit(20);
  return (
    <>
      <div className="main-head">
        <div>
          <p className="kicker">{pick(lang, "Wallet", "ওয়ালেট")}</p>
          <h1 className="num">{formatNumber(user.credits, lang)}</h1>
          <p className="hint">{pick(lang, "Credits left on this desk.", "এই ডেস্কে বাকি ক্রেডিট।")}</p>
        </div>
      </div>
      <WalletPanel lang={lang} />
      <section className="panel" style={{ marginTop: 18 }}>
        <h2>{pick(lang, "Ledger", "খতিয়ান")}</h2>
        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                <th>{pick(lang, "When", "কখন")}</th>
                <th>{pick(lang, "Type", "ধরন")}</th>
                <th>{pick(lang, "Amount", "পরিমাণ")}</th>
                <th>{pick(lang, "Balance", "ব্যালেন্স")}</th>
                <th>{pick(lang, "Note", "নোট")}</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((row) => (
                <tr key={row.id}>
                  <td className="num">{formatDhaka(row.createdAt, lang)}</td>
                  <td>{statusLabel(lang, row.type)}</td>
                  <td className="num">{row.amount > 0 ? "+" : ""}{formatNumber(row.amount, lang)}</td>
                  <td className="num">{formatNumber(row.balanceAfter, lang)}</td>
                  <td>{row.note}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </>
  );
}

import Link from "next/link";
import type { Metadata } from "next";
import { SiteFooter, SiteHeader } from "@/components/chrome";
import { formatBdt, formatNumber } from "@/lib/format";
import { pick } from "@/lib/i18n";
import { getLang } from "@/lib/lang";
import { PACKS } from "@/lib/packs";

export const metadata: Metadata = { title: "Pricing" };

export default async function PricingPage() {
  const lang = await getLang();
  return (
    <>
      <SiteHeader lang={lang} />
      <main id="main" className="band">
        <div className="wrap">
          <p className="kicker">Kfyklab · Texter</p>
          <h1>{pick(lang, "Credits, not contracts.", "চুক্তি নয়, ক্রেডিট।")}</h1>
          <p className="lede">{pick(lang, "A segment is one SMS part. English holds 160 characters, Bangla holds 70. Checkout in this lab is simulated.", "এক সেগমেন্ট মানে এসএমএসের এক অংশ। ইংরেজিতে ১৬০, বাংলায় ৭০। এই ল্যাবে পেমেন্ট সিমুলেটেড।")}</p>
          <div className="price-grid" style={{ marginTop: 22 }}>
            {PACKS.map((pack) => (
              <article key={pack.id} className={pack.featured ? "price-card featured" : "price-card"}>
                {pack.featured ? <span className="tag">{pick(lang, "Usual", "সাধারণ")}</span> : null}
                <h2>{lang === "bn" ? pack.bn : pack.en}</h2>
                <div className="bdt">{formatBdt(pack.bdt, lang)}</div>
                <div className="credits">{formatNumber(pack.credits, lang)} SMS</div>
                <p>{lang === "bn" ? pack.noteBn : pack.noteEn}</p>
                <p className="fine">{(pack.bdt / pack.credits).toFixed(2)} BDT / SMS</p>
                <Link className={pack.featured ? "btn btn-teal" : "btn"} href="/register">{pick(lang, "Start an order", "অর্ডার শুরু")}</Link>
              </article>
            ))}
          </div>
        </div>
      </main>
      <SiteFooter lang={lang} />
    </>
  );
}

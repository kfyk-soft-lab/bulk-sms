import Link from "next/link";
import { redirect } from "next/navigation";
import type { Metadata } from "next";
import { RegisterForm } from "@/components/auth-forms";
import { LangSwitch } from "@/components/chrome";
import { Logo } from "@/components/logo";
import { getCurrentUser } from "@/lib/auth";
import { pick } from "@/lib/i18n";
import { getLang } from "@/lib/lang";

export const metadata: Metadata = { title: "Create a desk" };

export default async function RegisterPage() {
  const user = await getCurrentUser();
  if (user) redirect("/portal/order");
  const lang = await getLang();
  return (
    <main className="auth-grid">
      <section className="auth-brand">
        <div>
          <Logo dark />
          <h1 style={{ marginTop: 28 }}>{pick(lang, "A desk with 400 credits.", "৪০০ ক্রেডিটসহ একটি ডেস্ক।")}</h1>
          <p>{pick(lang, "TEXTER is approved as your first sender ID. Ask for your own when you are ready.", "প্রথম সেন্ডার আইডি হিসেবে TEXTER অনুমোদিত। নিজেরটা পরে চাইতে পারবেন।")}</p>
        </div>
        <img src="/brand/texter-mark.png" alt="Texter mark" style={{ width: 120, height: 120, borderRadius: 28 }} />
      </section>
      <section className="auth-card">
        <div className="row-actions" style={{ justifyContent: "space-between" }}>
          <Link href="/">{pick(lang, "Back", "ফিরে যান")}</Link>
          <LangSwitch lang={lang} />
        </div>
        <h2>{pick(lang, "Open an account", "অ্যাকাউন্ট খুলুন")}</h2>
        <RegisterForm lang={lang} />
        <p>{pick(lang, "Already have a desk?", "ডেস্ক আছে?")} <Link href="/login">{pick(lang, "Log in", "লগ ইন")}</Link></p>
      </section>
    </main>
  );
}

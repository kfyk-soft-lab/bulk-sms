"use client";

import { useState } from "react";
import { errorText, pick, type Lang } from "@/lib/i18n";

export function LoginForm({ lang, next }: { lang: Lang; next: string }) {
  const [error, setError] = useState("");
  const [pending, setPending] = useState(false);

  return (
    <form
      onSubmit={async (event) => {
        event.preventDefault();
        setPending(true);
        setError("");
        const form = new FormData(event.currentTarget);
        const res = await fetch("/api/auth/login", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ email: form.get("email"), password: form.get("password") }),
        });
        const data = (await res.json()) as { error?: string };
        setPending(false);
        if (!res.ok) {
          setError(errorText(lang, data.error ?? "bad_login"));
          return;
        }
        window.location.href = next;
      }}
    >
      {error ? <div className="form-error">{error}</div> : null}
      <label className="field">
        {pick(lang, "Email", "ইমেইল")}
        <input name="email" type="email" autoComplete="username" required placeholder="demo@kfyklab.com" />
      </label>
      <label className="field">
        {pick(lang, "Password", "পাসওয়ার্ড")}
        <input name="password" type="password" autoComplete="current-password" required />
      </label>
      <button className="btn btn-teal" type="submit" disabled={pending}>
        {pending ? pick(lang, "Opening…", "খুলছে…") : pick(lang, "Open the desk", "ডেস্ক খুলুন")}
      </button>
    </form>
  );
}

export function RegisterForm({ lang }: { lang: Lang }) {
  const [error, setError] = useState("");
  const [pending, setPending] = useState(false);

  return (
    <form
      onSubmit={async (event) => {
        event.preventDefault();
        setPending(true);
        setError("");
        const form = new FormData(event.currentTarget);
        const res = await fetch("/api/auth/register", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            name: form.get("name"),
            company: form.get("company"),
            phone: form.get("phone"),
            email: form.get("email"),
            password: form.get("password"),
          }),
        });
        const data = (await res.json()) as { error?: string };
        setPending(false);
        if (!res.ok) {
          setError(errorText(lang, data.error ?? "server"));
          return;
        }
        window.location.href = "/portal/order";
      }}
    >
      {error ? <div className="form-error">{error}</div> : null}
      <label className="field">
        {pick(lang, "Your name", "আপনার নাম")}
        <input name="name" required minLength={2} />
      </label>
      <div className="grid-2">
        <label className="field">
          {pick(lang, "Shop or company", "দোকান বা প্রতিষ্ঠান")}
          <input name="company" />
        </label>
        <label className="field">
          {pick(lang, "Mobile", "মোবাইল")}
          <input name="phone" placeholder="01XXXXXXXXX" />
        </label>
      </div>
      <label className="field">
        {pick(lang, "Email", "ইমেইল")}
        <input name="email" type="email" autoComplete="username" required />
      </label>
      <label className="field">
        {pick(lang, "Password", "পাসওয়ার্ড")}
        <input name="password" type="password" autoComplete="new-password" required minLength={8} />
      </label>
      <button className="btn btn-teal" type="submit" disabled={pending}>
        {pending ? pick(lang, "Creating desk…", "ডেস্ক তৈরি হচ্ছে…") : pick(lang, "Create desk · 400 credits", "ডেস্ক খুলুন · ৪০০ ক্রেডিট")}
      </button>
    </form>
  );
}

import Link from "next/link";
import { setLanguage } from "@/app/actions";
import type { SessionUser } from "@/lib/auth";
import { formatNumber } from "@/lib/format";
import { pick, type Lang } from "@/lib/i18n";
import { DeskNav } from "./desk-nav";
import { Logo } from "./logo";
import { LogoutButton } from "./logout-button";

export function LangSwitch({ lang, light = false }: { lang: Lang; light?: boolean }) {
  const next = lang === "en" ? "bn" : "en";
  return (
    <form action={setLanguage}>
      <input type="hidden" name="lang" value={next} />
      <button className={light ? "lang-btn light" : "lang-btn"} type="submit">
        {lang === "en" ? "বাংলা" : "EN"}
      </button>
    </form>
  );
}

export function SiteHeader({ lang }: { lang: Lang }) {
  return (
    <header className="site-header">
      <a className="skip" href="#main">
        {pick(lang, "Skip to content", "মূল অংশে যান")}
      </a>
      <div className="wrap bar">
        <Link href="/" aria-label="Texter home">
          <Logo />
        </Link>
        <nav className="nav-links">
          <a href="/#product">{pick(lang, "Product", "প্রোডাক্ট")}</a>
          <a href="/#schedule">{pick(lang, "Schedule", "সময়সূচি")}</a>
          <Link href="/pricing">{pick(lang, "Pricing", "মূল্য")}</Link>
        </nav>
        <div className="nav-actions">
          <LangSwitch lang={lang} />
          <Link className="btn btn-ghost btn-small" href="/login">
            {pick(lang, "Log in", "লগ ইন")}
          </Link>
          <Link className="btn btn-small" href="/register">
            {pick(lang, "Place an order", "অর্ডার দিন")}
          </Link>
        </div>
      </div>
    </header>
  );
}

export function SiteFooter({ lang }: { lang: Lang }) {
  return (
    <footer className="site-footer">
      <div className="wrap footer-grid">
        <div>
          <Logo />
          <p>
            {pick(
              lang,
              "Texter is Kfyklab’s order desk for bulk SMS. Lists come in. A timetable goes out. Messages leave when their minute opens.",
              "Texter হলো Kfyklab-এর বাল্ক এসএমএস অর্ডার ডেস্ক। তালিকা আসে, সময়সূচি তৈরি হয়, আর বার্তা যায় তার মিনিটে।",
            )}
          </p>
        </div>
        <div>
          <strong>{pick(lang, "Desk", "ডেস্ক")}</strong>
          <p><Link href="/login">{pick(lang, "Customer login", "কাস্টমার লগইন")}</Link></p>
          <p><Link href="/pricing">{pick(lang, "Credit packs", "ক্রেডিট প্যাক")}</Link></p>
          <p><Link href="/portal">{pick(lang, "Open portal", "পোর্টাল খুলুন")}</Link></p>
        </div>
        <div>
          <strong>Dhaka</strong>
          <p>Asia/Dhaka · +880</p>
          <p className="fine">
            {pick(
              lang,
              "Preview gateway is simulated. No live carrier handoff.",
              "এই প্রিভিউয়ের গেটওয়ে সিমুলেটেড। কোনো লাইভ অপারেটরে যায় না।",
            )}
          </p>
          <p className="fine">Photos: The.sahil.photography, Tranmautritam / Pexels</p>
        </div>
      </div>
    </footer>
  );
}

export function PortalFrame({
  user,
  lang,
  children,
}: {
  user: SessionUser;
  lang: Lang;
  children: React.ReactNode;
}) {
  return (
    <div className="portal">
      <aside className="side">
        <Link href="/portal" aria-label="Texter desk">
          <Logo dark />
        </Link>
        <DeskNav lang={lang} role={user.role} />
        <div className="side-foot">
          <Link href="/portal/wallet" className="credit-chip">
            <span>{pick(lang, "Credits", "ক্রেডিট")}</span>
            <strong className="num">{formatNumber(user.credits, lang)}</strong>
          </Link>
          <div className="who">
            <strong>{user.name}</strong>
            <div className="fine" style={{ color: "#b7c0cf" }}>{user.company ?? user.email}</div>
          </div>
          <LangSwitch lang={lang} light />
          <LogoutButton lang={lang} />
        </div>
      </aside>
      <div className="main">{children}</div>
    </div>
  );
}

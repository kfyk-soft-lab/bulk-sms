"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { pick, type Lang } from "@/lib/i18n";

export function DeskNav({ lang, role }: { lang: Lang; role: string }) {
  const path = usePathname();
  const items = [
    { href: "/portal", label: pick(lang, "Desk", "ডেস্ক") },
    { href: "/portal/order", label: pick(lang, "New order", "নতুন অর্ডার") },
    { href: "/portal/senders", label: pick(lang, "Sender IDs", "সেন্ডার আইডি") },
    { href: "/portal/wallet", label: pick(lang, "Wallet", "ওয়ালেট") },
    { href: "/portal/reports", label: pick(lang, "Reports", "রিপোর্ট") },
  ];
  if (role === "admin") items.push({ href: "/admin", label: pick(lang, "Operator", "অপারেটর") });

  return (
    <nav>
      {items.map((item) => {
        const active = item.href === "/portal" ? path === "/portal" : path === item.href || path.startsWith(`${item.href}/`);
        return (
          <Link key={item.href} href={item.href} className={active ? "active" : undefined}>
            {item.label}
          </Link>
        );
      })}
    </nav>
  );
}

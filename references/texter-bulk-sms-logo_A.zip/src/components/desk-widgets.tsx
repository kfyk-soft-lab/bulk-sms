"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { errorText, pick, type Lang } from "@/lib/i18n";
import { PACKS } from "@/lib/packs";
import { formatBdt, formatNumber } from "@/lib/format";

export function CampaignControls({
  lang,
  id,
  status,
}: {
  lang: Lang;
  id: string;
  status: string;
}) {
  const router = useRouter();
  const [pending, setPending] = useState("");

  async function act(action: string) {
    if (action === "cancel" && !window.confirm(pick(lang, "Cancel and refund unsent messages?", "বাতিল করে না-পাঠানো বার্তার ক্রেডিট ফেরত দেবেন?"))) return;
    setPending(action);
    await fetch(`/api/campaigns/${id}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action }),
    });
    setPending("");
    router.refresh();
  }

  return (
    <div className="row-actions no-print">
      {status === "scheduled" || status === "sending" ? (
        <button className="btn btn-ghost btn-small" type="button" disabled={!!pending} onClick={() => act("pause")}>
          {pick(lang, "Pause", "বিরতি")}
        </button>
      ) : null}
      {status === "paused" ? (
        <button className="btn btn-small" type="button" disabled={!!pending} onClick={() => act("resume")}>
          {pick(lang, "Resume", "চালিয়ে যান")}
        </button>
      ) : null}
      {status !== "completed" && status !== "cancelled" ? (
        <button className="btn btn-ghost btn-small" type="button" disabled={!!pending} onClick={() => act("cancel")}>
          {pick(lang, "Cancel unsent", "না-পাঠানো বাতিল")}
        </button>
      ) : null}
      <a className="btn btn-ghost btn-small" href={`/api/campaigns/${id}/export`}>
        {pick(lang, "Export CSV", "CSV নিন")}
      </a>
    </div>
  );
}

export function SenderForm({ lang }: { lang: Lang }) {
  const router = useRouter();
  const [label, setLabel] = useState("");
  const [error, setError] = useState("");
  const [pending, setPending] = useState(false);

  return (
    <form
      onSubmit={async (event) => {
        event.preventDefault();
        setPending(true);
        setError("");
        const res = await fetch("/api/senders", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ label }),
        });
        const data = (await res.json()) as { error?: string };
        setPending(false);
        if (!res.ok) {
          setError(errorText(lang, data.error ?? "server"));
          return;
        }
        setLabel("");
        router.refresh();
      }}
    >
      {error ? <div className="form-error">{error}</div> : null}
      <label className="field">
        {pick(lang, "Request a sender ID", "সেন্ডার আইডি চাই")}
        <span>{pick(lang, "3–11 letters or numbers. Kfyklab approves it before use.", "৩–১১ অক্ষর। ব্যবহারের আগে Kfyklab অনুমোদন করে।")}</span>
        <input value={label} onChange={(event) => setLabel(event.target.value.toUpperCase())} placeholder="BANANI" maxLength={11} />
      </label>
      <button className="btn btn-small" type="submit" disabled={pending}>
        {pick(lang, "Submit request", "অনুরোধ পাঠান")}
      </button>
    </form>
  );
}

export function WalletPanel({ lang }: { lang: Lang }) {
  const router = useRouter();
  const [packId, setPackId] = useState("counter");
  const [pending, setPending] = useState(false);
  const [note, setNote] = useState("");
  const [error, setError] = useState("");
  const pack = PACKS.find((item) => item.id === packId) ?? PACKS[1];

  return (
    <div>
      <div className="price-grid">
        {PACKS.map((item) => (
          <button
            key={item.id}
            type="button"
            className={item.id === packId ? "price-card featured" : "price-card"}
            onClick={() => setPackId(item.id)}
          >
            <strong>{lang === "bn" ? item.bn : item.en}</strong>
            <span className="credits">{formatNumber(item.credits, lang)} SMS</span>
            <span className="bdt">{formatBdt(item.bdt, lang)}</span>
            <span className="fine">{lang === "bn" ? item.noteBn : item.noteEn}</span>
          </button>
        ))}
      </div>
      <div className="panel" style={{ marginTop: 16 }}>
        <h2>{pick(lang, "Simulated checkout", "সিমুলেটেড পেমেন্ট")}</h2>
        <p>
          {pick(lang, "bKash / card is not charged. Confirm to add lab credits instantly.", "bKash বা কার্ড থেকে টাকা কাটা হবে না। নিশ্চিত করলেই ল্যাব ক্রেডিট যোগ হবে।")}
        </p>
        {error ? <div className="form-error">{error}</div> : null}
        {note ? <p className="notice">{note}</p> : null}
        <button
          className="btn btn-teal"
          type="button"
          disabled={pending}
          onClick={async () => {
            setPending(true);
            setError("");
            const res = await fetch("/api/wallet", {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({ packId }),
            });
            const data = (await res.json()) as { error?: string; reference?: string; credits?: number };
            setPending(false);
            if (!res.ok) {
              setError(errorText(lang, data.error ?? "server"));
              return;
            }
            setNote(`${pick(lang, "Paid", "পরিশোধ")} ${data.reference} · ${formatNumber(data.credits ?? pack.credits, lang)}`);
            router.refresh();
          }}
        >
          {pending
            ? pick(lang, "Clearing…", "হচ্ছে…")
            : `${pick(lang, "Pay", "পরিশোধ")} ${formatBdt(pack.bdt, lang)}`}
        </button>
      </div>
    </div>
  );
}

export function AdminActions({
  lang,
  senderId,
  userId,
}: {
  lang: Lang;
  senderId?: string;
  userId?: string;
}) {
  const router = useRouter();
  const [amount, setAmount] = useState(500);
  const [pending, setPending] = useState(false);

  if (senderId) {
    return (
      <div className="row-actions">
        {["approved", "rejected", "pending"].map((status) => (
          <button
            key={status}
            className="btn btn-ghost btn-small"
            type="button"
            onClick={async () => {
              await fetch("/api/admin/senders", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ id: senderId, status }),
              });
              router.refresh();
            }}
          >
            {status}
          </button>
        ))}
      </div>
    );
  }

  return (
    <form
      className="row-actions"
      onSubmit={async (event) => {
        event.preventDefault();
        setPending(true);
        await fetch("/api/admin/credits", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ userId, amount, note: "Operator adjustment" }),
        });
        setPending(false);
        router.refresh();
      }}
    >
      <input style={{ width: 90 }} type="number" value={amount} onChange={(event) => setAmount(Number(event.target.value))} />
      <button className="btn btn-small" type="submit" disabled={pending}>
        {pick(lang, "Adjust", "সমন্বয়")}
      </button>
    </form>
  );
}

"use client";

import { useEffect } from "react";
import { useRouter } from "next/navigation";

export function LiveDispatch({ active }: { active: boolean }) {
  const router = useRouter();
  useEffect(() => {
    if (!active) return;
    let stopped = false;
    const tick = async () => {
      try {
        const res = await fetch("/api/dispatch", { method: "POST" });
        const data = (await res.json()) as { processed?: number };
        if (!stopped && data.processed && data.processed > 0) router.refresh();
      } catch {
        // gateway tick can fail quietly; the next interval retries
      }
    };
    const timer = window.setInterval(tick, 4000);
    void tick();
    return () => {
      stopped = true;
      window.clearInterval(timer);
    };
  }, [active, router]);
  return null;
}

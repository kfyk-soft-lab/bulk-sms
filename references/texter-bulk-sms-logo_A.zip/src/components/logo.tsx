export function Mark({ size = 42, title = "Texter" }: { size?: number; title?: string }) {
  return (
    <svg width={size} height={size} viewBox="0 0 80 80" role="img" aria-label={title}>
      <rect width="80" height="80" rx="18" fill="#0E1628" />
      <rect x="12" y="18" width="56" height="16" rx="8" fill="#F6E6C4" />
      <rect x="30" y="31" width="7" height="33" rx="3.5" fill="#F6E6C4" />
      <circle cx="33.5" cy="32.5" r="5.2" fill="#E4532F" />
      <rect x="42" y="46" width="7" height="18" rx="3.5" fill="#14A89A" />
      <rect x="52" y="38" width="7" height="26" rx="3.5" fill="#14A89A" />
      <rect x="62" y="30" width="7" height="34" rx="3.5" fill="#14A89A" />
    </svg>
  );
}

export function Logo({
  size = 42,
  word = true,
  dark = false,
}: {
  size?: number;
  word?: boolean;
  dark?: boolean;
}) {
  return (
    <span className={dark ? "logo on-dark" : "logo"}>
      <Mark size={size} />
      {word ? (
        <span className="logo-words">
          <strong>Texter</strong>
          <small>Kfyklab</small>
        </span>
      ) : null}
    </span>
  );
}

"use client";

import { pick, type Lang } from "@/lib/i18n";

export function LogoutButton({ lang }: { lang: Lang }) {
  return (
    <button
      className="btn btn-line btn-small"
      type="button"
      onClick={async () => {
        await fetch("/api/auth/logout", { method: "POST" });
        window.location.href = "/login";
      }}
    >
      {pick(lang, "Log out", "লগ আউট")}
    </button>
  );
}

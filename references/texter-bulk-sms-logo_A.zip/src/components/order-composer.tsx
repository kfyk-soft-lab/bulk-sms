"use client";

import Link from "next/link";
import { useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { formatDhaka, formatNumber } from "@/lib/format";
import { errorText, pick, statusLabel, type Lang } from "@/lib/i18n";
import {
  analyzeMessage,
  bucketSlots,
  nextDhakaHour,
  parseAudience,
  planSchedule,
  renderMessage,
  toDhakaInput,
  type ScheduleMode,
  type WeekendMode,
} from "@/lib/sms";

const SAMPLE = `01700001001, Karim
01811001002, Nusrat
01912001003, Rafi
01613001004, Mitu
01514001005, Hasan
01315001006, Lima
01700001007
01811001008, Shop 8
01912001009
01613001010, Counter`;

export function OrderComposer({
  lang,
  credits,
  senders,
}: {
  lang: Lang;
  credits: number;
  senders: { label: string }[];
}) {
  const router = useRouter();
  const [name, setName] = useState(lang === "bn" ? "কাউন্টার নোটিশ" : "Counter notice");
  const [senderId, setSenderId] = useState(senders[0]?.label ?? "");
  const [message, setMessage] = useState("");
  const [audience, setAudience] = useState("");
  const [mode, setMode] = useState<ScheduleMode>("generated");
  const [startLocal, setStartLocal] = useState(() => toDhakaInput(nextDhakaHour()));
  const [endLocal, setEndLocal] = useState(() => toDhakaInput(new Date(nextDhakaHour().getTime() + 4 * 24 * 60 * 60 * 1000)));
  const [windowStart, setWindowStart] = useState("09:00");
  const [windowEnd, setWindowEnd] = useState("20:00");
  const [perMinute, setPerMinute] = useState(40);
  const [skipWeekend, setSkipWeekend] = useState(true);
  const [weekendMode, setWeekendMode] = useState<WeekendMode>("bd");
  const [pending, setPending] = useState(false);
  const [error, setError] = useState("");

  const parsed = useMemo(() => parseAudience(audience), [audience]);
  const analysis = useMemo(() => analyzeMessage(message), [message]);
  const plan = useMemo(() => {
    if (!parsed.valid.length) return null;
    return planSchedule({
      mode,
      count: parsed.valid.length,
      perMinute,
      startLocal,
      endLocal,
      windowStart,
      windowEnd,
      skipWeekend,
      weekendMode,
    });
  }, [endLocal, mode, parsed.valid.length, perMinute, skipWeekend, startLocal, weekendMode, windowEnd, windowStart]);

  const cost = parsed.valid.length * analysis.segments;
  const cap = analysis.segments <= 1 ? analysis.single : analysis.segments * analysis.multi;
  const ratio = cap ? Math.min(100, Math.round((analysis.length / cap) * 100)) : 0;
  const optOut = /stop|unsubscribe|বাতিল/i.test(message);
  const preview = renderMessage(message || pick(lang, "Your message will sit here.", "আপনার বার্তা এখানে বসবে।"), parsed.valid[0]?.name);
  const bars = plan?.ok ? bucketSlots(plan.slots, plan.slots.length > 18 ? 60 : 15).slice(0, 12) : [];
  const maxBar = Math.max(...bars.map((bar) => bar.count), 1);
  const blockers = [
    !name.trim() ? "name_required" : "",
    !senderId ? "sender_not_approved" : "",
    !message.trim() ? "message_required" : "",
    analysis.segments > 6 ? "message_too_long" : "",
    !parsed.valid.length ? "no_recipients" : "",
    parsed.valid.length > 2000 ? "too_many_recipients" : "",
    plan && !plan.ok ? plan.error : "",
    cost > credits ? "insufficient_credits" : "",
  ].filter(Boolean);

  return (
    <div className="composer">
      <form
        className="panel"
        onSubmit={async (event) => {
          event.preventDefault();
          if (blockers.length || !plan?.ok) {
            setError(errorText(lang, blockers[0] || "bad_schedule"));
            return;
          }
          setPending(true);
          setError("");
          const res = await fetch("/api/campaigns", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              name,
              senderId,
              message,
              audience,
              mode,
              startLocal,
              endLocal,
              windowStart,
              windowEnd,
              perMinute,
              skipWeekend,
              weekendMode,
            }),
          });
          const data = (await res.json()) as { error?: string; id?: string };
          setPending(false);
          if (!res.ok || !data.id) {
            setError(errorText(lang, data.error ?? "server"));
            return;
          }
          router.push(`/portal/campaigns/${data.id}`);
          router.refresh();
        }}
      >
        <h2>{pick(lang, "Order ticket", "অর্ডার টিকিট")}</h2>
        <p className="hint">{pick(lang, "Times are Asia/Dhaka, even if your browser is elsewhere.", "সময় সবসময় ঢাকার, ব্রাউজার অন্য দেশে থাকলেও।")}</p>
        {error ? <div className="form-error">{error}</div> : null}
        <div className="grid-2">
          <label className="field">
            {pick(lang, "Order name", "অর্ডারের নাম")}
            <input value={name} onChange={(event) => setName(event.target.value)} maxLength={80} required />
          </label>
          <label className="field">
            {pick(lang, "Sender ID", "সেন্ডার আইডি")}
            <select value={senderId} onChange={(event) => setSenderId(event.target.value)}>
              {senders.length === 0 ? <option value="">{pick(lang, "No approved sender", "অনুমোদিত সেন্ডার নেই")}</option> : null}
              {senders.map((sender) => (
                <option key={sender.label} value={sender.label}>{sender.label}</option>
              ))}
            </select>
          </label>
        </div>
        <label className="field">
          {pick(lang, "Message", "বার্তা")}
          <span>{pick(lang, "Use {name} if the list has names.", "তালিকায় নাম থাকলে {name} ব্যবহার করুন।")}</span>
          <textarea value={message} onChange={(event) => setMessage(event.target.value)} maxLength={1000} placeholder={pick(lang, "Write in English or Bangla.", "ইংরেজি বা বাংলায় লিখুন।")} />
        </label>
        <div className="row-actions" style={{ marginBottom: 12 }}>
          <button
            className="btn btn-ghost btn-small"
            type="button"
            onClick={() =>
              setMessage(
                lang === "bn"
                  ? "{name}, আপনার অর্ডার বনানী কাউন্টারে রাত ৮টা পর্যন্ত রাখা আছে। বাতিল করতে STOP লিখে রিপ্লাই করুন।"
                  : "{name}, your order is at the Banani counter until 8pm. Reply STOP to opt out.",
              )
            }
          >
            {pick(lang, "Sample text", "নমুনা বার্তা")}
          </button>
          <span className="pill">{analysis.encoding === "unicode" ? "Unicode" : "GSM"}</span>
          <span className="num hint">
            {analysis.length} · {analysis.segments} {pick(lang, "segments", "সেগমেন্ট")}
          </span>
        </div>
        <div className={analysis.segments > 2 ? "meter warn" : "meter"} style={{ marginBottom: 14 }}>
          <span style={{ width: `${ratio}%` }} />
        </div>
        {!optOut && message.trim() ? (
          <p className="notice">{pick(lang, "Promo texts in Bangladesh usually carry an opt-out such as STOP. This is a hint, not a block.", "বাংলাদেশে প্রোমো এসএমএসে সাধারণত STOP-এর মতো অপ্ট-আউট থাকে। এটা শুধু ইঙ্গিত, বাধা নয়।")}</p>
        ) : null}
        <label className="field">
          {pick(lang, "Audience", "দর্শক")}
          <span>{pick(lang, "One number per line. Optional name after a comma. 01… or +880…", "প্রতি লাইনে একটি নম্বর। কমা দিয়ে নাম দিতে পারেন। ০১… বা +৮৮০…")}</span>
          <textarea value={audience} onChange={(event) => setAudience(event.target.value)} placeholder="017XXXXXXXX, Karim" />
        </label>
        <button className="btn btn-ghost btn-small" type="button" onClick={() => setAudience(SAMPLE)}>
          {pick(lang, "Load sample numbers", "নমুনা নম্বর বসান")}
        </button>
        <p className="hint">
          {formatNumber(parsed.valid.length, lang)} {pick(lang, "valid", "বৈধ")}
          {parsed.invalid.length ? ` · ${formatNumber(parsed.invalid.length, lang)} ${pick(lang, "skipped", "বাদ")}` : ""}
        </p>
        {parsed.invalid.slice(0, 3).map((row) => (
          <p key={row} className="hint" style={{ color: "var(--fail)" }}>{row}</p>
        ))}

        <h3 style={{ marginTop: 18 }}>{pick(lang, "How should it leave?", "কীভাবে যাবে?")}</h3>
        <div className="modes" role="radiogroup">
          {(
            [
              ["instant", pick(lang, "Instant", "এখনই"), pick(lang, "Start this minute, paced.", "এই মিনিট থেকে, গতি মেনে।")],
              ["fixed", pick(lang, "Fixed start", "নির্দিষ্ট সময়"), pick(lang, "All begin at one clock time.", "সবাই এক সময় থেকে শুরু।")],
              ["generated", pick(lang, "Generated", "তৈরি সূচি"), pick(lang, "Spread across your window.", "আপনার উইন্ডোতে ছড়িয়ে।")],
            ] as const
          ).map(([value, title, detail]) => (
            <button key={value} type="button" className={mode === value ? "mode on" : "mode"} onClick={() => setMode(value)} aria-pressed={mode === value}>
              <strong>{title}</strong>
              <small>{detail}</small>
            </button>
          ))}
        </div>
        {mode !== "instant" ? (
          <div className="grid-2">
            <label className="field">
              {pick(lang, "Start (Dhaka)", "শুরু (ঢাকা)")}
              <input type="datetime-local" value={startLocal} onChange={(event) => setStartLocal(event.target.value)} />
            </label>
            {mode === "generated" ? (
              <label className="field">
                {pick(lang, "Finish by (Dhaka)", "শেষ (ঢাকা)")}
                <input type="datetime-local" value={endLocal} onChange={(event) => setEndLocal(event.target.value)} />
              </label>
            ) : null}
          </div>
        ) : null}
        {mode === "generated" ? (
          <>
            <div className="grid-2">
              <label className="field">
                {pick(lang, "Daily window from", "দৈনিক উইন্ডো শুরু")}
                <input type="time" value={windowStart} onChange={(event) => setWindowStart(event.target.value)} />
              </label>
              <label className="field">
                {pick(lang, "Daily window to", "দৈনিক উইন্ডো শেষ")}
                <input type="time" value={windowEnd} onChange={(event) => setWindowEnd(event.target.value)} />
              </label>
            </div>
            <label className="check">
              <input type="checkbox" checked={skipWeekend} onChange={(event) => setSkipWeekend(event.target.checked)} />
              {pick(lang, "Skip weekend", "সাপ্তাহিক ছুটি বাদ")}
            </label>
            <label className="field">
              {pick(lang, "Weekend", "ছুটির দিন")}
              <select value={weekendMode} onChange={(event) => setWeekendMode(event.target.value as WeekendMode)}>
                <option value="bd">{pick(lang, "Bangladesh · Friday & Saturday", "বাংলাদেশ · শুক্র ও শনি")}</option>
                <option value="west">{pick(lang, "Saturday & Sunday", "শনি ও রবি")}</option>
              </select>
            </label>
          </>
        ) : null}
        <label className="field">
          {pick(lang, "Gateway pace (messages / minute)", "গেটওয়ে গতি (বার্তা / মিনিট)")}
          <input type="number" min={1} max={300} value={perMinute} onChange={(event) => setPerMinute(Number(event.target.value))} />
        </label>
        <button className="btn btn-teal" type="submit" disabled={pending || blockers.length > 0}>
          {pending
            ? pick(lang, "Placing order…", "অর্ডার হচ্ছে…")
            : `${pick(lang, "Place order", "অর্ডার দিন")} · ${formatNumber(cost || 0, lang)}`}
        </button>
      </form>

      <aside className="ticket ticket-sticky">
        <h2>{pick(lang, "Receipt preview", "রসিদ প্রিভিউ")}</h2>
        <div className="phone">
          <div className="from">{senderId || "TEXTER"}</div>
          <div className="bubble">{preview}</div>
        </div>
        <p><span className="hint">{pick(lang, "Encoding", "এনকোডিং")}</span><br />{analysis.encoding === "unicode" ? "Unicode · 70/67" : "GSM · 160/153"}</p>
        <p><span className="hint">{pick(lang, "Audience", "দর্শক")}</span><br /><span className="num">{formatNumber(parsed.valid.length, lang)}</span></p>
        <p><span className="hint">{pick(lang, "Credit cost", "ক্রেডিট খরচ")}</span><br /><span className="num">{formatNumber(cost || 0, lang)}</span></p>
        <p><span className="hint">{pick(lang, "Balance after", "পরে থাকবে")}</span><br /><span className="num">{formatNumber(credits - (cost || 0), lang)}</span></p>
        {plan?.ok ? (
          <>
            <p className="hint">
              {formatDhaka(plan.startsAt, lang)} → {formatDhaka(plan.endsAt, lang)} · {formatNumber(plan.slots.length, lang)} {pick(lang, "slots", "স্লট")}
            </p>
            <div className="timeline" aria-hidden>
              {bars.map((bar) => (
                <div className="tl-col" key={bar.at}>
                  <div className="tl-stack">
                    <div className="tl-queued" style={{ height: `${(bar.count / maxBar) * 100}%` }} />
                  </div>
                  <span>{formatDhaka(bar.at, "en", false)}</span>
                </div>
              ))}
            </div>
          </>
        ) : plan && !plan.ok ? (
          <p className="notice">
            {errorText(lang, plan.error)}
            {plan.capacity ? ` (${formatNumber(plan.capacity, lang)})` : ""}
          </p>
        ) : null}
        {blockers.includes("insufficient_credits") ? (
          <p><Link className="btn btn-small" href="/portal/wallet">{pick(lang, "Load credits", "ক্রেডিট নিন")}</Link></p>
        ) : null}
        <p className="fine">{statusLabel(lang, mode)} · {pick(lang, "Sandbox gateway. Nothing reaches a handset.", "স্যান্ডবক্স গেটওয়ে। কোনো হ্যান্ডসেটে যায় না।")}</p>
      </aside>
    </div>
  );
}

"use client";

import { useMemo, useState } from "react";
import { dhakaHourLabel, formatNumber } from "@/lib/format";
import { pick, type Lang } from "@/lib/i18n";
import { bucketSlots, planSchedule, toDhakaInput } from "@/lib/sms";

export function PaceSketch({ lang }: { lang: Lang }) {
  const [count, setCount] = useState(480);
  const [pace, setPace] = useState(30);
  const range = useMemo(() => {
    const start = new Date(Date.now() + 15 * 60 * 1000);
    const end = new Date(Date.now() + 6 * 24 * 60 * 60 * 1000);
    return { start: toDhakaInput(start), end: toDhakaInput(end) };
  }, []);
  const plan = useMemo(
    () =>
      planSchedule({
        mode: "generated",
        count,
        perMinute: pace,
        startLocal: range.start,
        endLocal: range.end,
        windowStart: "09:00",
        windowEnd: "20:00",
        skipWeekend: true,
        weekendMode: "bd",
      }),
    [count, pace, range.end, range.start],
  );
  const bars = plan.ok ? bucketSlots(plan.slots, 60).slice(0, 10) : [];
  const max = Math.max(...bars.map((bar) => bar.count), 1);

  return (
    <div className="desk-card" id="schedule">
      <header>
        <div>
          <strong>{pick(lang, "Generated timetable", "তৈরি সময়সূচি")}</strong>
          <p>{pick(lang, "09:00–20:00 Dhaka · skip Fri–Sat", "ঢাকা ০৯:০০–২০:০০ · শুক্র–শনি বাদ")}</p>
        </div>
        <span className="pill">{plan.ok ? pick(lang, "Ready", "প্রস্তুত") : pick(lang, "Too tight", "জায়গা কম")}</span>
      </header>
      <div className="bars" aria-hidden>
        {bars.map((bar) => (
          <div className="bar-col" key={bar.at}>
            <div className="bar" style={{ height: `${Math.max(8, (bar.count / max) * 150)}px` }} />
            <span>{dhakaHourLabel(bar.at, "en").split(",")[0]}</span>
          </div>
        ))}
      </div>
      <div className="sketch-controls">
        <label>
          {pick(lang, "Numbers", "নম্বর")} · <span className="num">{formatNumber(count, lang)}</span>
          <input type="range" min={40} max={1800} step={20} value={count} onChange={(event) => setCount(Number(event.target.value))} />
        </label>
        <label>
          {pick(lang, "Pace / min", "প্রতি মিনিট")} · <span className="num">{pace}</span>
          <input type="range" min={5} max={120} step={5} value={pace} onChange={(event) => setPace(Number(event.target.value))} />
        </label>
      </div>
    </div>
  );
}

import { boolean, integer, pgTable, text, timestamp } from "drizzle-orm/pg-core";

export const users = pgTable("users", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull().unique(),
  passwordHash: text("password_hash").notNull(),
  company: text("company"),
  phone: text("phone"),
  role: text("role").notNull().default("customer"),
  credits: integer("credits").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const sessions = pgTable("sessions", {
  id: text("id").primaryKey(),
  userId: text("user_id")
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  token: text("token").notNull().unique(),
  expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const senderIds = pgTable("sender_ids", {
  id: text("id").primaryKey(),
  userId: text("user_id")
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  label: text("label").notNull(),
  status: text("status").notNull().default("pending"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const campaigns = pgTable("campaigns", {
  id: text("id").primaryKey(),
  userId: text("user_id")
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  name: text("name").notNull(),
  senderLabel: text("sender_label").notNull(),
  message: text("message").notNull(),
  encoding: text("encoding").notNull(),
  segments: integer("segments").notNull(),
  status: text("status").notNull().default("scheduled"),
  scheduleMode: text("schedule_mode").notNull(),
  windowStart: text("window_start"),
  windowEnd: text("window_end"),
  perMinute: integer("per_minute").notNull().default(40),
  skipWeekend: boolean("skip_weekend").notNull().default(false),
  weekendMode: text("weekend_mode").notNull().default("bd"),
  scheduleLabel: text("schedule_label"),
  startsAt: timestamp("starts_at", { withTimezone: true }),
  endsAt: timestamp("ends_at", { withTimezone: true }),
  totalRecipients: integer("total_recipients").notNull().default(0),
  sentCount: integer("sent_count").notNull().default(0),
  deliveredCount: integer("delivered_count").notNull().default(0),
  failedCount: integer("failed_count").notNull().default(0),
  creditCost: integer("credit_cost").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const recipients = pgTable("recipients", {
  id: text("id").primaryKey(),
  campaignId: text("campaign_id")
    .notNull()
    .references(() => campaigns.id, { onDelete: "cascade" }),
  phone: text("phone").notNull(),
  name: text("name"),
  status: text("status").notNull().default("queued"),
  scheduledAt: timestamp("scheduled_at", { withTimezone: true }).notNull(),
  sentAt: timestamp("sent_at", { withTimezone: true }),
  providerRef: text("provider_ref"),
  error: text("error"),
});

export const scheduleSlots = pgTable("schedule_slots", {
  id: text("id").primaryKey(),
  campaignId: text("campaign_id")
    .notNull()
    .references(() => campaigns.id, { onDelete: "cascade" }),
  slotIndex: integer("slot_index").notNull(),
  startsAt: timestamp("starts_at", { withTimezone: true }).notNull(),
  recipientCount: integer("recipient_count").notNull(),
  status: text("status").notNull().default("pending"),
});

export const ledger = pgTable("ledger", {
  id: text("id").primaryKey(),
  userId: text("user_id")
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  type: text("type").notNull(),
  amount: integer("amount").notNull(),
  balanceAfter: integer("balance_after").notNull(),
  note: text("note"),
  campaignId: text("campaign_id"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

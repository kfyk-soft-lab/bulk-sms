import { randomBytes } from "crypto";
import { and, asc, eq, inArray, lte, sql } from "drizzle-orm";
import { db } from "@/db";
import { campaigns, recipients } from "@/db/schema";

async function refreshCampaign(campaignId: string) {
  const [stats] = await db
    .select({
      delivered: sql<number>`count(*) filter (where ${recipients.status} = 'delivered')::int`,
      failed: sql<number>`count(*) filter (where ${recipients.status} = 'failed')::int`,
      queued: sql<number>`count(*) filter (where ${recipients.status} = 'queued')::int`,
    })
    .from(recipients)
    .where(eq(recipients.campaignId, campaignId));
  const delivered = Number(stats?.delivered ?? 0);
  const failed = Number(stats?.failed ?? 0);
  const queued = Number(stats?.queued ?? 0);
  const status = queued === 0 ? "completed" : "sending";
  await db
    .update(campaigns)
    .set({
      deliveredCount: delivered,
      failedCount: failed,
      sentCount: delivered + failed,
      status,
    })
    .where(and(eq(campaigns.id, campaignId), inArray(campaigns.status, ["scheduled", "sending"])));
}

export async function processDue(userId: string, isAdmin: boolean, limit = 50) {
  const cap = Math.max(1, Math.min(200, limit));
  const filters = [
    eq(recipients.status, "queued"),
    lte(recipients.scheduledAt, new Date()),
    inArray(campaigns.status, ["scheduled", "sending"]),
  ];
  if (!isAdmin) filters.push(eq(campaigns.userId, userId));

  const due = await db
    .select({ id: recipients.id, campaignId: recipients.campaignId })
    .from(recipients)
    .innerJoin(campaigns, eq(recipients.campaignId, campaigns.id))
    .where(and(...filters))
    .orderBy(asc(recipients.scheduledAt))
    .limit(cap);

  const touched = new Set<string>();
  let processed = 0;
  for (const row of due) {
    const failed = Math.random() < 0.035;
    const updated = await db
      .update(recipients)
      .set({
        status: failed ? "failed" : "delivered",
        sentAt: new Date(),
        providerRef: `KFY-${randomBytes(4).toString("hex").toUpperCase()}`,
        error: failed ? "Carrier rejected" : null,
      })
      .where(and(eq(recipients.id, row.id), eq(recipients.status, "queued")))
      .returning({ id: recipients.id });
    if (updated.length) {
      processed += 1;
      touched.add(row.campaignId);
    }
  }
  for (const campaignId of touched) {
    await refreshCampaign(campaignId);
  }
  return processed;
}

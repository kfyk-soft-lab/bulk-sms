export type Lang = "en" | "bn";

export function pick(lang: Lang, en: string, bn: string) {
  return lang === "bn" ? bn : en;
}

const STATUS: Record<string, { en: string; bn: string }> = {
  scheduled: { en: "Scheduled", bn: "নির্ধারিত" },
  sending: { en: "Sending", bn: "পাঠানো হচ্ছে" },
  paused: { en: "Paused", bn: "বিরতি" },
  completed: { en: "Completed", bn: "সম্পন্ন" },
  cancelled: { en: "Cancelled", bn: "বাতিল" },
  queued: { en: "Queued", bn: "সারিতে" },
  delivered: { en: "Delivered", bn: "পৌঁছেছে" },
  failed: { en: "Failed", bn: "ব্যর্থ" },
  sent: { en: "Sent", bn: "পাঠানো" },
  pending: { en: "Pending", bn: "অপেক্ষমাণ" },
  approved: { en: "Approved", bn: "অনুমোদিত" },
  rejected: { en: "Rejected", bn: "প্রত্যাখ্যাত" },
  instant: { en: "Instant blast", bn: "এখনই পাঠান" },
  fixed: { en: "Fixed start", bn: "নির্দিষ্ট সময়" },
  generated: { en: "Generated pace", bn: "তৈরি সময়সূচি" },
  purchase: { en: "Purchase", bn: "ক্রয়" },
  debit: { en: "Debit", bn: "খরচ" },
  refund: { en: "Refund", bn: "ফেরত" },
  grant: { en: "Grant", bn: "উপহার" },
};

export function statusLabel(lang: Lang, status: string) {
  return STATUS[status]?.[lang] ?? status;
}

const ERRORS: Record<string, { en: string; bn: string }> = {
  auth: { en: "Please log in again.", bn: "আবার লগ ইন করুন।" },
  bad_login: { en: "Email or password does not match.", bn: "ইমেইল বা পাসওয়ার্ড মিলছে না।" },
  email_taken: { en: "That email already has a desk.", bn: "এই ইমেইলে আগেই অ্যাকাউন্ট আছে।" },
  bad_email: { en: "Enter a valid email.", bn: "সঠিক ইমেইল দিন।" },
  bad_password: { en: "Password needs at least 8 characters.", bn: "পাসওয়ার্ড অন্তত ৮ অক্ষরের হতে হবে।" },
  bad_name: { en: "Name is too short.", bn: "নাম আরও একটু বড় করে লিখুন।" },
  name_required: { en: "Give this order a name.", bn: "অর্ডারের একটি নাম দিন।" },
  sender_not_approved: { en: "Pick an approved sender ID.", bn: "অনুমোদিত সেন্ডার আইডি বেছে নিন।" },
  message_required: { en: "Write the message first.", bn: "আগে বার্তাটি লিখুন।" },
  message_too_long: { en: "Message is over 6 segments. Shorten it.", bn: "বার্তা ৬ সেগমেন্টের বেশি। ছেঁটে নিন।" },
  no_recipients: { en: "No valid numbers in the audience.", bn: "দর্শক তালিকায় কোনো বৈধ নম্বর নেই।" },
  too_many_recipients: { en: "This desk accepts up to 2,000 numbers per order.", bn: "এক অর্ডারে সর্বোচ্চ ২,০০০ নম্বর।" },
  bad_schedule: { en: "The schedule times are not valid.", bn: "সময়সূচির সময় সঠিক নয়।" },
  end_before_start: { en: "Finish time must be after the start.", bn: "শেষ সময় শুরুর পরে হতে হবে।" },
  window_empty: { en: "No sending minute falls inside that window.", bn: "এই উইন্ডোতে পাঠানোর কোনো মিনিট নেই।" },
  pace_too_tight: { en: "The window cannot hold this list at that pace.", bn: "এই গতিতে উইন্ডোতে এত নম্বর ধরে না।" },
  insufficient_credits: { en: "Not enough credits for this order.", bn: "এই অর্ডারের জন্য ক্রেডিট যথেষ্ট নয়।" },
  bad_sender: { en: "Sender ID must be 3–11 letters or numbers, starting with a letter.", bn: "সেন্ডার আইডি ৩–১১ অক্ষর, অক্ষর দিয়ে শুরু।" },
  sender_exists: { en: "You already requested that sender ID.", bn: "এই সেন্ডার আইডি আগেই চাওয়া হয়েছে।" },
  bad_pack: { en: "Unknown credit pack.", bn: "ক্রেডিট প্যাক চেনা যায়নি।" },
  forbidden: { en: "That desk is not yours.", bn: "এই ডেস্ক আপনার নয়।" },
  not_found: { en: "Order not found.", bn: "অর্ডার পাওয়া যায়নি।" },
  bad_action: { en: "That action is not available.", bn: "এই কাজটি এখন করা যাবে না।" },
  server: { en: "The desk hit a snag. Try again.", bn: "ডেস্কে একটু গন্ডগোল হয়েছে। আবার চেষ্টা করুন।" },
};

export function errorText(lang: Lang, code: string) {
  return ERRORS[code]?.[lang] ?? ERRORS[code]?.en ?? code;
}

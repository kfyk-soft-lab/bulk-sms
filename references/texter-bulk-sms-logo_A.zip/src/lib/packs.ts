export const PACKS = [
  {
    id: "starter",
    credits: 1000,
    bdt: 850,
    en: "Starter",
    bn: "স্টার্টার",
    noteEn: "A week of reminders",
    noteBn: "এক সপ্তাহের রিমাইন্ডার",
    featured: false,
  },
  {
    id: "counter",
    credits: 5000,
    bdt: 3750,
    en: "Counter",
    bn: "কাউন্টার",
    noteEn: "Where most shops begin",
    noteBn: "বেশিরভাগ দোকান এখান থেকে",
    featured: true,
  },
  {
    id: "floor",
    credits: 20000,
    bdt: 12800,
    en: "Shop floor",
    bn: "শপ ফ্লোর",
    noteEn: "Sales pushes and dues",
    noteBn: "সেল আর বকেয়া আদায়",
    featured: false,
  },
  {
    id: "lab",
    credits: 100000,
    bdt: 54000,
    en: "Lab",
    bn: "ল্যাব",
    noteEn: "Chains and networks",
    noteBn: "চেইন ও নেটওয়ার্ক",
    featured: false,
  },
] as const;

export type PackId = (typeof PACKS)[number]["id"];

export function findPack(id: string) {
  return PACKS.find((pack) => pack.id === id) ?? null;
}

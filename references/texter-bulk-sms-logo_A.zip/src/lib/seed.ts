import { randomUUID } from "crypto";
import { and, asc, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { campaigns, ledger, recipients, scheduleSlots, senderIds, users } from "@/db/schema";
import { hashPassword } from "./password";
import { planSchedule, toDhakaInput } from "./sms";

let seedPromise: Promise<void> | null = null;

export function ensureSeed() {
  if (!seedPromise) {
    seedPromise = runSeed().catch((error) => {
      seedPromise = null;
      throw error;
    });
  }
  return seedPromise;
}

async function upsertUser(input: {
  email: string;
  name: string;
  password: string;
  company: string;
  phone: string;
  role: string;
  credits: number;
}) {
  const existing = await db.select().from(users).where(eq(users.email, input.email)).limit(1);
  if (existing[0]) return existing[0];
  const id = randomUUID();
  const passwordHash = await hashPassword(input.password);
  await db.insert(users).values({
    id,
    name: input.name,
    email: input.email,
    passwordHash,
    company: input.company,
    phone: input.phone,
    role: input.role,
    credits: input.credits,
  });
  await db.insert(ledger).values({
    id: randomUUID(),
    userId: id,
    type: "grant",
    amount: input.credits,
    balanceAfter: input.credits,
    note: input.role === "admin" ? "Kfyklab operator float" : "Lab opening balance",
  });
  return (await db.select().from(users).where(eq(users.id, id)).limit(1))[0];
}

async function ensureSender(userId: string, label: string, status: string) {
  const rows = await db.select().from(senderIds).where(eq(senderIds.userId, userId));
  if (rows.some((row) => row.label === label)) return;
  await db.insert(senderIds).values({
    id: randomUUID(),
    userId,
    label,
    status,
  });
}

function demoPhone(index: number) {
  const prefixes = ["17", "18", "19", "16", "15", "13"];
  const prefix = prefixes[index % prefixes.length];
  const rest = String(10000000 + index * 137).slice(0, 8);
  return `+880${prefix}${rest}`;
}

async function seedDemoOrders(userId: string) {
  const existing = await db.select({ id: campaigns.id }).from(campaigns).where(eq(campaigns.userId, userId)).limit(1);
  if (existing.length) return;

  const now = Date.now();
  const liveId = randomUUID();
  const liveCount = 32;
  let delivered = 0;
  let failed = 0;
  const liveRows = Array.from({ length: liveCount }, (_, index) => {
    const past = index < 22;
    const isFailed = past && index % 11 === 0;
    if (past && isFailed) failed += 1;
    if (past && !isFailed) delivered += 1;
    const scheduledAt = past ? new Date(now - (40 - index) * 60 * 1000) : new Date(now + (index - 21) * 12 * 1000);
    return {
      id: randomUUID(),
      campaignId: liveId,
      phone: demoPhone(index + 3),
      name: ["Karim", "Nusrat", "Rafi", "Mitu", "Hasan", "Lima"][index % 6],
      status: past ? (isFailed ? "failed" : "delivered") : "queued",
      scheduledAt,
      sentAt: past ? scheduledAt : null,
      providerRef: past ? `KFY-SEED${String(index).padStart(3, "0")}` : null,
      error: isFailed ? "Carrier rejected" : null,
    };
  });

  await db.insert(campaigns).values({
    id: liveId,
    userId,
    name: "Banani showroom reopen",
    senderLabel: "NORTHWIND",
    message: "Northwind: Banani showroom reopens Friday at 10am. Show this SMS at the door.",
    encoding: "gsm",
    segments: 1,
    status: "sending",
    scheduleMode: "instant",
    perMinute: 40,
    skipWeekend: false,
    weekendMode: "bd",
    scheduleLabel: "Instant · 40/min",
    startsAt: liveRows[0]?.scheduledAt,
    endsAt: liveRows[liveRows.length - 1]?.scheduledAt,
    totalRecipients: liveCount,
    sentCount: delivered + failed,
    deliveredCount: delivered,
    failedCount: failed,
    creditCost: liveCount,
  });
  await db.insert(recipients).values(liveRows);

  const start = new Date(now + 18 * 60 * 60 * 1000);
  const end = new Date(now + 3 * 24 * 60 * 60 * 1000);
  const pacedCount = 36;
  const plan = planSchedule({
    mode: "generated",
    count: pacedCount,
    perMinute: 24,
    startLocal: toDhakaInput(start),
    endLocal: toDhakaInput(end),
    windowStart: "10:00",
    windowEnd: "18:00",
    skipWeekend: false,
    weekendMode: "bd",
    now: new Date(now),
  });
  if (!plan.ok) return;

  const pacedId = randomUUID();
  await db.insert(campaigns).values({
    id: pacedId,
    userId,
    name: "Week 12 due collection",
    senderLabel: "TEXTER",
    message: "Northwind: {name}, your invoice is due. Pay at the counter today to avoid a late fee.",
    encoding: "gsm",
    segments: 1,
    status: "scheduled",
    scheduleMode: "generated",
    windowStart: "10:00",
    windowEnd: "18:00",
    perMinute: 24,
    skipWeekend: false,
    weekendMode: "bd",
    scheduleLabel: "Generated · 10:00–18:00 · 24/min · all days",
    startsAt: new Date(plan.startsAt),
    endsAt: new Date(plan.endsAt),
    totalRecipients: pacedCount,
    sentCount: 0,
    deliveredCount: 0,
    failedCount: 0,
    creditCost: pacedCount,
  });
  await db.insert(recipients).values(
    plan.times.map((time, index) => ({
      id: randomUUID(),
      campaignId: pacedId,
      phone: demoPhone(index + 80),
      name: ["Shop 4", "Shop 9", "Rima", "Jamal", "Orpa", "Tanim"][index % 6],
      status: "queued",
      scheduledAt: new Date(time),
    })),
  );
  if (plan.slots.length) {
    await db.insert(scheduleSlots).values(
      plan.slots.map((slot, index) => ({
        id: randomUUID(),
        campaignId: pacedId,
        slotIndex: index,
        startsAt: new Date(slot.at),
        recipientCount: slot.count,
        status: "pending",
      })),
    );
  }

  const spent = liveCount + pacedCount;
  await db.update(users).set({ credits: 2500 - spent }).where(eq(users.id, userId));
  await db.insert(ledger).values([
    {
      id: randomUUID(),
      userId,
      type: "debit",
      amount: -liveCount,
      balanceAfter: 2500 - liveCount,
      note: "Order · Banani showroom reopen",
      campaignId: liveId,
    },
    {
      id: randomUUID(),
      userId,
      type: "debit",
      amount: -pacedCount,
      balanceAfter: 2500 - spent,
      note: "Order · Week 12 due collection",
      campaignId: pacedId,
    },
  ]);
}

export async function rearmSampleQueue(userId: string) {
  const [campaign] = await db
    .select()
    .from(campaigns)
    .where(and(eq(campaigns.userId, userId), eq(campaigns.name, "Banani showroom reopen")))
    .limit(1);
  if (!campaign || campaign.status === "paused" || campaign.status === "cancelled" || campaign.status === "completed") return;
  const queued = await db
    .select({ id: recipients.id, scheduledAt: recipients.scheduledAt })
    .from(recipients)
    .where(and(eq(recipients.campaignId, campaign.id), eq(recipients.status, "queued")))
    .orderBy(asc(recipients.scheduledAt));
  if (!queued.length) return;
  const latest = queued[queued.length - 1]?.scheduledAt?.getTime() ?? 0;
  if (latest > Date.now()) return;
  const now = Date.now();
  for (let index = 0; index < queued.length; index += 1) {
    await db
      .update(recipients)
      .set({ scheduledAt: new Date(now + (index + 1) * 8 * 1000) })
      .where(eq(recipients.id, queued[index].id));
  }
  await db
    .update(campaigns)
    .set({ status: "sending", endsAt: new Date(now + queued.length * 8 * 1000) })
    .where(eq(campaigns.id, campaign.id));
}

async function ensureTables() {
  const statements = [
    `create table if not exists users (
      id text primary key,
      name text not null,
      email text not null unique,
      password_hash text not null,
      company text,
      phone text,
      role text not null default 'customer',
      credits integer not null default 0,
      created_at timestamptz not null default now()
    )`,
    `create table if not exists sessions (
      id text primary key,
      user_id text not null references users(id) on delete cascade,
      token text not null unique,
      expires_at timestamptz not null,
      created_at timestamptz not null default now()
    )`,
    `create table if not exists sender_ids (
      id text primary key,
      user_id text not null references users(id) on delete cascade,
      label text not null,
      status text not null default 'pending',
      created_at timestamptz not null default now()
    )`,
    `create table if not exists campaigns (
      id text primary key,
      user_id text not null references users(id) on delete cascade,
      name text not null,
      sender_label text not null,
      message text not null,
      encoding text not null,
      segments integer not null,
      status text not null default 'scheduled',
      schedule_mode text not null,
      window_start text,
      window_end text,
      per_minute integer not null default 40,
      skip_weekend boolean not null default false,
      weekend_mode text not null default 'bd',
      schedule_label text,
      starts_at timestamptz,
      ends_at timestamptz,
      total_recipients integer not null default 0,
      sent_count integer not null default 0,
      delivered_count integer not null default 0,
      failed_count integer not null default 0,
      credit_cost integer not null default 0,
      created_at timestamptz not null default now()
    )`,
    `create table if not exists recipients (
      id text primary key,
      campaign_id text not null references campaigns(id) on delete cascade,
      phone text not null,
      name text,
      status text not null default 'queued',
      scheduled_at timestamptz not null,
      sent_at timestamptz,
      provider_ref text,
      error text
    )`,
    `create table if not exists schedule_slots (
      id text primary key,
      campaign_id text not null references campaigns(id) on delete cascade,
      slot_index integer not null,
      starts_at timestamptz not null,
      recipient_count integer not null,
      status text not null default 'pending'
    )`,
    `create table if not exists ledger (
      id text primary key,
      user_id text not null references users(id) on delete cascade,
      type text not null,
      amount integer not null,
      balance_after integer not null,
      note text,
      campaign_id text,
      created_at timestamptz not null default now()
    )`,
    `create index if not exists recipients_due_idx on recipients (status, scheduled_at)`,
    `create index if not exists recipients_campaign_idx on recipients (campaign_id)`,
    `create index if not exists campaigns_user_idx on campaigns (user_id)`,
  ];
  for (const statement of statements) {
    await db.execute(sql.raw(statement));
  }
}

async function runSeed() {
  await ensureTables();
  await upsertUser({
    email: "admin@kfyklab.com",
    name: "Kfyklab Desk",
    password: "Signal#2048",
    company: "Kfyklab",
    phone: "+8801700000001",
    role: "admin",
    credits: 100000,
  });
  const demo = await upsertUser({
    email: "demo@kfyklab.com",
    name: "Nusrat Rahman",
    password: "Demo#2048",
    company: "Northwind Retail",
    phone: "+8801711002200",
    role: "customer",
    credits: 2500,
  });
  await ensureSender(demo.id, "TEXTER", "approved");
  await ensureSender(demo.id, "NORTHWIND", "approved");
  await ensureSender(demo.id, "BANANI", "pending");
  const admin = await db.select().from(users).where(eq(users.email, "admin@kfyklab.com")).limit(1);
  if (admin[0]) await ensureSender(admin[0].id, "KFYKLAB", "approved");
  await seedDemoOrders(demo.id);
}

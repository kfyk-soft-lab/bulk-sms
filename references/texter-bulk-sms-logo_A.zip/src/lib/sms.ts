export type ScheduleMode = "instant" | "fixed" | "generated";
export type WeekendMode = "bd" | "west";

export type AudienceRow = { phone: string; name?: string };

export type PlanInput = {
  mode: ScheduleMode;
  count: number;
  perMinute: number;
  startLocal?: string;
  endLocal?: string;
  windowStart?: string;
  windowEnd?: string;
  skipWeekend?: boolean;
  weekendMode?: WeekendMode;
  now?: Date;
};

export type PlannedSlot = { at: string; count: number };

export type PlanResult =
  | {
      ok: true;
      times: string[];
      slots: PlannedSlot[];
      startsAt: string;
      endsAt: string;
    }
  | { ok: false; error: string; capacity?: number };

const DHAKA_MS = 6 * 60 * 60 * 1000;

const GSM_BASIC = new Set(
  "@£$¥èéùìòÇ\nØø\rÅåΔ_ΦΓΛΩΠΨΣΘΞÆæßÉ !\"#¤%&'()*+,-./0123456789:;<=>?¡ABCDEFGHIJKLMNOPQRSTUVWXYZÄÖÑÜ§¿abcdefghijklmnopqrstuvwxyzäöñüà".split(
    "",
  ),
);
const GSM_EXT = new Set("^{}\\[~]|€".split(""));

export function dateToDhakaParts(date: Date) {
  const shifted = new Date(date.getTime() + DHAKA_MS);
  return {
    year: shifted.getUTCFullYear(),
    month: shifted.getUTCMonth(),
    day: shifted.getUTCDate(),
    hour: shifted.getUTCHours(),
    minute: shifted.getUTCMinutes(),
    weekday: shifted.getUTCDay(),
  };
}

export function dhakaDate(year: number, month: number, day: number, hour: number, minute: number) {
  return new Date(Date.UTC(year, month, day, hour, minute) - DHAKA_MS);
}

export function toDhakaInput(date: Date) {
  const p = dateToDhakaParts(date);
  const pad = (n: number) => String(n).padStart(2, "0");
  return `${p.year}-${pad(p.month + 1)}-${pad(p.day)}T${pad(p.hour)}:${pad(p.minute)}`;
}

export function dhakaLocalToDate(local: string): Date | null {
  const match = /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})/.exec(local);
  if (!match) return null;
  const year = Number(match[1]);
  const month = Number(match[2]);
  const day = Number(match[3]);
  const hour = Number(match[4]);
  const minute = Number(match[5]);
  if (month < 1 || month > 12 || day < 1 || day > 31 || hour > 23 || minute > 59) return null;
  const date = new Date(Date.UTC(year, month - 1, day, hour, minute) - DHAKA_MS);
  return Number.isNaN(date.getTime()) ? null : date;
}

export function nextDhakaHour(from = new Date()) {
  const p = dateToDhakaParts(from);
  return dhakaDate(p.year, p.month, p.day, p.hour + 1, 0);
}

export function normalizePhone(raw: string): string | null {
  const digits = raw.replace(/\D/g, "");
  if (!digits) return null;
  let d = digits.startsWith("00") ? digits.slice(2) : digits;
  if (d.startsWith("880")) {
    // already international
  } else if (d.startsWith("0") && d.length === 11) {
    d = `880${d.slice(1)}`;
  } else if (d.length === 10 && d.startsWith("1")) {
    d = `880${d}`;
  }
  if (/^8801[3-9]\d{8}$/.test(d)) return `+${d}`;
  if (d.length >= 10 && d.length <= 15 && !d.startsWith("0") && !d.startsWith("880")) return `+${d}`;
  return null;
}

function looksLikePhone(value: string) {
  const digits = value.replace(/\D/g, "");
  return digits.length >= 10 && digits.length <= 15 && /^[+\d\s()-]+$/.test(value);
}

export function parseAudience(raw: string): { valid: AudienceRow[]; invalid: string[] } {
  const valid: AudienceRow[] = [];
  const invalid: string[] = [];
  const seen = new Set<string>();
  const lines = raw.split(/\n+/).map((line) => line.trim()).filter(Boolean);

  for (const line of lines) {
    const pieces = line.split(/[,\t;|]/).map((part) => part.trim()).filter(Boolean);
    const rows: { phoneRaw: string; name?: string }[] = [];
    if (pieces.length === 2 && looksLikePhone(pieces[0]) && !looksLikePhone(pieces[1])) {
      rows.push({ phoneRaw: pieces[0], name: pieces[1] });
    } else if (pieces.length > 1 && pieces.every(looksLikePhone)) {
      pieces.forEach((phoneRaw) => rows.push({ phoneRaw }));
    } else {
      const spaced = line.match(/^(\+?\d[\d\s()-]{8,})\s+(.+)$/);
      if (spaced && looksLikePhone(spaced[1])) {
        rows.push({ phoneRaw: spaced[1], name: spaced[2].trim() });
      } else {
        rows.push({ phoneRaw: line });
      }
    }

    for (const row of rows) {
      const phone = normalizePhone(row.phoneRaw);
      if (!phone) {
        invalid.push(line);
        continue;
      }
      if (seen.has(phone)) continue;
      seen.add(phone);
      valid.push({ phone, name: row.name?.slice(0, 40) });
    }
  }

  return { valid, invalid };
}

export function analyzeMessage(text: string) {
  let gsm = true;
  let septets = 0;
  for (const ch of text) {
    if (GSM_BASIC.has(ch)) septets += 1;
    else if (GSM_EXT.has(ch)) septets += 2;
    else {
      gsm = false;
      break;
    }
  }
  if (!gsm) {
    const length = Array.from(text).length;
    const segments = length === 0 ? 0 : length <= 70 ? 1 : Math.ceil(length / 67);
    return { encoding: "unicode" as const, length, segments, single: 70, multi: 67 };
  }
  const segments = septets === 0 ? 0 : septets <= 160 ? 1 : Math.ceil(septets / 153);
  return { encoding: "gsm" as const, length: septets, segments, single: 160, multi: 153 };
}

export function renderMessage(template: string, name?: string | null) {
  const safe = (name ?? "").trim();
  return template.replaceAll("{name}", safe || "Customer");
}

function parseClock(value: string | undefined) {
  const match = /^(\d{2}):(\d{2})$/.exec(value ?? "");
  if (!match) return null;
  const hour = Number(match[1]);
  const minute = Number(match[2]);
  if (hour > 23 || minute > 59) return null;
  return hour * 60 + minute;
}

function isWeekend(weekday: number, mode: WeekendMode) {
  return mode === "bd" ? weekday === 5 || weekday === 6 : weekday === 0 || weekday === 6;
}

function minuteIso(ms: number) {
  const date = new Date(ms);
  return new Date(
    Date.UTC(date.getUTCFullYear(), date.getUTCMonth(), date.getUTCDate(), date.getUTCHours(), date.getUTCMinutes()),
  ).toISOString();
}

function slotsFromTimes(times: string[]): PlannedSlot[] {
  const map = new Map<string, number>();
  for (const time of times) {
    const key = minuteIso(new Date(time).getTime());
    map.set(key, (map.get(key) ?? 0) + 1);
  }
  return [...map.entries()]
    .sort((a, b) => a[0].localeCompare(b[0]))
    .map(([at, count]) => ({ at, count }));
}

function paceFrom(start: Date, count: number, perMinute: number) {
  const times: string[] = [];
  const step = 60 / perMinute;
  for (let i = 0; i < count; i += 1) {
    const at = start.getTime() + Math.floor(i * step) * 1000;
    times.push(new Date(at).toISOString());
  }
  return times;
}

function windowMinutes(start: Date, end: Date, windowStart: number, windowEnd: number, skipWeekend: boolean, weekendMode: WeekendMode) {
  const minutes: Date[] = [];
  const first = dateToDhakaParts(start);
  let cursor = dhakaDate(first.year, first.month, first.day, 0, 0);
  for (let day = 0; day < 62 && cursor.getTime() <= end.getTime(); day += 1) {
    const parts = dateToDhakaParts(cursor);
    if (!(skipWeekend && isWeekend(parts.weekday, weekendMode))) {
      for (let minute = windowStart; minute < windowEnd; minute += 1) {
        const at = dhakaDate(parts.year, parts.month, parts.day, Math.floor(minute / 60), minute % 60);
        if (at.getTime() >= start.getTime() && at.getTime() <= end.getTime()) minutes.push(at);
      }
    }
    cursor = new Date(cursor.getTime() + 24 * 60 * 60 * 1000);
  }
  return minutes;
}

export function planSchedule(input: PlanInput): PlanResult {
  const count = Math.floor(input.count);
  if (count < 1) return { ok: false, error: "no_recipients" };
  const perMinute = Math.max(1, Math.min(300, Math.floor(input.perMinute || 40)));
  const now = input.now ?? new Date();

  if (input.mode === "instant") {
    const times = paceFrom(now, count, perMinute);
    return { ok: true, times, slots: slotsFromTimes(times), startsAt: times[0], endsAt: times[times.length - 1] };
  }

  if (input.mode === "fixed") {
    const start = dhakaLocalToDate(input.startLocal ?? "");
    if (!start) return { ok: false, error: "bad_schedule" };
    const times = paceFrom(start, count, perMinute);
    return { ok: true, times, slots: slotsFromTimes(times), startsAt: times[0], endsAt: times[times.length - 1] };
  }

  const start = dhakaLocalToDate(input.startLocal ?? "");
  const end = dhakaLocalToDate(input.endLocal ?? "");
  if (!start || !end) return { ok: false, error: "bad_schedule" };
  if (end.getTime() <= start.getTime()) return { ok: false, error: "end_before_start" };
  const windowStart = parseClock(input.windowStart);
  const windowEnd = parseClock(input.windowEnd);
  if (windowStart === null || windowEnd === null || windowEnd <= windowStart) return { ok: false, error: "bad_schedule" };

  const minutes = windowMinutes(start, end, windowStart, windowEnd, Boolean(input.skipWeekend), input.weekendMode ?? "bd");
  if (minutes.length === 0) return { ok: false, error: "window_empty" };
  const capacity = minutes.length * perMinute;
  if (count > capacity) return { ok: false, error: "pace_too_tight", capacity };

  const times: string[] = [];
  for (let i = 0; i < count; i += 1) {
    const pos = (i + 0.5) / count;
    const minuteFloat = pos * minutes.length;
    const index = Math.min(minutes.length - 1, Math.floor(minuteFloat));
    const second = Math.min(59, Math.floor((minuteFloat - index) * 60));
    times.push(new Date(minutes[index].getTime() + second * 1000).toISOString());
  }
  return { ok: true, times, slots: slotsFromTimes(times), startsAt: times[0], endsAt: times[times.length - 1] };
}

export function bucketSlots(slots: PlannedSlot[], minutes: number) {
  const span = Math.max(1, minutes) * 60 * 1000;
  const map = new Map<number, number>();
  for (const slot of slots) {
    const ms = new Date(slot.at).getTime();
    const key = Math.floor(ms / span) * span;
    map.set(key, (map.get(key) ?? 0) + slot.count);
  }
  return [...map.entries()]
    .sort((a, b) => a[0] - b[0])
    .map(([ms, count]) => ({ at: new Date(ms).toISOString(), count }));
}

export function scheduleSummary(input: {
  mode: ScheduleMode;
  perMinute: number;
  windowStart?: string | null;
  windowEnd?: string | null;
  skipWeekend?: boolean;
  weekendMode?: string | null;
}) {
  if (input.mode === "instant") return `Instant · ${input.perMinute}/min`;
  if (input.mode === "fixed") return `Fixed start · ${input.perMinute}/min`;
  const weekend =
    input.skipWeekend ? (input.weekendMode === "west" ? "skip Sat–Sun" : "skip Fri–Sat") : "all days";
  return `Generated · ${input.windowStart ?? "09:00"}–${input.windowEnd ?? "20:00"} · ${input.perMinute}/min · ${weekend}`;
}
